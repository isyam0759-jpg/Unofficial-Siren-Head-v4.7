# Siren Head Addon — port ke Forge 1.20.1 (GeckoLib)

Port dari **Siren Head Addon V4.7 (1.21 FIX)** karya **BendytheDemon17** (add-on Minecraft Bedrock) ke mod Java Forge 1.20.1.
Seluruh hak cipta konten (model, tekstur, animasi, partikel, desain mob) tetap milik pembuat aslinya — beri kredit kepadanya
jika Anda membagikan mod ini.

## Pendekatan

Sesuai permintaan ("tanpa mengubah efek partikel, animation controller, dll"), file Bedrock **tidak diterjemahkan ulang**.
JSON aslinya dikirim apa adanya di dalam mod dan dijalankan oleh *runtime Bedrock* berbasis Java; GeckoLib hanya dipakai untuk
geometri/render/bone.

| Bagian | Cara |
|---|---|
| Animation controller, animasi, Molang | JSON asli → `com.sirenhead.bedrock.anim` / `molang` (murni Java, dites) |
| Partikel (`particles/*.json`) | JSON asli → `com.sirenhead.bedrock.particle` (emitter, kurva, flipbook, tabrakan) dirender di `BedrockParticles` |
| Behavior entity (komponen, group, event, property) | JSON asli → `com.sirenhead.bedrock.behavior` + `entity/ai/BedrockComponents` |
| Command (`execute`, `damage`, `effect`, `tp`, `summon`, `ride`, …) & `.mcfunction` | `com.sirenhead.bedrock.command` (parser, teruji) + `server/command/BedrockCommands` |
| Model / render | GeckoLib 4.8.4 (`client/BedrockEntityRenderer`, `BedrockGeoModel`) |

Satu kelas `BedrockEntity` melayani ke-74 entity; tiap entity punya `EntityType` sendiri (`sirenhead:<nama>`).
ID Bedrock `ho:x` / `bd:x` → `sirenhead:x`.

## Build

```
./gradlew build          # butuh JDK 17 dan internet (Forge + GeckoLib)
./gradlew runClient
```
Hasil: `build/libs/sirenhead-4.7.0.jar`. Pasang bersama GeckoLib 4.8.x untuk Forge 1.20.1 dan Forge 47.3.0+.

## Build otomatis (GitHub Actions)
`.github/workflows/build.yml` (satu file): mengekstrak zip di root repo bila ada, menyimpan hasil ekstrak ke repo, lalu
membangun jar di GitHub (Java 17) dan menaruh `sirenhead-jar` + `build-log` sebagai artifact; daftar error juga ditulis di
halaman Summary. Panduan dari HP: `PANDUAN_GITHUB_HP.md`.

## Status

**Tahap-1 (paket ini):** semua entity (74), animasi/controller, partikel, behavior, command, jaringan, blok (`siren_head_head`,
`bd_lighter`), spawn egg, creative tab.
**Tahap-2 (belum):** revolver & shotgun, Creator Sword (17 varian), tophat, armor maid, resep, loot table, spawn rule, port
`scripts/modules/*.js`, animasi item.

### PENTING — kode Forge belum pernah dikompilasi
Lingkungan tempat saya bekerja tidak bisa mengunduh Minecraft/Forge/GeckoLib, jadi:
* paket `com.sirenhead.bedrock.**` (runtime murni) **sudah dikompilasi dan dites** terhadap data asli addon;
* paket `com.sirenhead.mod.**` (kode Forge/GeckoLib) **hanya diperiksa sintaks dan konsistensi antar-kelas**. Harapkan beberapa
  error kompilasi kecil pada build pertama (nama method/parameter API). Yang paling mungkin:
  * `BedrockEntity`: `Entity.setMaxUpStep`, `walkAnimation`, `removeAllGoals` — sesuaikan ke API 1.20.1 official mappings;
  * `BedrockGeoModel`: `getAnimationProcessor().getRegisteredBones()`, `bone.getInitialSnapshot()`;
  * `BedrockEntityRenderer`: signature `getRenderType(...)` / `render(...)` GeckoLib 4.8;
  * `SirenBlockRenderer`: signature `rotateBlock(Direction, PoseStack)`;
  * `BedrockNetwork`: `PacketDistributor` / `NetworkEvent.Context`.
  Kirim log error `./gradlew build` kepada saya dan akan saya perbaiki.

### Titik kalibrasi visual
* `client/BedrockGeoModel`: konstanta `ROT_X/Y/Z` dan `POS_X/Y/Z` (tanda arah rotasi/posisi bone). Jika animasi tampak
  terbalik/cermin di game, balik tandanya di sana — satu tempat saja.
* `client/BedrockParticles.place`: sumbu lokal emitter yang menempel pada entity (kiri/atas/depan).

### Suara
Add-on aslinya **tidak menyertakan file audio**. `sounds.json` sudah dibuat; letakkan file `.ogg` sesuai daftar di
`src/main/resources/assets/sirenhead/sounds/REQUIRED_SOUND_FILES.txt` (tanpa file, game hanya mencatat peringatan).

## Perbedaan yang disengaja
* `gamerule` dan `difficulty` di dalam command addon **diabaikan** (mengubah pengaturan dunia). `gamemode` pada pemain tetap dijalankan.
* `tp` ke koordinat ekstrem (`~999999999…`, cara addon "membuang" mob) → entity non-pemain di-`discard`.
* `anchored eyes` + `positioned ^^^N`: offset mata dipakai satu kali (agar sinar sonic blast lurus, tidak naik terus).
* Rantai fungsi dibatasi (kedalaman 400 / 2500 command) agar loop `sonic_blast` tidak menggantung server.
* `textures/particle/particles` (atlas partikel lama Bedrock) dipetakan ke `generic_0..7` vanilla (4 partikel: attack, blood, sound_part, warning).
* `playanimation` pada pemain diabaikan (model pemain bukan GeckoLib).
* Material: `slime` → translucent, `charged_creeper` → additive (`eyes`), lainnya cutout.

## Cacat bawaan addon (dipertahankan, tidak diperbaiki)
* Controller hilang: `controller.animation.siren_head_bd.{move,attack,sound_attack}`, `cartoon_cat_bd.move`, `cartoon_hand.{move,hey}`,
  `cartoon_head.{move,hey}`; animasi `cartoon_hand3.general2`, `mountain_bd.*` tidak terdefinisi; shortname `gan` tidak terpetakan.
* 45 nama animasi duplikat (yang terakhir menang); event merujuk component group yang tidak ada.
* 3 referensi tekstur tidak ada (`lighthead_taiga`) → tekstur putih.
* Tidak ada file audio.

## Struktur
```
src/main/java/com/sirenhead/bedrock/   runtime murni (Molang, anim, particle, behavior, command)
src/main/java/com/sirenhead/mod/       glue Forge (entity, goal, command, jaringan, client, blok, item)
src/main/resources/assets/sirenhead/   geo/, textures/, lang/, sounds.json, bedrock/rp (JSON asli)
src/main/resources/data/sirenhead/bedrock/bp   behavior asli (entities, controllers, functions, ...)
tools/port_assets.py, tools/fill_lang.py       pengonversi aset
devtools/tests/                                tes lokal untuk runtime murni
```
Tes lokal runtime: lihat `devtools/tests/*` (javac + gson, tanpa Forge).
