> **Catatan:** dokumen ini adalah kontrak desain awal. Untuk keadaan akhir lihat `README.md` di root proyek (beberapa nama kelas dan pembagian modul berubah).

# Siren Head — Bedrock add-on → Forge 1.20.1 + GeckoLib 4.8.4

Goal: port `Siren Head Addon V4.7 (1.21 FIX)` to a Forge 1.20.1 mod **without changing particle effects,
animation controllers, animations, entity behaviour data** — the original Bedrock JSON is shipped unchanged and
executed by a small Bedrock runtime written in Java; GeckoLib provides geometry loading, rendering, bones.

Original addon extracted at (read-only reference, NEVER modify):
`/tmp/claude-0/-home-claude/0bff84df-77de-57d8-a179-e7ef0b7f5dbd/scratchpad/src/ex/SirenHead V4.7(BP)` and `...(RP)`.
Project root: `/home/claude/sirenhead-forge` (Gradle, ForgeGradle 6, Java 17, package root `com.sirenhead`).

## Rules for everyone
* Write ONLY inside your own packages/files (see ownership). Never edit another module's files; if you need an API change
  from another module, adapt on your side or note it in your final report.
* `com.sirenhead.bedrock.**` is **pure Java 17** (only `com.google.gson` + JDK). No `net.minecraft`, no Forge, no GeckoLib.
  That lets us compile and test it here: `javac --release 17 -cp /opt/gradle-8.14.3/lib/gson-2.10.jar -d <out> $(find ... -name '*.java')`.
* `com.sirenhead.mod.**` is Forge 1.20.1 (official/Mojang mappings: `net.minecraft.world.entity.PathfinderMob`, `ServerLevel`,
  `ResourceLocation`, `Vec3`, `SynchedEntityData`, ...). We CANNOT compile it here (Maven is blocked) so be meticulous:
  use only APIs you are certain exist in 1.20.1 / Forge 47.x / GeckoLib 4.8.4. GeckoLib sources (4.8.5 head of branch 1.20.1) are
  cached in `/tmp/claude-0/-home-claude/0bff84df-77de-57d8-a179-e7ef0b7f5dbd/scratchpad/gl` and can be downloaded from
  `https://raw.githubusercontent.com/bernie-g/geckolib/1.20.1/{core|Forge}/src/main/java/software/bernie/geckolib/...` (curl works for raw.githubusercontent.com only).
* Tests live in `/home/claude/sirenhead-forge/devtools/tests/<module>/` (plain `main` programs, no JUnit) and run against the REAL addon data
  (extracted dir above, via `DirectoryResourceSource`). Scratch/build output goes to
  `/tmp/claude-0/-home-claude/0bff84df-77de-57d8-a179-e7ef0b7f5dbd/scratchpad/build-<module>/`.
* Molang is done: `com.sirenhead.bedrock.molang.{Molang,MolangEnv,MolangEnvBase}`. Values are `Double`/`String`/entity-ref objects; `null` = unset.
  Booleans are 1.0/0.0. `Molang.compile(str)` is cached; `expr.evalD(env)`.
* Java code style: no Lombok, no external libs, `@Nullable` from `org.jetbrains.annotations` only in `mod` code.
* Final report to the coordinator (<= 25 lines): files written, public API as implemented (any deviation from this doc), what was tested, known gaps.

## Resource layout (produced by `tools/port_assets.py`, output committed under `src/main/resources`)
```
assets/sirenhead/bedrock/rp/{animations,animation_controllers,entity,render_controllers,particles,attachables}/**.json   (unchanged content, lower-cased names)
assets/sirenhead/bedrock/rp/sounds/sound_definitions.json, sounds.json, geometry_index.json, index.json
assets/sirenhead/geo/<geometry id without "geometry.">.geo.json      (GeckoLib; ONE geometry per file, format 1.12.0)
assets/sirenhead/textures/**   (same relative paths as the Bedrock RP, lower-cased)   -> ResourceLocation("sirenhead","textures/entity/foo.png")
assets/sirenhead/lang/en_us.json, assets/sirenhead/sounds.json
data/sirenhead/bedrock/bp/{entities,animations,animation_controllers,functions,spawn_rules,items,blocks,recipes}/**   (unchanged content)
data/sirenhead/bedrock/bp/index.json
```
`index.json` = JSON array of every logical file path below it (full paths incl. `assets/...`/`data/...`), because jars can't be listed.
Use `new ClasspathResourceSource(loader, BedrockPaths.RP_INDEX, BedrockPaths.BP_INDEX)` in game and `DirectoryResourceSource(root)` in tests
(for tests, a directory laid out exactly like the jar is produced by `tools/port_assets.py --out <dir>`; the coordinator will have it at
`/home/claude/sirenhead-forge/src/main/resources` as soon as the script exists — until then read the extracted addon directly and map paths yourself).
`BedrockPaths.RP` / `BedrockPaths.BP` are the two roots.

Id mapping: Bedrock `ho:sirenhead`, `bd:slam` → Java `sirenhead:sirenhead`, `sirenhead:slam` (`BedrockPaths.javaId`). Bedrock ids stay the keys inside the Bedrock runtime.

## Pure modules and their public contracts

### A. `com.sirenhead.bedrock.anim` (animations, controllers, client entity defs, rig)  — owner: Fork A
```java
public interface AnimationHost {            // implemented by the Forge glue
    MolangEnv env();                         // entity queries + persistent v.* storage (a MolangEnvBase subclass)
    void command(String cmd);                // BP side: timeline entries / controller on_entry,on_exit strings: "/execute ...", "@s bd:event", "v.x = ...;" are NOT commands (those are Molang, handled internally)
    void particle(String effect, String locator, String preEffectScript);   // RP side; `effect` = short name from entity "particle_effects" (or a full id)
    void sound(String effect);                                              // RP side; short name from entity "sound_effects" (or full event id)
}
public final class BedrockAnimLibrary {      // immutable, thread-safe after load
    public static BedrockAnimLibrary load(ResourceSource src, String rootDir);   // reads rootDir/animations/*.json, rootDir/animation_controllers/*.json (rootDir = BedrockPaths.RP or BP)
    public AnimationDef animation(String fullName);           // "animation.x.y" ; null if unknown
    public ControllerDef controller(String fullName);         // "controller.animation.x.y"
}
public record AnimateEntry(String shortName, String condition /* molang, nullable */) {}
public final class EntityAnimator {
    public EntityAnimator(BedrockAnimLibrary lib, Map<String,String> animations /* short -> animation.* or controller.animation.* */,
                          List<AnimateEntry> animate, List<String> preAnimationScripts, boolean computePose /* true client/RP, false server/BP */, AnimationHost host);
    public static List<AnimateEntry> parseAnimate(JsonElement scriptsAnimate);   // JSON "scripts.animate": ["a", {"b":"cond"}]
    public static List<String> parseScriptList(JsonElement e);                   // "scripts.pre_animation" etc (string or array of strings)
    public void tick(double timeSeconds);        // advance to absolute time (entity life time in seconds, may include partial ticks, monotonic); fires events through host
    public Pose pose();                          // blended pose for the last tick (computePose only)
    public void playForced(String fullAnimOrControllerName, String nextState, double blendOutSeconds, String stopExpression, String controllerName); // Bedrock /playanimation
    public void reset();
}
public final class Pose { public static final class Bone { public final double[] rot /*deg, Bedrock*/, pos /*px*/, scale; } public Map<String,Bone> bones(); }
public final class ClientEntityDef {         // RP entity/*.json "minecraft:client_entity"
    public static ClientEntityDef parse(JsonObject root);
    String identifier(); Map<String,String> textures(); Map<String,String> geometry(); Map<String,String> materials();
    Map<String,String> animations(); List<AnimateEntry> animate(); List<String> preAnimation();
    Map<String,String> particleEffects(); Map<String,String> soundEffects(); List<String> renderControllers();
    boolean hasScripts(); (plus anything else you need, e.g. spawn_egg, enable_attachables)
}
public final class RenderControllerDef {     // RP render_controllers/*.json
    public static Map<String,RenderControllerDef> parseAll(JsonObject root);
    public Choice resolve(MolangEnv env, ClientEntityDef def);   // evaluates geometry/textures/materials, arrays (Array.skins[query.variant]) -> Choice(geometryId e.g. "geometry.siren_head_bd", texturePath e.g. "textures/entity/towerhead/towerhead", material)
    public record Choice(String geometryId, String texturePath, String material) {}
}
public final class Rig {                     // from the GeckoLib geo json produced by the pipeline (format 1.12.0, one geometry)
    public static Rig parse(String geoJson);
    public double[] locator(String name, Pose poseOrNull);    // Bedrock model-space position in PIXELS after bone transforms (null if locator absent)
    public Set<String> boneNames();
}
```
Semantics to honour (Bedrock): animations of ALL active controllers/animations are blended additively (rotation/position summed ×weight, scale multiplied);
`animate` entries evaluated each tick (condition optional); controllers: initial_state (default "default"), transitions in order, `on_entry`/`on_exit`
(Molang or commands), per-state `animations` (name or {name: blendExpr}), `particle_effects`, `sound_effects`, `blend_transition`, `blend_via_shortest_path`,
`query.all_animations_finished` / `any_animation_finished` (per controller state), `query.anim_time`, `variables`; animation: `loop` (true/false/"hold_on_last_frame"),
`animation_length`, `anim_time_update`, `blend_weight`, `override_previous_animation`, `start_delay`, `loop_delay`, `timeline` (commands at times → host.command),
`sound_effects` / `particle_effects` (time-keyed → host.sound/particle), bones rotation/position/scale as constants/Molang/keyframes with `pre`/`post`,
`lerp_mode` linear/catmullrom/step. `this` in channel expressions = the default value for that channel. Evaluate Molang with a decorated env that overrides
`query.anim_time`, `query.all_animations_finished`, `this` and falls through to `host.env()`. Missing animation/controller names are ignored (log once).
Built-in `animation.common.look_at_target` → head bone rotation `[query.target_x_rotation, query.target_y_rotation, 0]` (provide it in code).

### B. `com.sirenhead.bedrock.particle` (pure) + `com.sirenhead.mod.client.particle` (Forge, client only) — owner: Fork B
```java
public final class ParticleLibrary { public static ParticleLibrary load(ResourceSource src, String rpRoot); public ParticleDef get(String bedrockId /* "bd:siren_range" */); public Set<String> ids(); }
// pure simulation (no MC): ParticleDef (parse of particle_effect), ParticleEmitterSim(def, MolangEnv-backed vars, rng) with
//   tick(dt) / state of live particles: position, velocity, size, uv rect (flipbook), colour rgba, rotation, facing mode, lifetime, light mode
// Forge client:
public final class BedrockParticles {
    public static void init(net.minecraftforge.eventbus.api.IEventBus modBus, net.minecraftforge.eventbus.api.IEventBus forgeBus, ParticleLibrary lib);  // client setup: register render hook (RenderLevelStageEvent) + tick hook (ClientTickEvent); call once
    public static void spawn(String bedrockId, double x, double y, double z, float yawDeg, @Nullable net.minecraft.world.entity.Entity attachTo, @Nullable Map<String,Double> variables);
    public static void clear();
}
```
All 69 particle files must behave as in Bedrock (components listed in the survey: emitter_rate_instant/steady, emitter_lifetime_once/looping, emitter_shape_point/disc/box/sphere,
emitter_local_space, emitter_initialization, particle_lifetime_expression, particle_initial_speed, particle_initial_spin, particle_motion_dynamic/collision,
particle_appearance_billboard (facing modes, uv flipbook), particle_appearance_tinting (gradient/expression), particle_appearance_lighting, particle_expire_if_not_in_blocks;
curves and Molang vars `variable.particle_age/lifetime/random_1..4`, `variable.emitter_age`…). Textures: `textures/particle/x` → `sirenhead:textures/particle/x.png`; `textures/blocks/dirt` → `minecraft:textures/block/dirt.png`;
`textures/particle/particles` (vanilla atlas) → pick the closest sensible fallback and document it. Blend: Bedrock `particles_blend`/`particles_alpha` materials.

### C1. `com.sirenhead.bedrock.behavior` (pure) + `com.sirenhead.mod.entity.ai` (Forge) — owner: Fork C1
```java
public final class BehaviorDef {             // BP entities/**.json "minecraft:entity"
    public static BehaviorDef parse(JsonObject root);
    String identifier(); boolean spawnable(); boolean summonable();
    Map<String,PropertyDef> properties();    // description.properties (int/float/bool/enum, default, range, client_sync)
    JsonObject components(); Map<String,JsonObject> componentGroups(); Map<String,JsonElement> events();
    Map<String,String> animationMap(); List<AnimateEntry> animate(); List<String> preAnimation();   // description.animations / scripts.animate / scripts.pre_animation  (AnimateEntry from the anim module)
}
public record PropertyDef(String name, String type, double def /* enums: index */, List<String> enumValues, double min, double max, boolean clientSync) {}
public interface BehaviorHost {
    void onComponentsChanged();                                   // groups/properties changed: rebuild goals/attributes/timers
    void runCommand(String command, String target);              // queue_command entries; target "self"|"target"|"other"|...; executed by the command engine
    java.util.Random random();
    FilterContext filterContext(String subject);                  // see below
}
public interface FilterContext { Object test(String test, String operator, Object value); }   // per-subject facts for filters (is_family, has_damage, has_target, target_distance, distance_to_nearest_player, hourly_clock_time, has_tag, on_ground, has_equipment, is_riding, in_water, ...)
public final class BehaviorState {
    public BehaviorState(BehaviorDef def, BehaviorHost host);
    public void trigger(String event);                            // full Bedrock event semantics: add/remove component_groups, set_property, randomize (weights, per-entry filters), sequence, trigger (nested), queue_command, filters (all_of/any_of/none_of, test/subject/operator/value, domain), reset_target...
    public boolean hasGroup(String g); public Set<String> activeGroups();
    public double property(String name); public void setProperty(String name, double v);   // clamped to range, enums by index
    public JsonObject component(String name);                      // effective component: top-level overridden by active groups (later groups win), or null
    public Map<String,JsonObject> effectiveComponents();
    public CompoundTag-free serialization: String saveState(); void loadState(String s);
    public void initDefaults();                                    // property defaults, then caller triggers "minecraft:entity_spawned"
}
// Forge (owner C1): com.sirenhead.mod.entity.ai.BedrockComponents:  static void apply(BedrockEntity e)  (re-applies attributes/goals/sensors/timers from effective components);  static void tick(BedrockEntity e) (timers, sensors, spawn_entity, environment_sensor, tick_world…);
//   plus every Goal class + McFilterContext (implements FilterContext for entity / other entity / damage source).
```
Components to implement (from the survey; see Fork C1 brief): timer, target_nearby_sensor, environment_sensor, spawn_entity, behavior.melee_attack, behavior.look_at_target, look_at_player, random_look_around,
random_stroll, move_towards_restriction, float, ranged_attack, delayed_attack, nearest_prioritized_attackable_target, nearest_attackable_target, hurt_by_target, summon_entity, knockback_roar, lay_down,
movement, movement.basic/skip, scale (visual only, query model_scale), health, knockback_resistance, follow_range, attack, damage_sensor, hurt_on_condition, rideable, projectile, explode, instant_despawn, despawn, tick_world, transformation, variant/mark_variant/skin_id,
is_stunned, angry, ageable, type_family, fire_immune, fall_damage, can_climb, break_blocks, collision_box/custom_hit_test (document how mapped), underwater_movement, variable_max_auto_step, jump.static, preferred_path, navigation.*, loot, addrider, physics, pushable, nameable, breathable, floats_in_liquid.

### C2. `com.sirenhead.bedrock.command` (pure) + `com.sirenhead.mod.server.command` + `com.sirenhead.mod.network` (Forge) — owner: Fork C2
```java
// Forge, server:
public final class BedrockCommands {
    public static int run(ServerLevel level, @Nullable Entity executor, String command);        // one Bedrock command: "/execute ...", "execute ...", "effect @s ...", "@s bd:event" (= /event entity @s bd:event shorthand used by controllers). Returns success count.
    public static int runFunction(ServerLevel level, @Nullable Entity executor, String functionPath);   // "sirenhead/bat_choi2" -> data/sirenhead/bedrock/bp/functions/sirenhead/bat_choi2.mcfunction
}
// Forge, network:  com.sirenhead.mod.network.BedrockNetwork { public static void register(); public static SimpleChannel CHANNEL; }  // owned by C2
//   packets (server->client): PlayAnimationPacket(entityId, anim, nextState, blendOut, stopExpr, controller)  -> client EntityAnimator.playForced via BedrockClientHooks interface (see below)
//   CameraShakePacket, CameraSetPacket/CameraClearPacket/CameraFadePacket, InputPermissionPacket(movement,camera), BedrockParticlePacket(id,x,y,z,yaw,attachEntityId)
// Client hook seam (C2 defines, coordinator implements): com.sirenhead.mod.network.ClientHooks { static void playAnimation(int entityId, String anim, String next, double blendOut, String stop, String ctrl); }
```
Bedrock commands present in the add-on (counts): execute 212, playanimation 53, camerashake 49, say 39, gamemode 38, event (`@s evt` 32 + `/event entity` 7), effect 30, stopsound 24, scoreboard 20,
playsound 12, gamerule 12, function 10, tp 6, tag 6, inputpermission 6, ride 5, kill 4, summon 4, particle 4, damage 2, camera 2, title/msg/setblock 1; plus `scriptevent bd:entity_move <side> <up> <front>` (see BP scripts/modules/Main.js, applies impulse along view dir)
and the `entityHurt` knockback script (damaged non-player by `siren_head` family gets impulse view*2). Selectors: `@s @e @a @p @r @initiator`, args `type family(!) r rm c tag(!) m(!) name scores x y z dx dy dz l lm rx ry rxm rym haspermission hasitem`
(implement those that occur; grep the add-on). `execute` subcommands: as, at, positioned (incl. `^^^` local, `~~~`), rotated, anchored, if/unless entity, run. Local coordinates `^` use the executor's rotation (yaw only when `rotated ~ 0`).
`family=` for vanilla entities: provide a small table (player, monster, inanimate (armor_stand, boat, minecart, item, ...), mob, undead, zombie, skeleton, villager, ...); modded entities → `BedrockEntity.def` families (type_family component) — see BedrockEntity API.

### D. Items / blocks / weapons — `com.sirenhead.mod.item`, `com.sirenhead.mod.block` — owner: Fork D
Ports BP `items/**`, `blocks/**`, `recipes/**`, `scripts/modules/**` (revolver, shotgun, Creator Sword "trevorsword" with 16 variants, tophat helmet, maid chestplate, siren_head_head block, bd_lighter block)
+ RP `attachables/**`, models, textures, item animations/controllers (`revolver.animation.json`, `revolver.animation_controllers.json`, ...). Registers via `SirenItems.register(IEventBus)` / `SirenBlocks.register(IEventBus)`;
exposes `SirenItems.ALL_ITEMS` (list of `Supplier<? extends Item>`) for the creative tab.

## Forge glue (coordinator)
`com.sirenhead.mod.{SirenHeadMod, BedrockEntities (EntityType per BP entity, spawn eggs), entity.BedrockEntity, entity.BedrockEntityDef, molang.EntityMolangEnv, client.* (renderer, GeoModel, client setup), BedrockLibraries}`

```java
package com.sirenhead.mod.entity;
public class BedrockEntity extends PathfinderMob implements GeoEntity {
    public BedrockEntityDef def();                       // def().id() "ho:sirenhead", def().behavior() BehaviorDef, def().families() Set<String>
    public BehaviorState behavior();                     // server only (null on client)
    public void triggerEvent(String event);              // server: behavior().trigger(event)
    public double getProperty(String name);              // synced both sides (0 when unset)
    public void setProperty(String name, double value);  // server
    public boolean isStunned(); public void setStunned(boolean b);     // synced (minecraft:is_stunned)
    public int getVariant(); public void setVariant(int v);            // synced; also markVariant, skinId
    public int getMarkVariant(); public void setMarkVariant(int v); public int getSkinId(); public void setSkinId(int v);
    public boolean hasBedrockTarget();                   // synced flag mirrors getTarget()!=null
    public EntityMolangEnv molang();                     // this entity's MolangEnv for current side
    public java.util.Set<String> families();             // from minecraft:type_family (effective)
    public void setBedrockScale(double s); public double getBedrockScale();   // minecraft:scale
    public void applyBedrockComponents();                // calls BedrockComponents.apply(this)
    public Entity getBedrockTargetEntity();
}
public final class BedrockEntityDef { String id(); BehaviorDef behavior(); ClientEntityDef client() /* null if none or server*/; double hitWidth(), hitHeight(); }
```
Server tick (coordinator): `BedrockComponents.tick(this)`; BP `EntityAnimator.tick(lifeTimeSeconds)` with host → `BedrockCommands.run(level, this, cmd)`.
Client tick/render: RP `EntityAnimator.tick(time)` + pose → GeckoLib bones in `BedrockGeoModel.setCustomAnimations`; particles → `BedrockParticles.spawn`; sounds → `SoundEvent` `sirenhead:<event>`.
