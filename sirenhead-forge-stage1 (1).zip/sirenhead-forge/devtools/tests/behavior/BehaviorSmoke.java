import com.sirenhead.bedrock.BedrockPaths;
import com.sirenhead.bedrock.behavior.*;
import com.sirenhead.bedrock.json.Jsons;
import com.sirenhead.bedrock.molang.MolangEnv;
import com.sirenhead.bedrock.molang.MolangEnvBase;
import com.sirenhead.bedrock.res.DirectoryResourceSource;

import java.util.*;

public class BehaviorSmoke {
    static int fails = 0;
    static void check(boolean c, String m) { if (!c) { fails++; System.out.println("FAIL: " + m); } }

    public static void main(String[] a) {
        DirectoryResourceSource src = new DirectoryResourceSource(java.nio.file.Path.of(a[0]));
        List<String> files = src.list(BedrockPaths.BP + "/entities", ".json");
        Map<String, BehaviorDef> defs = new TreeMap<>();
        for (String f : files) {
            BehaviorDef d = BehaviorDef.parse(Jsons.parseObject(src.readText(f)));
            defs.put(d.identifier(), d);
        }
        System.out.println("BP entities: " + defs.size());
        check(defs.size() == 74, "74 BP entities expected");
        int totalEvents = 0, runs = 0;
        List<String> cmds = new ArrayList<>();
        for (BehaviorDef d : defs.values()) {
            final List<String> myCmds = new ArrayList<>();
            final Random rnd = new Random(1);
            BehaviorHost host = new BehaviorHost() {
                public void onComponentsChanged() {}
                public void runCommand(String c, String t) { myCmds.add(t + ":" + c); }
                public Random random() { return rnd; }
                public FilterContext filterContext(String s) {
                    return (test, dom, arg) -> switch (test) {
                        case "is_family" -> "monster".equals(arg) || "player".equals(arg);
                        case "has_target" -> true;
                        case "target_distance" -> 12.0;
                        case "distance_to_nearest_player" -> 10.0;
                        case "hourly_clock_time" -> 6000.0;
                        case "has_damage" -> true;
                        default -> false;
                    };
                }
                public MolangEnv env() { return new MolangEnvBase() { public Object query(String n, Object[] x) { return 0.0; } }; }
                public void warn(String m) { System.out.println("  warn " + d.identifier() + ": " + m); }
            };
            BehaviorState st = new BehaviorState(d, host);
            st.trigger("minecraft:entity_spawned");
            for (String ev : d.events().keySet()) {
                totalEvents++;
                st.trigger(ev);
                runs++;
                for (String g : st.activeGroups()) check(d.componentGroups().containsKey(g), d.identifier() + " unknown active group " + g);
                st.effectiveComponents();
            }
            String saved = st.saveState();
            BehaviorState st2 = new BehaviorState(d, host);
            st2.loadState(saved);
            check(st2.activeGroups().equals(st.activeGroups()), d.identifier() + " state roundtrip");
            cmds.addAll(myCmds);
        }
        System.out.println("events triggered: " + runs + ", queued commands: " + cmds.size());

        // targeted semantic check: sirenhead spawn
        BehaviorDef sh = defs.get("ho:sirenhead");
        final Random r2 = new Random(3);
        BehaviorState st = new BehaviorState(sh, new BehaviorHost() {
            public void onComponentsChanged() {}
            public void runCommand(String c, String t) { System.out.println("  cmd[" + t + "] " + c); }
            public Random random() { return r2; }
            public FilterContext filterContext(String s) { return (t, d, x) -> false; }
            public MolangEnv env() { return new MolangEnvBase() { public Object query(String n, Object[] x) { return 0.0; } }; }
        });
        st.trigger("minecraft:entity_spawned");
        System.out.println("sirenhead groups after spawn: " + st.activeGroups() + " props=" + st.properties());
        check(st.hasGroup("bd:melee_con"), "spawn adds bd:melee_con");
        System.out.println("timer source: '" + st.sourceOf("minecraft:timer") + "' = " + st.raw("minecraft:timer"));
        st.trigger("bd:choose_attack");
        System.out.println("after choose_attack: " + st.activeGroups() + " bd:melee=" + st.property("bd:melee"));
        check(!st.hasGroup("bd:melee_con") && st.property("bd:melee") > 0, "choose_attack switches group + sets melee");
        System.out.println(fails == 0 ? "ALL OK" : "FAILURES: " + fails);
    }
}
