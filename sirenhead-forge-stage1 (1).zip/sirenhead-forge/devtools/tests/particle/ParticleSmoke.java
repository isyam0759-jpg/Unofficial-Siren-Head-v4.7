import com.sirenhead.bedrock.BedrockPaths;
import com.sirenhead.bedrock.particle.*;
import com.sirenhead.bedrock.res.DirectoryResourceSource;

import java.util.*;

public class ParticleSmoke {
    static int fails = 0;

    static void check(boolean c, String msg) {
        if (!c) {
            fails++;
            System.out.println("FAIL: " + msg);
        }
    }

    public static void main(String[] a) {
        DirectoryResourceSource src = new DirectoryResourceSource(java.nio.file.Path.of(a[0]));
        ParticleLibrary lib = ParticleLibrary.load(src, BedrockPaths.RP);
        System.out.println("particles=" + lib.ids().size() + " errors=" + lib.errors());
        check(lib.ids().size() == 69, "expected 69 defs");
        ParticleWorld ground = new ParticleWorld() {
            public String blockId(int x, int y, int z) { return y < 64 ? "minecraft:stone" : "minecraft:air"; }
            public boolean isSolid(int x, int y, int z) { return y < 64; }
        };
        int maxAlive = 0; String maxId = "";
        for (String id : lib.ids()) {
            ParticleDef d = lib.get(id);
            ParticleEmitter e = new ParticleEmitter(d, Map.of("variable.size", 3.0), 42L, ground);
            int peak = 0, spawnedTotalSeen = 0; double t = 0;
            boolean bad = false;
            for (int i = 0; i < 200 && !e.isDone(); i++) {
                e.setTransform(10 + i * 0.01, 66, 10, 30);
                e.tick(0.05);
                t += 0.05;
                if (i == 80) e.stop();
                peak = Math.max(peak, e.particles().size());
                for (Particle p : e.particles()) {
                    double[] v = {p.wx, p.wy, p.wz, p.sizeX, p.sizeY, p.u0, p.v0, p.u1, p.v1, p.r, p.g, p.b, p.a, p.rotDeg, p.dirX, p.dirY, p.dirZ};
                    for (double x : v) if (Double.isNaN(x) || Double.isInfinite(x)) bad = true;
                }
            }
            check(!bad, id + " produced NaN/inf");
            check(e.isDone(), id + " never finished (t=" + t + ", alive=" + e.particles().size() + ")");
            if (peak > maxAlive) { maxAlive = peak; maxId = id; }
            if (peak == 0) System.out.println("  note: " + id + " never had live particles");
        }
        System.out.println("peak alive in one emitter: " + maxAlive + " (" + maxId + ")");

        // ---- curves
        ParticleDef bs = lib.get("bd:bul_smoke");
        ParticleEmitter e = new ParticleEmitter(bs, null, 1L, null);
        e.setTransform(0, 0, 0, 0);
        e.tick(0.05);
        check(e.particles().size() == 10, "bul_smoke instant 10 got " + e.particles().size());
        Particle p0 = e.particles().get(0);
        check(p0.a < 0.1, "bul_smoke starts transparent: " + p0.a);
        for (int i = 0; i < 18; i++) e.tick(0.05); // 0.95 s
        boolean found = false;
        for (Particle p : e.particles()) if (p.age > 0.9) { found = true; check(p.a > 0.85, "bul_smoke alpha near age 0.49*life: " + p.a + " age=" + p.age); }
        System.out.println("bul_smoke mid-life particle seen: " + found);

        // ---- flipbook (attack.json: 8 frames stretched to lifetime)
        ParticleDef atk = lib.ids().stream().map(lib::get).filter(x -> x.identifier().endsWith(":attack")).findFirst().orElse(null);
        check(atk != null, "attack particle present");
        if (atk != null) {
            ParticleEmitter ae = new ParticleEmitter(atk, null, 7L, ground);
            ae.setTransform(0, 70, 0, 0);
            ae.tick(0.05);
            Particle q = ae.particles().get(0);
            check(Math.abs(q.u0 - 56f / 128f) < 1e-5 && Math.abs(q.u1 - 64f / 128f) < 1e-5, "attack frame0 uv " + q.u0 + ".." + q.u1);
            while (q.age < q.lifetime * 0.5 && !q.dead) ae.tick(0.05);
            System.out.println("attack mid uv u0=" + q.u0 + " (frame " + Math.round((56 - q.u0 * 128) / 8) + ")");
        }

        // ---- billboard maths
        double[] cam = {0, 0, 0}, R = {1, 0, 0}, U = {0, 1, 0}, F = {0, 0, 1};
        for (ParticleDef.Facing f : ParticleDef.Facing.values()) {
            double[] ax = new double[3], ay = new double[3];
            BillboardMath.axes(f, cam, R, U, F, 3, 2, 8, new double[]{0.3 / Math.sqrt(0.98), 0.8 / Math.sqrt(0.98), 0.5 / Math.sqrt(0.98)}, Math.cos(0.7), Math.sin(0.7), 25, ax, ay);
            double la = Math.sqrt(ax[0] * ax[0] + ax[1] * ax[1] + ax[2] * ax[2]);
            double lb = Math.sqrt(ay[0] * ay[0] + ay[1] * ay[1] + ay[2] * ay[2]);
            double dt = ax[0] * ay[0] + ax[1] * ay[1] + ax[2] * ay[2];
            check(Math.abs(la - 1) < 1e-6 && Math.abs(lb - 1) < 1e-6 && Math.abs(dt) < 1e-6, f + " axes not orthonormal " + la + " " + lb + " " + dt);
        }
        System.out.println(fails == 0 ? "ALL OK" : ("FAILURES: " + fails));
    }
}
