import com.google.gson.*;
import com.sirenhead.bedrock.BedrockPaths;
import com.sirenhead.bedrock.anim.*;
import com.sirenhead.bedrock.json.Jsons;
import com.sirenhead.bedrock.molang.*;
import com.sirenhead.bedrock.res.*;
import java.nio.file.*;
import java.util.*;

public class AnimSmoke {
    static class Env extends MolangEnvBase {
        Map<String, Double> props = new HashMap<>();
        Map<String, Double> q = new HashMap<>();
        double life;
        @Override public Object query(String n, Object[] a) {
            switch (n) {
                case "property": return props.getOrDefault(String.valueOf(a[0]), 0.0);
                case "life_time": return life;
                default: return q.getOrDefault(n, 0.0);
            }
        }
    }
    static class Host implements AnimationHost {
        Env env = new Env();
        List<String> cmds = new ArrayList<>(), parts = new ArrayList<>(), sounds = new ArrayList<>();
        public MolangEnv env() { return env; }
        public void command(String c) { cmds.add(c); }
        public void particle(String e, String l, String p) { parts.add(e + "@" + l); }
        public void sound(String s) { sounds.add(s); }
    }
    static int bad = 0;
    static void check(boolean ok, String msg) { if (!ok) { bad++; System.out.println("FAIL: " + msg); } }

    public static void main(String[] a) throws Exception {
        ResourceSource src = new DirectoryResourceSource(Path.of(a[0]));
        BedrockAnimLibrary rp = BedrockAnimLibrary.load(src, BedrockPaths.RP);
        BedrockAnimLibrary bp = BedrockAnimLibrary.load(src, BedrockPaths.BP);
        System.out.println("RP: anims=" + rp.animations().size() + " ctrls=" + rp.controllers().size() + " entities=" + rp.clientEntities().size() + " rc=" + rp.renderControllers().size());
        System.out.println("BP: anims=" + bp.animations().size() + " ctrls=" + bp.controllers().size());
        System.out.println("RP warnings: " + rp.warnings());
        check(rp.warnings().isEmpty() && bp.warnings().isEmpty(), "library warnings");

        // every client entity: animate for 6 simulated seconds under varying inputs
        int total = 0, events = 0;
        for (ClientEntityDef d : rp.clientEntities().values()) {
            Host h = new Host();
            EntityAnimator an = new EntityAnimator(rp, d.animations(), d.animate(), d.preAnimation(), true, h);
            for (int t = 0; t < 120; t++) {
                h.env.life = t / 20.0;
                h.env.q.put("modified_move_speed", t % 40 < 20 ? 0.0 : 0.3);
                h.env.props.put("bd:melee", (double) ((t / 20) % 4));
                an.tick(t / 20.0);
                for (Pose.Bone b : an.pose().bones().values())
                    for (int i = 0; i < 3; i++) check(Double.isFinite(b.rot[i]) && Double.isFinite(b.pos[i]) && Double.isFinite(b.scale[i]), d.identifier() + " NaN in pose");
            }
            total++; events += h.parts.size() + h.sounds.size();
        }
        System.out.println("animated " + total + " client entities, effect events=" + events);

        // siren head: melee property drives the general controller state
        ClientEntityDef sd = rp.clientEntity("ho:sirenhead");
        check(sd != null, "ho:sirenhead client def");
        Host h = new Host();
        EntityAnimator an = new EntityAnimator(rp, sd.animations(), sd.animate(), sd.preAnimation(), true, h);
        for (int t = 0; t < 10; t++) { h.env.life = t / 20.0; an.tick(t / 20.0); }
        System.out.println("idle states: " + an.activeStates());
        h.env.props.put("bd:melee", 1.0);
        for (int t = 10; t < 30; t++) { h.env.life = t / 20.0; an.tick(t / 20.0); }
        System.out.println("melee=1 states: " + an.activeStates() + " bones=" + an.pose().bones().size() + " sounds=" + h.sounds + " particles=" + h.parts);

        // render controller resolution
        ClientEntityDef od = rp.clientEntity("ho:originalsirenhead");
        for (String rc : od.renderControllers()) {
            RenderControllerDef r = rp.renderController(rc);
            check(r != null, "rc " + rc);
            Env e = new Env();
            e.q.put("skin_id", 1.0);
            System.out.println("render choice skin_id=1: " + r.resolve(e, od));
        }

        // BP animators (server side, no pose): run each BP entity's animate list
        int bpCount = 0;
        for (String p : src.list(BedrockPaths.BP + "/entities", ".json")) {
            JsonObject root = Jsons.parseObject(src.readText(p));
            JsonObject desc = Jsons.obj(Jsons.obj(root, "minecraft:entity"), "description");
            if (desc == null) continue;
            Map<String, String> anims = new LinkedHashMap<>();
            JsonObject ao = Jsons.obj(desc, "animations");
            if (ao != null) for (var e : ao.entrySet()) anims.put(e.getKey(), e.getValue().getAsString());
            JsonObject sc = Jsons.obj(desc, "scripts");
            if (sc == null) continue;
            Host bh = new Host();
            EntityAnimator ban = new EntityAnimator(bp, anims, EntityAnimator.parseAnimate(sc.get("animate")), EntityAnimator.parseScriptList(sc.get("pre_animation")), false, bh);
            for (int t = 0; t < 200; t++) {
                bh.env.life = t / 20.0;
                bh.env.props.put("bd:melee", (double) ((t / 30) % 7));
                ban.tick(t / 20.0);
            }
            bpCount++;
            if (p.endsWith("tower_head.json")) System.out.println("tower_head BP: states=" + ban.activeStates() + " cmds=" + bh.cmds.size() + " first=" + bh.cmds.subList(0, Math.min(4, bh.cmds.size())));
        }
        System.out.println("ran " + bpCount + " BP entity animators");

        // Rig + locators
        Rig rig = Rig.parse(Files.readString(Path.of(a[0], "assets/sirenhead/geo/siren_head_bd.geo.json")));
        double[] dust = rig.locator("dust", null);
        double[] step = rig.locator("step", null);
        System.out.println("locators dust=" + Arrays.toString(dust) + " step=" + Arrays.toString(step) + " bones=" + rig.boneNames().size());
        check(dust != null && step != null, "locators");
        System.out.println(bad == 0 ? "ALL OK" : "FAILURES: " + bad);
    }
}
