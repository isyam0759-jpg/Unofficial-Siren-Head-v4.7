import com.sirenhead.bedrock.command.*;
import java.nio.file.*;
import java.util.*;

public class CommandSmoke {
    static int fails = 0;
    static void check(boolean ok, String msg) { if (!ok) { fails++; System.out.println("FAIL: " + msg); } }
    static void near(double a, double b, String msg) { check(Math.abs(a - b) < 1e-6, msg + " got " + a + " want " + b); }

    static class M implements Selector.Target {
        String type, name = "m"; boolean player; Set<String> fam = new HashSet<>(), tags = new HashSet<>(); int gm = -1;
        double x, y, z; Map<String, Integer> sc = new HashMap<>();
        M(String type, double x, double y, double z) { this.type = type; this.x = x; this.y = y; this.z = z; this.player = type.equals("player"); if (player) gm = 0; }
        public boolean isPlayer() { return player; }
        public boolean isType(String t) { return type.equals(t); }
        public boolean inFamily(String f) { return fam.contains(f); }
        public boolean hasTag(String t) { return tags.contains(t); }
        public String name() { return name; }
        public int gameMode() { return gm; }
        public Integer score(String o) { return sc.get(o); }
        public double x() { return x; } public double y() { return y; } public double z() { return z; }
        public double width() { return 0.6; } public double height() { return 1.8; }
        public double yaw() { return 0; } public double pitch() { return 0; }
        public int xpLevel() { return 0; }
    }

    public static void main(String[] a) throws Exception {
        // ---- every command of the addon must tokenize/parse
        int n = 0, exec = 0;
        for (String line : Files.readAllLines(Paths.get("devtools/tests/command/all_commands.txt"))) {
            line = line.trim();
            if (line.isEmpty()) continue;
            List<String> t = Lex.tokens(line);
            n++;
            try {
                if (t.get(0).equals("execute")) {
                    ExecChain c = ExecChain.parse(t);
                    exec++;
                    check(c.run != null && !c.run.isEmpty(), "execute without run: " + line);
                    for (ExecChain.Stage s : c.stages) {
                        if (s.kind == ExecChain.Kind.AS || s.kind == ExecChain.Kind.AT || s.kind == ExecChain.Kind.IF_ENTITY) Selector.parse(s.sel);
                    }
                    // the nested command must itself parse when it is an execute
                    List<String> inner = Lex.tokens(c.run);
                    if (inner.get(0).equals("execute")) ExecChain.parse(inner);
                }
                for (String tok : t) if (tok.startsWith("@")) Selector.parse(tok);
            } catch (RuntimeException e) {
                fails++;
                System.out.println("PARSE FAIL: " + line + " -> " + e);
            }
        }
        System.out.println("parsed " + n + " commands (" + exec + " execute)");

        // ---- tokenizer
        check(Lex.tokens("execute @e [scores={respawn=1}] at @s run camera @s clear").get(1).equals("@e[scores={respawn=1}]"), "glue selector");
        check(Lex.tokens("say Hello @p you").size() == 4, "say tokens");

        // ---- coordinates
        List<Pos.Coord> cs = Pos.parseToken("~~0.2~");
        check(cs.size() == 3 && cs.get(1).v == 0.2 && cs.get(0).kind == '~', "~~0.2~");
        cs = Pos.parseToken("^^0.5^1");
        check(cs.size() == 3 && cs.get(1).v == 0.5 && cs.get(2).v == 1 && cs.get(2).kind == '^', "^^0.5^1");
        cs = Pos.parseToken("~999999999999999~-99999999~999999999999999999");
        check(cs.size() == 3 && cs.get(1).v == -99999999, "huge");
        double[] r = Pos.parseOne("^^^10").resolve(0, 0, 0, 0, 0);        // yaw 0 faces +z
        near(r[0], 0, "fwd x"); near(r[1], 0, "fwd y"); near(r[2], 10, "fwd z");
        r = Pos.parseOne("^^^10").resolve(0, 0, 0, 90, 0);                // yaw 90 faces -x
        near(r[0], -10, "yaw90 x"); near(r[2], 0, "yaw90 z");
        r = Pos.parseOne("^1^^").resolve(0, 0, 0, 0, 0);                   // left of a +z facing entity is +x
        near(r[0], 1, "left x");
        r = Pos.parseOne("^^2^").resolve(5, 5, 5, 123, 0);
        near(r[1], 7, "up with pitch only along up axis when pitch=0? (y) " );
        r = Pos.parseOne("~1 ~ ~-2").resolve(10, 20, 30, 0, 0);
        near(r[0], 11, "rel x"); near(r[2], 28, "rel z");

        // ---- selectors
        M cat = new M("ho:cartoon_cat", 0, 0, 0); cat.fam.add("siren_head");
        M hand = new M("bd:cartoon_hand", 1, 0, 0);
        M cow = new M("cow", 3, 0, 0); cow.fam.add("mob");
        M p1 = new M("player", 2, 0, 0); p1.gm = 1;
        M p2 = new M("player", 10, 0, 0); p2.name = "Bob"; p2.tags.add("target");
        List<M> all = List.of(cat, hand, cow, p1, p2);
        Random rng = new Random(1);
        check(Selector.parse("@e[type=ho:cartoon_cat]").select(all, 0, 0, 0, null, rng).equals(List.of(cat)), "type");
        check(Selector.parse("@e[type=!player,type=!ho:cartoon_cat,r=5]").select(all, 0, 0, 0, null, rng).size() == 2, "neg types + r");
        check(Selector.parse("@e[family=!siren_head,r=5,c=1]").select(all, 0, 0, 0, null, rng).get(0) == hand, "nearest non-siren");
        check(Selector.parse("@e[family=!siren_head,r=5,c=-1]").select(all, 0, 0, 0, null, rng).get(0) == p1 || true, "farthest");
        check(Selector.parse("@e[family=!siren_head,r=5,c=-1]").select(all, 0, 0, 0, null, rng).get(0) == cow, "farthest is cow");
        check(Selector.parse("@a[m=c]").select(all, 0, 0, 0, null, rng).equals(List.of(p1)), "gamemode creative");
        check(Selector.parse("@a[m=!c]").select(all, 0, 0, 0, null, rng).equals(List.of(p2)), "gamemode not creative");
        check(Selector.parse("@p").select(all, 0, 0, 0, null, rng).equals(List.of(p1)), "@p nearest");
        check(Selector.parse("@p[tag=target]").select(all, 0, 0, 0, null, rng).equals(List.of(p2)), "@p tag");
        check(Selector.parse("@a[rm=5,r=12]").select(all, 0, 0, 0, null, rng).equals(List.of(p2)), "rm/r ring");
        p2.sc.put("siren_stun", 3); p2.sc.put("siren_stunned", 2);
        check(Selector.parse("@a[scores={siren_stun=3,siren_stunned=2}]").select(all, 0, 0, 0, null, rng).equals(List.of(p2)), "scores");
        check(Selector.parse("@a[scores={siren_stun=1..2}]").select(all, 0, 0, 0, null, rng).isEmpty(), "score range miss");
        check(Selector.parse("@a[scores={siren_stun=2..}]").select(all, 0, 0, 0, null, rng).equals(List.of(p2)), "score open range");
        check(Selector.parse("@e[type=minecraft:cow]").select(all, 0, 0, 0, null, rng).equals(List.of(cow)), "minecraft: prefix");
        check(Selector.parse("@s").select(all, 0, 0, 0, cat, rng).equals(List.of(cat)), "@s");
        check(Selector.parse("@s[type=cow]").select(all, 0, 0, 0, cat, rng).isEmpty(), "@s filtered");
        check(Selector.parse("Bob").select(all, 0, 0, 0, null, rng).equals(List.of(p2)), "player name");
        p1.y = -5;
        check(Selector.parse("@a[m=c,x=~,z=~,y=0,dy=-10000]").select(all, 2, 0, 0, null, rng).equals(List.of(p1)), "volume below y=0");
        // ---- ranges
        check(Selector.Range.parse("..5").test(-100) && !Selector.Range.parse("..5").test(6), "range ..5");
        check(Selector.Range.parse("!3").test(4) && !Selector.Range.parse("!3").test(3), "range !3");

        // ---- execute chains
        ExecChain c = ExecChain.parse(Lex.tokens("execute as @s at @s positioned ^^^10 rotated ~ 0 run tag @a[m=!c,tag=!siren_ride,c=1,r=10] add siren_ride"));
        check(c.stages.size() == 4 && c.run.startsWith("tag @a"), "modern chain: " + c.stages.size());
        c = ExecChain.parse(Lex.tokens("execute @a ~~~ execute @e[type=ho:cartoon_cat,c=1] ~~~ detect ~~-1~ leaves 0 say hi there"));
        check(c.run.startsWith("execute @e") && c.stages.size() == 3, "legacy outer");
        c = ExecChain.parse(Lex.tokens(c.run));
        check(c.stages.get(3).kind == ExecChain.Kind.IF_BLOCK && c.run.equals("say hi there"), "legacy detect");
        c = ExecChain.parse(Lex.tokens("execute unless block ^^^0.35 air run function sirenhead/sonic_blast/hit"));
        check(c.stages.get(0).negate && c.stages.get(0).sel.equals("air") && c.run.equals("function sirenhead/sonic_blast/hit"), "unless block");
        c = ExecChain.parse(Lex.tokens("execute if score @s sound_wave matches 1 rotated ~ 0 run summon ho:siren_tar ^30^1^20 ~~"));
        check(c.stages.get(0).kind == ExecChain.Kind.IF_SCORE_MATCHES && c.stages.get(0).range.test(1) && c.stages.size() == 2, "score matches");
        c = ExecChain.parse(Lex.tokens("execute as @s at @s anchored eyes run function sirenhead/sonic_blast/loop"));
        check(c.stages.get(2).kind == ExecChain.Kind.ANCHORED && c.stages.get(2).sel.equals("eyes"), "anchored");

        System.out.println(fails == 0 ? "ALL OK" : fails + " FAILURES");
        if (fails > 0) System.exit(1);
    }
}
