event entity @s bd:set_target
scoreboard objectives add sound_wave dummy
scoreboard players random @s sound_wave 0 2
execute if score @s sound_wave matches 0 rotated ~ 0 run summon ho:siren_tar ~~~ ~~
execute if score @s sound_wave matches 1 rotated ~ 0 run summon ho:siren_tar ^30^1^20 ~~
execute if score @s sound_wave matches 2 rotated ~ 0 run summon ho:siren_tar ^-30^1^20 ~~