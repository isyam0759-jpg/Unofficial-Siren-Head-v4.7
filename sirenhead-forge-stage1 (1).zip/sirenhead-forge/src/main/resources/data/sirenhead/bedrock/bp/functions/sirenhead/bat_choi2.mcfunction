effect @s resistance 7 5 true
playanimation @p[m=!c,tag=siren_ride,r=10] animation.siren_head_bd.picking_p a 0
playanimation @e[family=illager,c=1,r=10] animation.siren_head_bd.picking_e a 0
playanimation @e[family=irongolem,c=1,r=10] animation.siren_head_bd.picking_e2 a 0
playanimation @e[family=undead,c=1,r=10] animation.siren_head_bd.picking_p a 0
playanimation @e[family=soulless_knight,c=1,r=10] animation.siren_head_bd.picking_e3 a 0
execute as @s at @s if entity @a[tag=siren_ride,m=!c,r=10,c=1] run ride @a[tag=siren_ride,m=!c,r=10,c=1] start_riding @s teleport_rider until_full
execute as @s at @s if entity @e[family=illager,r=10,c=1] run ride @e[family=illager,r=10,c=1] start_riding @s teleport_rider until_full
execute as @s at @s if entity @e[family=irongolem,r=10,c=1] run ride @e[family=irongolem,r=10,c=1] start_riding @s teleport_rider until_full
execute as @s at @s if entity @a[tag=siren_ride,m=!c,r=10,c=1] run inputpermission set @a[m=!c,tag=siren_ride,c=1,r=10] movement disabled
execute as @s at @s if entity @a[tag=siren_ride,m=!c,r=10,c=1] run inputpermission set @a[m=!c,tag=siren_ride,c=1,r=10] camera disabled
execute as @s at @s rotated ~ 0 run camera @a[m=!c,r=10,c=1] set minecraft:free pos ^5^7^10 facing @s
tp @s ~~~ ~~