execute unless block ^^^0.35 air run function sirenhead/sonic_blast/hit
execute positioned ^^^0.35 if block ~~~ air run function sirenhead/sonic_blast/loop

particle bd:sound_wave2 ~~~
damage @e[family=!siren_head,r=5] 10 magic entity @s