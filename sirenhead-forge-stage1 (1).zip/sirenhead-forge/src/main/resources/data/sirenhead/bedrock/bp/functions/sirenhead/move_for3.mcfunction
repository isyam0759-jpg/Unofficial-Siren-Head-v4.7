execute as @s at @s run tp @s ^0.1^^ facing @e[family=siren_head,c=1]
execute as @s at @s run tp @s ^0.1^^ facing @e[family=siren_head,c=1]
execute as @s at @s run tp @s ^0.1^^ facing @e[family=siren_head,c=1]