execute as @s at @s rotated ~ 0 positioned ^^^5 anchored feet run camerashake add @a[r=30] 1 1.2 positional
execute as @s at @s rotated ~ 0 positioned ^4^^5 anchored feet run summon ho:slam_down ~~~
execute as @s at @s rotated ~ 0 positioned ^-4^^5 anchored feet run summon ho:slam_down ~~~
execute as @s at @s rotated ~ 0 positioned ^^^5 anchored feet run particle bd:ground_damage ~~0.1~
execute as @s at @s rotated ~ 0 positioned ^^^5 anchored feet run particle bd:siren_dust_up ~~0.1~
execute as @s at @s rotated ~ 0 positioned ^4^^5 anchored feet run particle bd:siren_range2 ~~0.1~
execute as @s at @s rotated ~ 0 positioned ^-4^^5 anchored feet run particle bd:siren_range2 ~~0.1~
execute as @s at @s rotated ~ 0 positioned ^4^^5 anchored feet run particle bd:earth_claw2 ~~0.1~
execute as @s at @s rotated ~ 0 positioned ^-4^^5 anchored feet run particle bd:earth_claw2 ~~0.1~