particle bd:siren_dust ~~0.1~
particle bd:earth_claw2 ~~0.1~