tp @s ^^^0.1 true
tp @s ^^^0.1 true
tp @s ^^^0.1 true