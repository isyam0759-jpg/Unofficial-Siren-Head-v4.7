execute as @s at @s positioned ^^^10 rotated ~ 0 run tag @a[m=!c,tag=!siren_ride,c=1,r=10] add siren_ride
execute as @s at @s positioned ^^^10 rotated ~ 0 run tp @p[tag=siren_ride,m=!c,r=10] ~~~ ~~
execute as @s at @s positioned ^^^10 rotated ~ 0 run inputpermission set @a[m=!c,tag=siren_ride,c=1,r=10] movement disabled
execute as @s at @s positioned ^^^10 rotated ~ 0 run inputpermission set @a[m=!c,tag=siren_ride,c=1,r=10] camera disabled
execute as @s at @s positioned ^^^10 rotated ~ 0 run ride @p[tag=siren_ride,m=!c,r=10] start_riding @s teleport_rider until_full
execute as @s at @s if entity @e[family=illager,r=10,c=1] run ride @e[family=illager,r=10,c=1] start_riding @s teleport_rider until_full
execute as @s at @s if entity @e[family=irongolem,r=10,c=1] run ride @e[family=irongolem,r=10,c=1] start_riding @s teleport_rider until_full
execute as @s at @s if entity @e[family=soulless_knight,r=10,c=1] run ride @e[family=soulless_knight,r=10,c=1] start_riding @s teleport_rider until_full
tp @s ~~~ ~~