execute as @e [scores={respawn=1}] at @s run inputpermission set @s camera enabled
execute as @e [scores={respawn=1}] at @s run inputpermission set @s movement enabled
execute as @e [scores={respawn=1}] at @s run camera @s clear


scoreboard players set @a respawn 1
scoreboard players set @e [type=player] respawn 0