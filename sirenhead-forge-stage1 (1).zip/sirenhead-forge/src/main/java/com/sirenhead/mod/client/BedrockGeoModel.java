package com.sirenhead.mod.client;

import com.sirenhead.bedrock.anim.Pose;
import com.sirenhead.bedrock.anim.RenderControllerDef;
import com.sirenhead.mod.BedrockLibraries;
import com.sirenhead.mod.SirenHeadMod;
import com.sirenhead.mod.entity.BedrockEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.core.animatable.model.CoreGeoBone;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.model.GeoModel;

import java.util.HashMap;
import java.util.Map;

/**
 * GeckoLib model used for every add-on entity. The geometry and texture come from the Bedrock render controller of the
 * entity (resolved every frame), the bone transforms from the Bedrock animation runtime ({@link ClientEntityState}).
 * GeckoLib's own animation controllers are not used.
 */
public class BedrockGeoModel extends GeoModel<BedrockEntity> {
    /**
     * Calibration constants. Bedrock rotates/moves bones in the same frame that the geometry is authored in, GeckoLib
     * bakes the bone rotation as (-x, -y, +z) and mirrors X on render. If an animation looks mirrored in game, flip the
     * matching sign here.
     */
    static final float ROT_X = -1f, ROT_Y = -1f, ROT_Z = 1f;
    static final float POS_X = 1f, POS_Y = 1f, POS_Z = 1f;

    private static final ResourceLocation NO_ANIMATION = new ResourceLocation(SirenHeadMod.MOD_ID, "animations/none.animation.json");
    private static final ResourceLocation MISSING_GEO = new ResourceLocation(SirenHeadMod.MOD_ID, "geo/_missing.geo.json");
    private static final ResourceLocation MISSING_TEXTURE = new ResourceLocation("minecraft", "textures/misc/white.png");
    private static final Map<String, ResourceLocation> TEXTURES = new HashMap<>();

    @Override
    public ResourceLocation getModelResource(BedrockEntity entity) {
        RenderControllerDef.Choice c = ClientEntityState.of(entity).choice();
        if (c != null && c.geometryId() != null) {
            String res = BedrockLibraries.geoResource(c.geometryId());
            if (res != null) return new ResourceLocation(res);
        }
        return MISSING_GEO;
    }

    @Override
    public ResourceLocation getTextureResource(BedrockEntity entity) {
        RenderControllerDef.Choice c = ClientEntityState.of(entity).choice();
        if (c == null || c.texturePath() == null) return MISSING_TEXTURE;
        return TEXTURES.computeIfAbsent(c.texturePath(), p -> {
            String path = p.startsWith("textures/") ? p : "textures/" + p;
            if (!path.endsWith(".png")) path = path + ".png";
            return new ResourceLocation(SirenHeadMod.MOD_ID, path);
        });
    }

    @Override
    public ResourceLocation getAnimationResource(BedrockEntity entity) {
        return NO_ANIMATION;
    }

    @Override
    public void setCustomAnimations(BedrockEntity entity, long instanceId, AnimationState<BedrockEntity> animationState) {
        ClientEntityState cs = ClientEntityState.of(entity);
        Pose pose = cs.animator() == null ? null : cs.animator().pose();
        for (CoreGeoBone bone : getAnimationProcessor().getRegisteredBones()) {
            var init = bone.getInitialSnapshot();
            Pose.Bone pb = pose == null ? null : pose.peek(bone.getName());
            if (pb == null || !pb.touched) {
                bone.setRotX(init.getRotX());
                bone.setRotY(init.getRotY());
                bone.setRotZ(init.getRotZ());
                bone.setPosX(init.getOffsetX());
                bone.setPosY(init.getOffsetY());
                bone.setPosZ(init.getOffsetZ());
                bone.setScaleX(init.getScaleX());
                bone.setScaleY(init.getScaleY());
                bone.setScaleZ(init.getScaleZ());
                continue;
            }
            bone.setRotX(init.getRotX() + ROT_X * (float) Math.toRadians(pb.rot[0]));
            bone.setRotY(init.getRotY() + ROT_Y * (float) Math.toRadians(pb.rot[1]));
            bone.setRotZ(init.getRotZ() + ROT_Z * (float) Math.toRadians(pb.rot[2]));
            bone.setPosX(init.getOffsetX() + POS_X * (float) pb.pos[0]);
            bone.setPosY(init.getOffsetY() + POS_Y * (float) pb.pos[1]);
            bone.setPosZ(init.getOffsetZ() + POS_Z * (float) pb.pos[2]);
            bone.setScaleX(init.getScaleX() * (float) pb.scale[0]);
            bone.setScaleY(init.getScaleY() * (float) pb.scale[1]);
            bone.setScaleZ(init.getScaleZ() * (float) pb.scale[2]);
        }
    }
}
