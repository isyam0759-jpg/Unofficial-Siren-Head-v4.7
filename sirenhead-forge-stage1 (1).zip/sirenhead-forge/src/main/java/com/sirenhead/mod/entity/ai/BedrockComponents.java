package com.sirenhead.mod.entity.ai;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sirenhead.bedrock.behavior.BehaviorState;
import com.sirenhead.bedrock.behavior.Filters;
import com.sirenhead.bedrock.json.Jsons;
import com.sirenhead.mod.entity.BedrockEntity;
import com.sirenhead.mod.server.command.BedrockSpawn;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.BreakDoorGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MoveTowardsRestrictionGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Applies the effective Bedrock components of a {@link BedrockEntity} to Java (attributes, goals, synced flags) and runs the
 * ones that are time driven (timers, sensors, spawn_entity, despawn, explode, projectile, ...).
 */
public final class BedrockComponents {
    private BedrockComponents() {
    }

    /** Runtime state of the active components. Only used on the server. */
    public static final class State {
        public final Set<String> families = new HashSet<>();
        public int seatCount = 1;
        public boolean healthApplied;
        public double minHealth;
        public int changeCounter;
        final Map<String, double[]> rt = new HashMap<>();
        final List<Goal> goals = new ArrayList<>();
        final List<Goal> targetGoals = new ArrayList<>();
        boolean launched;
        int hitCooldown;
    }

    // =================================================================== helpers

    private static double num(JsonObject o, String k, double def) {
        return o == null ? def : Jsons.num(o, k, def);
    }

    /** {@code 5}, {@code {"range_min":1,"range_max":3}} or {@code [1,3]} -> a representative number (max). */
    private static double numOrRange(JsonElement e, double def) {
        if (e == null || e.isJsonNull()) return def;
        if (e.isJsonPrimitive()) {
            try {
                return e.getAsDouble();
            } catch (RuntimeException ex) {
                return def;
            }
        }
        if (e.isJsonObject()) return Jsons.num(e.getAsJsonObject(), "range_max", Jsons.num(e.getAsJsonObject(), "value", def));
        if (e.isJsonArray() && e.getAsJsonArray().size() > 0) return e.getAsJsonArray().get(e.getAsJsonArray().size() - 1).getAsDouble();
        return def;
    }

    private static String baseKey(BehaviorState b, String name) {
        String src = b.sourceOf(name);
        if (src == null) src = "";
        return name + "@" + src + "#" + (src.isEmpty() ? 0 : b.generation(src));
    }

    private static void setBase(BedrockEntity e, net.minecraft.world.entity.ai.attributes.Attribute a, double v) {
        var inst = e.getAttribute(a);
        if (inst != null && inst.getBaseValue() != v) inst.setBaseValue(v);
    }

    private static void fire(BedrockEntity e, JsonElement spec, List<Runnable> out) {
        if (spec == null || spec.isJsonNull()) return;
        final String event;
        final String target;
        if (spec.isJsonPrimitive()) {
            event = spec.getAsString();
            target = "self";
        } else if (spec.isJsonObject()) {
            event = Jsons.str(spec.getAsJsonObject(), "event", null);
            target = Jsons.str(spec.getAsJsonObject(), "target", "self");
        } else return;
        if (event == null || event.isEmpty()) return;
        out.add(() -> {
            if (target.equals("self")) e.triggerEvent(event);
            else if (target.equals("target") && e.getTarget() instanceof BedrockEntity bt) bt.triggerEvent(event, e);
            else if (target.equals("parent") && e.getVehicle() instanceof BedrockEntity bv) bv.triggerEvent(event, e);
        });
    }

    // =================================================================== apply (when the active groups change)

    public static void apply(BedrockEntity e) {
        BehaviorState b = e.behavior();
        if (b == null) return;
        State st = e.comp;
        st.changeCounter++;

        // ---- family
        st.families.clear();
        JsonObject tf = b.component("minecraft:type_family");
        if (tf != null && tf.has("family") && tf.get("family").isJsonArray()) for (JsonElement x : tf.getAsJsonArray("family")) st.families.add(x.getAsString());

        // ---- attributes
        JsonObject h = b.component("minecraft:health");
        if (h != null) {
            double v = numOrRange(h.get("value"), 20);
            e.healthScale = Math.max(1.0, v / 1024.0);
            setBase(e, Attributes.MAX_HEALTH, Math.min(v, 1024.0));
            st.minHealth = num(h, "min", 0);
            if (!st.healthApplied) {
                st.healthApplied = true;
                e.setHealth(e.getMaxHealth());
            }
        }
        JsonObject mv = b.component("minecraft:movement");
        if (mv != null) setBase(e, Attributes.MOVEMENT_SPEED, numOrRange(mv.get("value"), 0.25));
        JsonObject kb = b.component("minecraft:knockback_resistance");
        if (kb != null) setBase(e, Attributes.KNOCKBACK_RESISTANCE, Math.max(0, Math.min(1, num(kb, "value", 0))));
        JsonObject fr = b.component("minecraft:follow_range");
        if (fr != null) setBase(e, Attributes.FOLLOW_RANGE, Math.min(2048, num(fr, "value", 16)));
        JsonObject at = b.component("minecraft:attack");
        if (at != null) setBase(e, Attributes.ATTACK_DAMAGE, numOrRange(at.get("damage"), 0));
        JsonObject step = b.component("minecraft:variable_max_auto_step");
        if (step != null) e.setMaxUpStep((float) num(step, "base_value", 0.5625));

        // ---- cosmetic / synced
        JsonObject sc = b.component("minecraft:scale");
        if (sc != null && !b.has("minecraft:scale_by_age")) e.setBedrockScale((float) num(sc, "value", 1));
        JsonObject var = b.component("minecraft:variant");
        e.setVariant(var == null ? 0 : (int) num(var, "value", 0));
        JsonObject mark = b.component("minecraft:mark_variant");
        e.setMarkVariant(mark == null ? 0 : (int) num(mark, "value", 0));
        JsonObject skin = b.component("minecraft:skin_id");
        e.setSkinId(skin == null ? 0 : (int) num(skin, "value", 0));
        e.setFlag(BedrockEntity.F_STUNNED, b.has("minecraft:is_stunned"));
        JsonObject pu = b.component("minecraft:pushable");
        e.pushableFlag = pu == null || Jsons.bool(pu, "is_pushable", true);

        // ---- rideable
        JsonObject rd = b.component("minecraft:rideable");
        if (rd != null) {
            st.seatCount = (int) num(rd, "seat_count", 1);
            double x = 0, y = 0, z = 0;
            JsonArray seats = Jsons.arr(rd, "seats");
            if (seats != null && seats.size() > 0 && seats.get(0).isJsonObject()) {
                JsonArray p = Jsons.arr(seats.get(0).getAsJsonObject(), "position");
                if (p != null && p.size() >= 3) {
                    x = p.get(0).getAsDouble();
                    y = p.get(1).getAsDouble();
                    z = p.get(2).getAsDouble();
                }
            }
            e.setSeat(true, (float) x, (float) y, (float) z);
        } else {
            e.setSeat(false, 0, 0, 0);
        }

        // ---- navigation
        JsonObject nav = b.component("minecraft:navigation.walk");
        if (nav == null) nav = b.component("minecraft:navigation.climb");
        if (nav != null && e.getNavigation() instanceof GroundPathNavigation g) {
            g.setCanOpenDoors(Jsons.bool(nav, "can_open_doors", false));
            g.setCanPassDoors(Jsons.bool(nav, "can_pass_doors", true));
        }

        rebuildGoals(e, b, st);

        // ---- drop runtime state of components that are gone
        Set<String> valid = new HashSet<>();
        for (String name : b.effectiveComponents().keySet()) valid.add(baseKey(b, name));
        st.rt.keySet().removeIf(k -> !valid.contains(k.substring(0, k.indexOf('|'))));
    }

    private static void rebuildGoals(BedrockEntity e, BehaviorState b, State st) {
        for (Goal g : st.goals) e.goalSelector.removeGoal(g);
        for (Goal g : st.targetGoals) e.targetSelector.removeGoal(g);
        st.goals.clear();
        st.targetGoals.clear();

        String shooter = null;
        JsonObject sh = b.component("minecraft:shooter");
        if (sh != null) shooter = Jsons.str(sh, "def", null);

        for (Map.Entry<String, JsonElement> en : b.effectiveComponents().entrySet()) {
            String name = en.getKey();
            if (!name.startsWith("minecraft:behavior.") && !name.equals("minecraft:annotation.break_door")) continue;
            if (!en.getValue().isJsonObject()) continue;
            JsonObject c = en.getValue().getAsJsonObject();
            int prio = (int) num(c, "priority", 5);
            Goal g = null;
            boolean target = false;
            switch (name) {
                case "minecraft:behavior.float":
                    g = new FloatGoal(e);
                    break;
                case "minecraft:behavior.random_stroll":
                    g = new BedrockGoals.Stroll(e, c);
                    break;
                case "minecraft:behavior.look_at_player":
                    g = new LookAtPlayerGoal(e, Player.class, (float) num(c, "look_distance", 8), (float) num(c, "probability", 0.02));
                    break;
                case "minecraft:behavior.random_look_around":
                    g = new RandomLookAroundGoal(e);
                    break;
                case "minecraft:behavior.move_towards_restriction":
                    g = new MoveTowardsRestrictionGoal(e, num(c, "speed_multiplier", 1));
                    break;
                case "minecraft:behavior.melee_attack":
                    g = new BedrockGoals.Melee(e, c);
                    break;
                case "minecraft:behavior.look_at_target":
                    g = new BedrockGoals.LookAtTarget(e, c);
                    break;
                case "minecraft:behavior.ranged_attack":
                    g = new BedrockGoals.Ranged(e, c, shooter);
                    break;
                case "minecraft:behavior.delayed_attack":
                    g = new BedrockGoals.DelayedAttack(e, c);
                    break;
                case "minecraft:behavior.knockback_roar":
                    g = new BedrockGoals.KnockbackRoar(e, c);
                    break;
                case "minecraft:behavior.summon_entity":
                    g = new BedrockGoals.Summon(e, c);
                    break;
                case "minecraft:behavior.lay_down":
                    g = new BedrockGoals.LayDown(e, c);
                    break;
                case "minecraft:annotation.break_door":
                    g = new BreakDoorGoal(e, d -> true);
                    prio = 1;
                    break;
                case "minecraft:behavior.nearest_attackable_target":
                case "minecraft:behavior.nearest_prioritized_attackable_target":
                    g = new BedrockGoals.NearestTarget(e, c);
                    target = true;
                    break;
                case "minecraft:behavior.hurt_by_target":
                    g = new HurtByTargetGoal(e);
                    target = true;
                    break;
                default:
                    break;
            }
            if (g == null) continue;
            if (target) {
                e.targetSelector.addGoal(prio, g);
                st.targetGoals.add(g);
            } else {
                e.goalSelector.addGoal(prio, g);
                st.goals.add(g);
            }
        }
    }

    // =================================================================== tick

    public static void tick(BedrockEntity e) {
        BehaviorState b = e.behavior();
        if (b == null || !e.isAlive()) return;
        State st = e.comp;
        List<Runnable> deferred = new ArrayList<>();
        Level level = e.level();

        for (Map.Entry<String, JsonElement> en : new ArrayList<>(b.effectiveComponents().entrySet())) {
            String name = en.getKey();
            if (!en.getValue().isJsonObject()) continue;
            JsonObject c = en.getValue().getAsJsonObject();
            String base = baseKey(b, name);
            switch (name) {
                case "minecraft:timer":
                    tickTimer(e, st, c, base, deferred);
                    break;
                case "minecraft:target_nearby_sensor":
                    tickTargetSensor(e, st, c, base, deferred);
                    break;
                case "minecraft:environment_sensor":
                    tickEnvironmentSensor(e, st, c, base, deferred);
                    break;
                case "minecraft:spawn_entity":
                    tickSpawnEntity(e, st, c, base);
                    break;
                case "minecraft:instant_despawn":
                    if (Jsons.bool(c, "remove_child_entities", false)) for (Entity p : new ArrayList<>(e.getPassengers())) p.discard();
                    e.discard();
                    return;
                case "minecraft:despawn":
                    tickDespawn(e, c);
                    break;
                case "minecraft:explode":
                    if (tickExplode(e, st, c, base)) return;
                    break;
                case "minecraft:transformation":
                    if (tickTransformation(e, st, c, base)) return;
                    break;
                case "minecraft:addrider":
                    tickAddRider(e, st, c, base);
                    break;
                case "minecraft:ageable":
                    tickAgeable(e, st, c, base, b, deferred);
                    break;
                case "minecraft:break_blocks":
                    if (e.tickCount % 5 == 0) breakBlocks(e, c);
                    break;
                case "minecraft:projectile":
                    tickProjectile(e, st, c, deferred);
                    break;
                default:
                    break;
            }
        }
        int counter = st.changeCounter;
        for (Runnable r : deferred) {
            r.run();
            if (st.changeCounter != counter) break; // components changed: remaining firings belonged to the old state
        }
    }

    // ------------------------------------------------------------------ timers / sensors

    private static double armTicks(BedrockEntity e, JsonObject c) {
        JsonElement t = c.get("time");
        double lo = 0, hi = 0;
        if (t != null && t.isJsonArray() && t.getAsJsonArray().size() >= 2) {
            lo = t.getAsJsonArray().get(0).getAsDouble();
            hi = t.getAsJsonArray().get(1).getAsDouble();
        } else if (t != null && t.isJsonPrimitive()) {
            lo = hi = t.getAsDouble();
        }
        boolean random = Jsons.bool(c, "randomInterval", true);
        double s = (random ? lo + e.bedrockRandom().nextDouble() * (hi - lo) : lo);
        return Math.max(1, s * 20.0);
    }

    private static void tickTimer(BedrockEntity e, State st, JsonObject c, String base, List<Runnable> out) {
        double[] s = st.rt.computeIfAbsent(base + "|t", k -> new double[]{armTicks(e, c)});
        if (s[0] == Double.POSITIVE_INFINITY) return;
        s[0] -= 1;
        if (s[0] <= 0) {
            s[0] = Jsons.bool(c, "looping", true) ? armTicks(e, c) : Double.POSITIVE_INFINITY;
            fire(e, c.get("time_down_event"), out);
        }
    }

    private static void tickTargetSensor(BedrockEntity e, State st, JsonObject c, String base, List<Runnable> out) {
        double[] s = st.rt.computeIfAbsent(base + "|s", k -> new double[]{0});
        LivingEntity t = e.getTarget();
        if (t == null || !t.isAlive()) {
            s[0] = 0;
            return;
        }
        double d = e.distanceTo(t);
        double inside = num(c, "inside_range", 1);
        double outside = num(c, "outside_range", 32);
        if (d <= inside) {
            if (Jsons.bool(c, "must_see", false) && !e.hasLineOfSight(t)) return;
            if (s[0] != 1) {
                s[0] = 1;
                fire(e, c.get("on_inside_range"), out);
            }
        } else if (d >= outside) {
            if (s[0] != 2) {
                s[0] = 2;
                fire(e, c.get("on_outside_range"), out);
            }
        }
    }

    private static void tickEnvironmentSensor(BedrockEntity e, State st, JsonObject c, String base, List<Runnable> out) {
        JsonArray triggers = Jsons.arr(c, "triggers");
        if (triggers == null) return;
        double[] s = st.rt.computeIfAbsent(base + "|e", k -> {
            double[] a = new double[triggers.size()];
            java.util.Arrays.fill(a, -1);
            return a;
        });
        for (int i = 0; i < triggers.size() && i < s.length; i++) {
            if (!triggers.get(i).isJsonObject()) continue;
            JsonObject t = triggers.get(i).getAsJsonObject();
            boolean now = Filters.test(t.get("filters"), McFilterContext.subjects(e, e.eventOther()));
            double prev = s[i];
            s[i] = now ? 1 : 0;
            if (now && prev != 1) fire(e, t, out);
        }
    }

    // ------------------------------------------------------------------ spawn / despawn / explode / transform / rider / age

    private static void tickSpawnEntity(BedrockEntity e, State st, JsonObject c, String base) {
        JsonArray list = Jsons.arr(c, "entities");
        if (list == null) return;
        for (int i = 0; i < list.size(); i++) {
            if (!list.get(i).isJsonObject()) continue;
            JsonObject o = list.get(i).getAsJsonObject();
            double[] s = st.rt.computeIfAbsent(base + "|sp" + i, k -> new double[]{wait(e, o), 0});
            if (s[1] == 1) continue;
            s[0] -= 1;
            if (s[0] > 0) continue;
            String id = Jsons.str(o, "spawn_entity", null);
            int n = (int) num(o, "num_to_spawn", 1);
            if (id != null) {
                for (int k = 0; k < n; k++) {
                    double ox = (e.bedrockRandom().nextDouble() - 0.5) * 0.5, oz = (e.bedrockRandom().nextDouble() - 0.5) * 0.5;
                    Entity ne = BedrockSpawn.spawn(e.level(), id, e.getX() + ox, e.getY() + e.getBbHeight() * 0.5, e.getZ() + oz, e.getYRot(), 0, Jsons.str(o, "spawn_event", null));
                    if (ne instanceof BedrockEntity be) be.setBedrockOwner(e);
                }
            }
            if (Jsons.bool(o, "single_use", false)) s[1] = 1;
            else s[0] = wait(e, o);
        }
    }

    private static double wait(BedrockEntity e, JsonObject o) {
        double lo = num(o, "min_wait_time", 10), hi = num(o, "max_wait_time", 40);
        return Math.max(1, (lo + e.bedrockRandom().nextDouble() * Math.max(0, hi - lo)) * 20.0);
    }

    private static void tickDespawn(BedrockEntity e, JsonObject c) {
        if (e.tickCount < 40 || e.tickCount % 20 != 0) return;
        JsonObject d = Jsons.obj(c, "despawn_from_distance");
        double max = d == null ? 54 : num(d, "max_distance", 54);
        Player p = e.level().getNearestPlayer(e, -1);
        if (p == null || p.distanceTo(e) > max) e.discard();
    }

    private static boolean tickExplode(BedrockEntity e, State st, JsonObject c, String base) {
        double[] s = st.rt.computeIfAbsent(base + "|x", k -> new double[]{Jsons.bool(c, "fuse_lit", false) ? num(c, "fuse_length", 3) * 20 : Double.POSITIVE_INFINITY});
        if (s[0] == Double.POSITIVE_INFINITY) return false;
        s[0] -= 1;
        if (s[0] > 0) return false;
        Level.ExplosionInteraction mode = Jsons.bool(c, "breaks_blocks", true) ? Level.ExplosionInteraction.MOB : Level.ExplosionInteraction.NONE;
        e.level().explode(e, e.getX(), e.getY() + e.getBbHeight() * 0.5, e.getZ(), (float) num(c, "power", 3), Jsons.bool(c, "causes_fire", false), mode);
        e.discard();
        return true;
    }

    private static boolean tickTransformation(BedrockEntity e, State st, JsonObject c, String base) {
        String into = Jsons.str(c, "into", null);
        if (into == null) return false;
        JsonObject delay = Jsons.obj(c, "delay");
        double[] s = st.rt.computeIfAbsent(base + "|tr", k -> new double[]{delay == null ? 1 : num(delay, "value", 0) * 20 + 1});
        s[0] -= 1;
        if (s[0] > 0) return false;
        String[] spec = BedrockSpawn.splitEvent(into);
        Entity ne = BedrockSpawn.spawn(e.level(), spec[0], e.getX(), e.getY(), e.getZ(), e.getYRot(), e.getXRot(), spec[1]);
        if (ne != null) {
            if (e.hasCustomName()) ne.setCustomName(e.getCustomName());
            e.discard();
            return true;
        }
        s[0] = Double.POSITIVE_INFINITY;
        return false;
    }

    private static void tickAddRider(BedrockEntity e, State st, JsonObject c, String base) {
        double[] s = st.rt.computeIfAbsent(base + "|ar", k -> new double[]{0});
        if (s[0] == 1) return;
        s[0] = 1;
        String id = Jsons.str(c, "entity_type", null);
        if (id == null) return;
        String[] spec = BedrockSpawn.splitEvent(id);
        Entity r = BedrockSpawn.spawn(e.level(), spec[0], e.getX(), e.getY(), e.getZ(), e.getYRot(), 0, spec[1]);
        if (r != null) r.startRiding(e, true);
    }

    private static void tickAgeable(BedrockEntity e, State st, JsonObject c, String base, BehaviorState b, List<Runnable> out) {
        double dur = Math.max(1, num(c, "duration", 1200) * 20);
        double[] s = st.rt.computeIfAbsent(base + "|ag", k -> new double[]{0, 0});
        if (s[1] == 0) s[0] += 1;
        JsonObject sba = b.component("minecraft:scale_by_age");
        if (sba != null) {
            double t = Math.min(1, s[0] / dur);
            e.setBedrockScale((float) (num(sba, "start_scale", 1) + (num(sba, "end_scale", 1) - num(sba, "start_scale", 1)) * t));
        }
        if (s[1] == 0 && s[0] >= dur) {
            s[1] = 1;
            fire(e, c.get("grow_up"), out);
        }
    }

    private static void breakBlocks(BedrockEntity e, JsonObject c) {
        Level level = e.level();
        if (!level.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) return;
        JsonArray names = Jsons.arr(c, "breakable_blocks");
        if (names == null) return;
        AABB box = e.getBoundingBox().inflate(0.4, 0, 0.4);
        for (BlockPos p : BlockPos.betweenClosed(BlockPos.containing(box.minX, box.minY, box.minZ), BlockPos.containing(box.maxX, box.maxY, box.maxZ))) {
            BlockState st = level.getBlockState(p);
            if (st.isAir()) continue;
            boolean match = false;
            for (JsonElement n : names) {
                String name = n.getAsString();
                if (name.startsWith("leaves")) match = st.is(BlockTags.LEAVES);
                else match = BuiltInRegistries.BLOCK.getKey(st.getBlock()).getPath().equals(name.replace("minecraft:", ""));
                if (match) break;
            }
            if (match) level.destroyBlock(p.immutable(), true, e);
        }
    }

    // ------------------------------------------------------------------ projectile

    private static void tickProjectile(BedrockEntity e, State st, JsonObject c, List<Runnable> out) {
        if (!st.launched) {
            st.launched = true;
            JsonArray off = Jsons.arr(c, "offset");
            double yaw = Math.toRadians(e.getYRot()), pitch = Math.toRadians(e.getXRot());
            if (off != null && off.size() >= 3) {
                double ox = off.get(0).getAsDouble(), oy = off.get(1).getAsDouble(), oz = off.get(2).getAsDouble();
                double fx = -Math.sin(yaw), fz = Math.cos(yaw);
                e.setPos(e.getX() + ox * fz + oz * fx, e.getY() + oy, e.getZ() - ox * fx + oz * fz);
            }
            double power = num(c, "power", 1.6);
            Vec3 dir = new Vec3(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
            e.setDeltaMovement(dir.scale(power));
            e.setNoGravity(num(c, "gravity", 0.05) == 0);
        }
        Vec3 v = e.getDeltaMovement();
        double inertia = num(c, "inertia", 0.99);
        double grav = num(c, "gravity", 0.05);
        v = new Vec3(v.x * inertia, v.y * inertia - (grav == 0 ? 0 : grav), v.z * inertia);
        e.setDeltaMovement(v);
        e.move(MoverType.SELF, v);
        if (v.lengthSqr() > 1.0E-6) {
            e.setYRot((float) (Math.atan2(-v.x, v.z) * (180.0 / Math.PI)));
            e.setXRot((float) (-Math.atan2(v.y, Math.sqrt(v.x * v.x + v.z * v.z)) * (180.0 / Math.PI)));
            e.yRotO = e.getYRot();
            e.xRotO = e.getXRot();
        }
        if (st.hitCooldown > 0) st.hitCooldown--;
        JsonObject onHit = Jsons.obj(c, "on_hit");
        boolean blockHit = e.horizontalCollision || e.verticalCollision;
        Entity hitEntity = null;
        Entity owner = e.getBedrockOwner();
        for (Entity o : e.level().getEntities(e, e.getBoundingBox().inflate(0.2), x -> x != owner && x.isAlive() && !(x instanceof BedrockEntity b && b.families().contains("inanimate")))) {
            if (o instanceof LivingEntity && !(o instanceof BedrockEntity bo && owner instanceof BedrockEntity bw && bo.def() == bw.def())) {
                hitEntity = o;
                break;
            }
        }
        if ((blockHit || hitEntity != null) && st.hitCooldown == 0) {
            st.hitCooldown = 5;
            if (hitEntity != null && onHit != null) {
                JsonObject dmg = Jsons.obj(onHit, "impact_damage");
                if (dmg != null) {
                    DamageSource src = owner instanceof LivingEntity ol ? e.damageSources().mobAttack(ol) : e.damageSources().generic();
                    hitEntity.hurt(src, (float) num(dmg, "damage", 1));
                    if (Jsons.bool(dmg, "knockback", true)) hitEntity.push(v.x * 0.3, 0.2, v.z * 0.3);
                }
            }
            JsonObject def = onHit == null ? null : Jsons.obj(onHit, "definition_event");
            if (def != null) fire(e, def.get("event_trigger"), out);
            if (onHit != null && onHit.has("remove_on_hit")) e.discard();
        }
        if (e.tickCount > 600) e.discard();
    }

    // =================================================================== hooks from BedrockEntity

    public static void onTargetAcquired(BedrockEntity e, LivingEntity target) {
        BehaviorState b = e.behavior();
        JsonObject c = b == null ? null : b.component("minecraft:on_target_acquired");
        if (c == null) return;
        List<Runnable> out = new ArrayList<>();
        fire(e, c, out);
        for (Runnable r : out) r.run();
    }

    /** Returns the damage to apply, or a negative value to cancel the hit. */
    public static float onHurt(BedrockEntity e, DamageSource src, float amount) {
        BehaviorState b = e.behavior();
        if (b == null) return amount;
        JsonObject ds = b.component("minecraft:damage_sensor");
        if (ds != null) {
            JsonArray trig = Jsons.arr(ds, "triggers");
            if (trig != null) {
                for (JsonElement te : trig) {
                    if (!te.isJsonObject()) continue;
                    JsonObject t = te.getAsJsonObject();
                    if (!McFilterContext.causeMatches(src, Jsons.str(t, "cause", "all"))) continue;
                    Entity attacker = src.getEntity();
                    if (t.has("on_damage") && t.get("on_damage").isJsonObject()) {
                        JsonObject od = t.getAsJsonObject("on_damage");
                        if (!od.has("filters") || Filters.test(od.get("filters"), McFilterContext.subjects(e, attacker))) {
                            List<Runnable> out = new ArrayList<>();
                            fire(e, od, out);
                            Entity prev = attacker;
                            for (Runnable r : out) r.run();
                        }
                    }
                    JsonElement dd = t.get("deals_damage");
                    boolean deals = true;
                    if (dd != null && dd.isJsonPrimitive()) {
                        if (dd.getAsJsonPrimitive().isBoolean()) deals = dd.getAsBoolean();
                        else {
                            String s = dd.getAsString();
                            deals = !(s.equals("no") || s.equals("false") || s.equals("no_but_side_effects_apply"));
                        }
                    }
                    if (!deals) return -1f;
                }
            }
        }
        amount = (float) (amount / e.healthScale);
        if (e.comp.minHealth > 0) {
            double limit = e.getHealth() - e.comp.minHealth / e.healthScale;
            if (limit <= 0) return -1f;
            amount = (float) Math.min(amount, limit);
        }
        return amount;
    }
}
