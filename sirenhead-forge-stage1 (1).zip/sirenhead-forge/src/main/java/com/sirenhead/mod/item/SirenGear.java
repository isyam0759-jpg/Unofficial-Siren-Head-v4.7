package com.sirenhead.mod.item;

import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

import java.util.List;

/** Weapons and armor of the add-on (stage 2 of the port). */
final class SirenGear {
    private SirenGear() {
    }

    static void register(DeferredRegister<Item> items, List<RegistryObject<? extends Item>> all) {
        // filled in by the second delivery stage
    }
}
