package com.sirenhead.mod.block;

import com.sirenhead.mod.SirenHeadMod;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.PushReaction;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** The two custom blocks of the add-on. */
public final class SirenBlocks {
    private SirenBlocks() {
    }

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, SirenHeadMod.MOD_ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, SirenHeadMod.MOD_ID);

    /** bd:siren_head_head - decorative head, rotates with the placing direction. */
    public static final RegistryObject<Block> SIREN_HEAD_HEAD = BLOCKS.register("siren_head_head",
            () -> new SirenGeoBlock(BlockBehaviour.Properties.of().strength(2.5f).noOcclusion(), true, true));

    /** bd:bd_lighter - invisible-collision light source (light level 10), breakable in 4 s. */
    public static final RegistryObject<Block> BD_LIGHTER = BLOCKS.register("bd_lighter",
            () -> new SirenGeoBlock(BlockBehaviour.Properties.of().strength(2.5f).noOcclusion().noCollission()
                    .lightLevel(s -> 10).pushReaction(PushReaction.DESTROY).replaceable(), false, false));

    public static final RegistryObject<BlockEntityType<SirenGeoBlockEntity>> GEO_BLOCK_ENTITY = BLOCK_ENTITIES.register("geo_block",
            () -> BlockEntityType.Builder.of(SirenGeoBlockEntity::new, SIREN_HEAD_HEAD.get(), BD_LIGHTER.get()).build(null));

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
        BLOCK_ENTITIES.register(bus);
    }
}
