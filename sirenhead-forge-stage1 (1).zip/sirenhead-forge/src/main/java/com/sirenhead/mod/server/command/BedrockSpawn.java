package com.sirenhead.mod.server.command;

import com.sirenhead.mod.BedrockEntities;
import com.sirenhead.mod.entity.BedrockEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.ForgeRegistries;

/** Spawning of entities by Bedrock identifier (add-on entities and vanilla names such as {@code xp_orb}). */
public final class BedrockSpawn {
    private BedrockSpawn() {
    }

    /** Resolves a Bedrock id ({@code ho:sirenhead}, {@code minecraft:zombie}, {@code zombie}, {@code xp_orb}); null if unknown. */
    public static EntityType<?> resolve(String id) {
        if (id == null || id.isBlank()) return null;
        String t = id.trim();
        EntityType<?> own = BedrockEntities.type(t);
        if (own != null) return own;
        String ns = "minecraft";
        String path = t;
        int c = t.indexOf(':');
        if (c >= 0) {
            ns = t.substring(0, c);
            path = t.substring(c + 1);
            if (ns.equals("ho") || ns.equals("bd")) {
                ResourceLocation rl = new ResourceLocation("sirenhead", path);
                return ForgeRegistries.ENTITY_TYPES.containsKey(rl) ? ForgeRegistries.ENTITY_TYPES.getValue(rl) : null;
            }
        }
        if (path.equals("xp_orb")) path = "experience_orb";
        if (path.equals("lightning_bolt")) path = "lightning_bolt";
        ResourceLocation rl = new ResourceLocation(ns, path);
        return ForgeRegistries.ENTITY_TYPES.containsKey(rl) ? ForgeRegistries.ENTITY_TYPES.getValue(rl) : null;
    }

    /**
     * Spawns an entity. {@code event} (may be null) replaces {@code minecraft:entity_spawned} for add-on entities.
     *
     * @return the new entity, or null if the id is unknown / the level is not a server level
     */
    public static Entity spawn(Level level, String id, double x, double y, double z, float yaw, float pitch, String event) {
        if (!(level instanceof ServerLevel sl)) return null;
        EntityType<?> type = resolve(id);
        if (type == null) return null;
        Entity e;
        if (type == EntityType.EXPERIENCE_ORB) {
            e = new ExperienceOrb(sl, x, y, z, 1);
        } else {
            e = type.create(sl);
            if (e == null) return null;
            e.moveTo(x, y, z, yaw, pitch);
            if (e instanceof BedrockEntity be && event != null && !event.isBlank()) be.spawnEvent = event;
            if (e instanceof net.minecraft.world.entity.Mob mob) {
                mob.yHeadRot = yaw;
                mob.yBodyRot = yaw;
            }
        }
        sl.addFreshEntity(e);
        return e;
    }

    /** Splits {@code "ho:cartoon_cat<minecraft:entity_spawned>"} into id and event (event null if absent). */
    public static String[] splitEvent(String spec) {
        int lt = spec.indexOf('<');
        if (lt < 0 || !spec.endsWith(">")) return new String[]{spec, null};
        return new String[]{spec.substring(0, lt), spec.substring(lt + 1, spec.length() - 1)};
    }
}
