package com.sirenhead.mod.client;

import com.sirenhead.mod.BedrockEntities;
import com.sirenhead.mod.entity.BedrockEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.EntityType;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.RegistryObject;

/** Client-only wiring: entity renderers, Bedrock particle ticking/rendering, camera shake and input locks. */
public final class ClientSetup {
    private ClientSetup() {
    }

    public static void init(IEventBus modBus) {
        modBus.addListener(ClientSetup::registerRenderers);
        MinecraftForge.EVENT_BUS.addListener(ClientSetup::onClientTick);
        MinecraftForge.EVENT_BUS.addListener(ClientSetup::onRenderLevel);
        MinecraftForge.EVENT_BUS.addListener(ClientSetup::onCameraAngles);
        MinecraftForge.EVENT_BUS.addListener(ClientSetup::onMovementInput);
        MinecraftForge.EVENT_BUS.addListener(ClientSetup::onLogout);
    }

    private static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        for (RegistryObject<EntityType<BedrockEntity>> ro : BedrockEntities.TYPES.values()) {
            event.registerEntityRenderer(ro.get(), BedrockEntityRenderer::new);
        }
        event.registerBlockEntityRenderer(com.sirenhead.mod.block.SirenBlocks.GEO_BLOCK_ENTITY.get(), ctx -> new SirenBlockRenderer());
    }

    private static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (Minecraft.getInstance().isPaused()) return;
        BedrockParticles.tick();
        ClientPackets.clientTick();
    }

    private static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        BedrockParticles.render(event.getPoseStack(), event.getCamera(), event.getPartialTick());
    }

    private static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        float[] s = ClientPackets.shakeOffsets();
        if (s[0] == 0 && s[1] == 0 && s[2] == 0) return;
        event.setYaw(event.getYaw() + s[0]);
        event.setPitch(event.getPitch() + s[1]);
        event.setRoll(event.getRoll() + s[2]);
    }

    private static void onMovementInput(MovementInputUpdateEvent event) {
        if (ClientPackets.movementEnabled) return;
        var in = event.getInput();
        in.leftImpulse = 0;
        in.forwardImpulse = 0;
        in.up = false;
        in.down = false;
        in.left = false;
        in.right = false;
        in.jumping = false;
        in.shiftKeyDown = false;
    }

    private static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        ClientPackets.reset();
    }
}
