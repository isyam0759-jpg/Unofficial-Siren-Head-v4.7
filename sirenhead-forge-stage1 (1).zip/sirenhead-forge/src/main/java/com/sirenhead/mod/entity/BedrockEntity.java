package com.sirenhead.mod.entity;

import com.sirenhead.bedrock.anim.AnimationHost;
import com.sirenhead.bedrock.anim.EntityAnimator;
import com.sirenhead.bedrock.behavior.BehaviorHost;
import com.sirenhead.bedrock.behavior.BehaviorState;
import com.sirenhead.bedrock.behavior.FilterContext;
import com.sirenhead.bedrock.molang.MolangEnv;
import com.sirenhead.mod.BedrockLibraries;
import com.sirenhead.mod.SirenHeadMod;
import com.sirenhead.mod.entity.ai.BedrockComponents;
import com.sirenhead.mod.entity.ai.McFilterContext;
import com.sirenhead.mod.molang.EntityMolangEnv;
import com.sirenhead.mod.server.command.BedrockCommands;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import org.joml.Vector3f;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * The single Java entity class behind every Bedrock entity of the add-on.
 * <ul>
 *   <li>Server: owns a {@link BehaviorState} (component groups, properties, events), applies the active components
 *       ({@link BedrockComponents}) and runs the BP animation controllers ({@link EntityAnimator}) whose commands drive the mob.</li>
 *   <li>Client: renders with GeckoLib; the RP animators/controllers run in {@code ClientEntityState} from synced data.</li>
 * </ul>
 */
public class BedrockEntity extends PathfinderMob implements GeoEntity {
    public static final int F_STUNNED = 1;
    public static final int F_CASTING = 2;
    public static final int F_DELAYED = 4;
    public static final int F_LAYING = 8;
    public static final int F_RIDEABLE = 16;

    private static final EntityDataAccessor<CompoundTag> DATA_PROPS = SynchedEntityData.defineId(BedrockEntity.class, EntityDataSerializers.COMPOUND_TAG);
    private static final EntityDataAccessor<Integer> DATA_FLAGS = SynchedEntityData.defineId(BedrockEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_VARIANT = SynchedEntityData.defineId(BedrockEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_MARK = SynchedEntityData.defineId(BedrockEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_SKIN = SynchedEntityData.defineId(BedrockEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_TARGET = SynchedEntityData.defineId(BedrockEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> DATA_SCALE = SynchedEntityData.defineId(BedrockEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Vector3f> DATA_SEAT = SynchedEntityData.defineId(BedrockEntity.class, EntityDataSerializers.VECTOR3);

    private final BedrockEntityDef def;
    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);

    // ---- server only
    private BehaviorState behavior;
    private EntityAnimator bpAnimator;
    private final List<String[]> queued = new ArrayList<>();
    private final Random bedrockRandom = new Random();
    private boolean initialized;
    private boolean loadedFromSave;
    private boolean propsDirty = true;
    private DamageSource currentDamage;
    private Entity eventOther;
    private UUID ownerUuid;
    /** Runtime state of the active components (timers, sensors, goals). */
    public final BedrockComponents.State comp = new BedrockComponents.State();
    /** Health in Bedrock units is divided by this to fit vanilla's 1024 max-health cap. */
    public double healthScale = 1.0;
    public boolean pushableFlag = true;
    /** Event fired on first tick instead of {@code minecraft:entity_spawned} (set by {@code /summon type x y z <event>}). */
    public String spawnEvent = "minecraft:entity_spawned";

    // ---- both sides
    private EntityMolangEnv molang;
    /** Client-only render state (typed as Object so this class loads on dedicated servers). */
    public Object clientData;

    public BedrockEntity(EntityType<? extends BedrockEntity> type, Level level, BedrockEntityDef def) {
        super(type, level);
        this.def = def;
        if (!level.isClientSide) this.behavior = new BehaviorState(def.behavior(), new ServerHost());
    }

    // =================================================================== accessors

    public BedrockEntityDef def() {
        return def;
    }

    /** Server only (null on the client). */
    public BehaviorState behavior() {
        return behavior;
    }

    public EntityMolangEnv molang() {
        if (molang == null) molang = new EntityMolangEnv(this);
        return molang;
    }

    public Random bedrockRandom() {
        return bedrockRandom;
    }

    /** Value of a Bedrock entity property (server: live state, client: synced copy). */
    public double getProperty(String name) {
        if (behavior != null) return behavior.property(name);
        CompoundTag t = entityData.get(DATA_PROPS);
        return t.contains(name) ? t.getDouble(name) : 0.0;
    }

    public void setProperty(String name, double v) {
        if (behavior != null) behavior.setProperty(name, v);
    }

    public int getVariant() {
        return entityData.get(DATA_VARIANT);
    }

    public void setVariant(int v) {
        entityData.set(DATA_VARIANT, v);
    }

    public int getMarkVariant() {
        return entityData.get(DATA_MARK);
    }

    public void setMarkVariant(int v) {
        entityData.set(DATA_MARK, v);
    }

    public int getSkinId() {
        return entityData.get(DATA_SKIN);
    }

    public void setSkinId(int v) {
        entityData.set(DATA_SKIN, v);
    }

    public float getBedrockScale() {
        return entityData.get(DATA_SCALE);
    }

    public void setBedrockScale(float s) {
        entityData.set(DATA_SCALE, s);
    }

    public int getFlags() {
        return entityData.get(DATA_FLAGS);
    }

    public boolean hasFlag(int f) {
        return (entityData.get(DATA_FLAGS) & f) != 0;
    }

    public void setFlag(int f, boolean on) {
        int cur = entityData.get(DATA_FLAGS);
        int n = on ? (cur | f) : (cur & ~f);
        if (n != cur) entityData.set(DATA_FLAGS, n);
    }

    public boolean isStunned() {
        return hasFlag(F_STUNNED);
    }

    public boolean isCasting() {
        return hasFlag(F_CASTING);
    }

    public boolean isDelayedAttacking() {
        return hasFlag(F_DELAYED);
    }

    public boolean isLayingDown() {
        return hasFlag(F_LAYING);
    }

    public void setSeat(boolean rideable, float x, float y, float z) {
        setFlag(F_RIDEABLE, rideable);
        entityData.set(DATA_SEAT, new Vector3f(x, y, z));
    }

    public boolean hasBedrockTarget() {
        return entityData.get(DATA_TARGET) >= 0;
    }

    public Entity getBedrockTargetEntity() {
        if (!level().isClientSide) return getTarget();
        int id = entityData.get(DATA_TARGET);
        return id < 0 ? null : level().getEntity(id);
    }

    public Entity getBedrockOwner() {
        if (ownerUuid == null || !(level() instanceof ServerLevel sl)) return null;
        return sl.getEntity(ownerUuid);
    }

    public void setBedrockOwner(Entity owner) {
        this.ownerUuid = owner == null ? null : owner.getUUID();
    }

    /** Families = type_family of the active components (server) or of the definition (client). */
    public Set<String> families() {
        return behavior != null ? comp.families : def.families();
    }

    public DamageSource currentDamage() {
        return currentDamage;
    }

    public Entity eventOther() {
        return eventOther != null ? eventOther : getTarget();
    }

    // =================================================================== data

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(DATA_PROPS, new CompoundTag());
        entityData.define(DATA_FLAGS, 0);
        entityData.define(DATA_VARIANT, 0);
        entityData.define(DATA_MARK, 0);
        entityData.define(DATA_SKIN, 0);
        entityData.define(DATA_TARGET, -1);
        entityData.define(DATA_SCALE, 1.0f);
        entityData.define(DATA_SEAT, new Vector3f(0, 0, 0));
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (behavior != null) tag.putString("BedrockState", behavior.saveState());
        tag.putBoolean("BedrockInit", initialized);
        if (ownerUuid != null) tag.putUUID("BedrockOwner", ownerUuid);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (behavior != null && tag.contains("BedrockState")) behavior.loadState(tag.getString("BedrockState"));
        loadedFromSave = tag.getBoolean("BedrockInit");
        if (tag.hasUUID("BedrockOwner")) ownerUuid = tag.getUUID("BedrockOwner");
        propsDirty = true;
    }

    // =================================================================== events

    /** Runs a Bedrock event of this entity (server only). */
    public void triggerEvent(String event) {
        if (behavior != null) behavior.trigger(event);
    }

    public void triggerEvent(String event, Entity other) {
        Entity prev = eventOther;
        eventOther = other;
        try {
            triggerEvent(event);
        } finally {
            eventOther = prev;
        }
    }

    // =================================================================== tick

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide) serverTick();
    }

    private void serverTick() {
        if (behavior == null) return;
        if (!initialized) {
            initialized = true;
            if (!loadedFromSave) triggerEvent(spawnEvent);
            BedrockComponents.apply(this);
            if (!loadedFromSave) setHealth(getMaxHealth());
        }
        if (!queued.isEmpty()) {
            List<String[]> copy = new ArrayList<>(queued);
            queued.clear();
            for (String[] q : copy) {
                Entity executor = q[1].equals("target") ? getTarget() : this;
                if (executor != null && executor.isAlive()) BedrockCommands.run(executor, q[0]);
            }
        }
        BedrockComponents.tick(this);
        if (bpAnimator == null) bpAnimator = createBpAnimator();
        bpAnimator.tick(tickCount / 20.0);
        LivingEntity t = getTarget();
        int tid = t == null ? -1 : t.getId();
        if (entityData.get(DATA_TARGET) != tid) entityData.set(DATA_TARGET, tid);
        if (propsDirty) syncProps();
    }

    private EntityAnimator createBpAnimator() {
        AnimationHost host = new AnimationHost() {
            @Override
            public MolangEnv env() {
                return molang();
            }

            @Override
            public void command(String cmd) {
                BedrockCommands.run(BedrockEntity.this, cmd);
            }

            @Override
            public void particle(String effect, String locator, String preEffectScript) {
            }

            @Override
            public void sound(String effect) {
            }
        };
        return new EntityAnimator(BedrockLibraries.bp(), def.behavior().animationMap(), def.behavior().animate(),
                def.behavior().preAnimation(), false, host);
    }

    private void syncProps() {
        propsDirty = false;
        CompoundTag t = new CompoundTag();
        for (var p : def.behavior().properties().values()) {
            if (p.clientSync()) t.putDouble(p.name(), behavior.property(p.name()));
        }
        entityData.set(DATA_PROPS, t);
    }

    @Override
    public void setTarget(LivingEntity target) {
        LivingEntity old = getTarget();
        super.setTarget(target);
        if (!level().isClientSide && behavior != null && old == null && target != null) BedrockComponents.onTargetAcquired(this, target);
    }

    // =================================================================== combat

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!level().isClientSide && behavior != null) {
            currentDamage = source;
            try {
                amount = BedrockComponents.onHurt(this, source, amount);
            } finally {
                currentDamage = null;
            }
            if (amount < 0) return false;
        }
        return super.hurt(source, amount);
    }

    @Override
    public boolean isPushable() {
        return pushableFlag && super.isPushable();
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        // the add-on plays its own step sounds from the client entity definition
    }

    @Override
    protected net.minecraft.sounds.SoundEvent getHurtSound(DamageSource source) {
        return null;
    }

    @Override
    protected net.minecraft.sounds.SoundEvent getDeathSound() {
        return null;
    }

    // =================================================================== riding

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return hasFlag(F_RIDEABLE) && getPassengers().size() < Math.max(1, comp.seatCount);
    }

    @Override
    protected void positionRider(Entity passenger, Entity.MoveFunction callback) {
        if (!hasPassenger(passenger)) return;
        if (!hasFlag(F_RIDEABLE)) {
            super.positionRider(passenger, callback);
            return;
        }
        Vector3f s = entityData.get(DATA_SEAT);
        double yaw = Math.toRadians(yBodyRot);
        double cos = Math.cos(yaw), sin = Math.sin(yaw);
        double sc = getBedrockScale();
        double lx = s.x() * sc, lz = s.z() * sc;
        callback.accept(passenger, getX() + lx * cos - lz * sin, getY() + s.y() * sc, getZ() + lx * sin + lz * cos);
    }

    // =================================================================== GeckoLib

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        // Animations are produced by the Bedrock runtime (see ClientEntityState / BedrockGeoModel), not by GeckoLib controllers.
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return geoCache;
    }

    // =================================================================== behaviour host

    private final class ServerHost implements BehaviorHost {
        private final java.util.Set<String> warned = new java.util.HashSet<>();

        @Override
        public void onComponentsChanged() {
            if (initialized) BedrockComponents.apply(BedrockEntity.this);
        }

        @Override
        public void runCommand(String command, String target) {
            queued.add(new String[]{command, target == null ? "self" : target});
        }

        @Override
        public Random random() {
            return bedrockRandom;
        }

        @Override
        public FilterContext filterContext(String subject) {
            Entity e;
            switch (subject) {
                case "self":
                    e = BedrockEntity.this;
                    break;
                case "other":
                    e = eventOther();
                    break;
                case "target":
                    e = getTarget();
                    break;
                case "parent":
                    e = getVehicle();
                    break;
                case "damager":
                    e = currentDamage == null ? null : currentDamage.getEntity();
                    break;
                case "player": {
                    Player p = level().getNearestPlayer(BedrockEntity.this, 256);
                    e = p;
                    break;
                }
                default:
                    e = null;
                    break;
            }
            if (e == null) return null;
            return new McFilterContext(e, e == BedrockEntity.this ? currentDamage : null, BedrockEntity.this);
        }

        @Override
        public MolangEnv env() {
            return molang();
        }

        @Override
        public void onPropertyChanged(String name, double value) {
            propsDirty = true;
        }

        @Override
        public void warn(String message) {
            if (warned.add(message)) SirenHeadMod.LOGGER.debug("[{}] {}", def.id(), message);
        }
    }
}
