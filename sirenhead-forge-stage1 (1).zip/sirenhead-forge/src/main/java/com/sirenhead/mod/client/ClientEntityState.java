package com.sirenhead.mod.client;

import com.sirenhead.bedrock.anim.AnimateEntry;
import com.sirenhead.bedrock.anim.AnimationHost;
import com.sirenhead.bedrock.anim.ClientEntityDef;
import com.sirenhead.bedrock.anim.EntityAnimator;
import com.sirenhead.bedrock.anim.RenderControllerDef;
import com.sirenhead.bedrock.molang.Molang;
import com.sirenhead.bedrock.molang.MolangEnv;
import com.sirenhead.mod.BedrockLibraries;
import com.sirenhead.mod.SirenHeadMod;
import com.sirenhead.mod.entity.BedrockEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;

import java.util.List;

/**
 * Client-side Bedrock state of one entity: the RP {@link EntityAnimator} (animations, animation controllers, particle and
 * sound keyframes) and the currently selected render controller choice (geometry / texture / material).
 */
public final class ClientEntityState implements AnimationHost {
    public static final String FALLBACK_GEOMETRY = "geometry.none";

    private final BedrockEntity entity;
    private final ClientEntityDef cdef;
    private final EntityAnimator animator;
    private RenderControllerDef.Choice choice;
    private double lastTime = Double.NaN;

    private ClientEntityState(BedrockEntity entity) {
        this.entity = entity;
        this.cdef = BedrockLibraries.clientEntity(entity.def().id());
        if (cdef != null) {
            this.animator = new EntityAnimator(BedrockLibraries.rp(), cdef.animations(), cdef.animate(), cdef.preAnimation(), true, this);
        } else {
            this.animator = null;
        }
    }

    public static ClientEntityState of(BedrockEntity e) {
        if (e.clientData instanceof ClientEntityState s) return s;
        ClientEntityState s = new ClientEntityState(e);
        e.clientData = s;
        return s;
    }

    public ClientEntityDef def() {
        return cdef;
    }

    public EntityAnimator animator() {
        return animator;
    }

    public RenderControllerDef.Choice choice() {
        return choice;
    }

    /** Called once per rendered frame before the model is drawn. */
    public void update(float partialTick) {
        entity.molang().setPartialTick(partialTick);
        if (animator == null) return;
        double t = (entity.tickCount + partialTick) / 20.0;
        if (Double.isNaN(lastTime) || t != lastTime) {
            lastTime = t;
            try {
                animator.tick(t);
            } catch (RuntimeException ex) {
                SirenHeadMod.LOGGER.debug("[{}] animator failed: {}", entity.def().id(), ex.toString());
            }
        }
        choice = resolveChoice();
    }

    private RenderControllerDef.Choice resolveChoice() {
        if (cdef == null) return null;
        MolangEnv env = entity.molang();
        List<AnimateEntry> entries = cdef.renderControllerEntries();
        for (AnimateEntry en : entries) {
            String cond = en.condition();
            if (cond != null && !cond.isBlank()) {
                Object r = Molang.compileLenient(cond).eval(env);
                if (Molang.toNum(r) == 0) continue;
            }
            String full = en.shortName();
            if (!full.startsWith("controller.render.")) full = "controller.render." + full;
            RenderControllerDef rc = BedrockLibraries.rp().renderController(full);
            if (rc == null) rc = BedrockLibraries.rp().renderController(en.shortName());
            if (rc == null) continue;
            return rc.resolve(env, cdef);
        }
        return null;
    }

    // ------------------------------------------------------------------ AnimationHost

    @Override
    public MolangEnv env() {
        return entity.molang();
    }

    @Override
    public void command(String cmd) {
        // RP animations contain no commands; BP commands run on the server.
    }

    @Override
    public void particle(String effect, String locator, String preEffectScript) {
        String id = cdef != null && cdef.particleEffects().containsKey(effect) ? cdef.particleEffects().get(effect) : effect;
        BedrockParticles.spawnAttached(entity, this, id, locator, preEffectScript);
    }

    @Override
    public void sound(String effect) {
        String name = cdef != null && cdef.soundEffects().containsKey(effect) ? cdef.soundEffects().get(effect) : effect;
        if (name == null || Minecraft.getInstance().level == null) return;
        SoundEvent ev = SoundEvent.createVariableRangeEvent(new ResourceLocation(SirenHeadMod.MOD_ID, name));
        Minecraft.getInstance().level.playLocalSound(entity.getX(), entity.getY(), entity.getZ(), ev, SoundSource.HOSTILE, 1.0f, 1.0f, false);
    }
}
