package com.sirenhead.mod.server.command;

import com.sirenhead.bedrock.BedrockPaths;
import com.sirenhead.bedrock.command.ExecChain;
import com.sirenhead.bedrock.command.Lex;
import com.sirenhead.bedrock.command.Pos;
import com.sirenhead.bedrock.command.Selector;
import com.sirenhead.mod.BedrockLibraries;
import com.sirenhead.mod.SirenHeadMod;
import com.sirenhead.mod.entity.BedrockEntity;
import com.sirenhead.mod.entity.ai.McFilterContext;
import com.sirenhead.mod.network.BedrockNetwork;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetActionBarTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.scores.criteria.ObjectiveCriteria;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * Interpreter for the Bedrock command subset used by the add-on (behaviour events, animation timelines and
 * {@code .mcfunction} files). Parsing / selector maths live in the pure {@code com.sirenhead.bedrock.command} package.
 */
public final class BedrockCommands {
    private BedrockCommands() {
    }

    private static final int MAX_DEPTH = 400;
    private static final int MAX_COMMANDS = 2500;
    private static final Random RNG = new Random();
    private static final Set<String> WARNED = new HashSet<>();
    private static final Map<String, Selector> SELECTORS = new HashMap<>();
    private static final Map<String, SoundEvent> SOUNDS = new HashMap<>();
    private static final Map<UUID, boolean[]> INPUT = new HashMap<>();

    // =================================================================== context

    private static final class Ctx {
        final ServerLevel level;
        Entity self;
        double x, y, z;
        float yaw, pitch;
        boolean eyes;

        Ctx(ServerLevel level) {
            this.level = level;
        }

        Ctx copy() {
            Ctx c = new Ctx(level);
            c.self = self;
            c.x = x;
            c.y = y;
            c.z = z;
            c.yaw = yaw;
            c.pitch = pitch;
            c.eyes = eyes;
            c.shared = shared;
            return c;
        }

        int[] shared = {MAX_COMMANDS};
    }

    /** Runs a command as the given entity, at its position and rotation. */
    public static void run(Entity executor, String command) {
        if (!(executor.level() instanceof ServerLevel level) || command == null) return;
        Ctx c = new Ctx(level);
        c.self = executor;
        c.x = executor.getX();
        c.y = executor.getY();
        c.z = executor.getZ();
        c.yaw = executor.getYRot();
        c.pitch = executor.getXRot();
        exec(c, command, 0);
    }

    private static void warn(String msg) {
        if (WARNED.add(msg)) SirenHeadMod.LOGGER.debug("[bedrock-command] {}", msg);
    }

    private static void exec(Ctx c, String cmd, int depth) {
        String line = cmd == null ? "" : cmd.trim();
        if (line.isEmpty() || line.startsWith("#")) return;
        if (depth > MAX_DEPTH || --c.shared[0] < 0) {
            warn("command budget exhausted: " + line);
            return;
        }
        try {
            List<String> t = Lex.tokens(line);
            if (t.isEmpty()) return;
            switch (t.get(0)) {
                case "execute": walk(c, ExecChain.parse(t), 0, depth); break;
                case "function": function(c, t, depth); break;
                case "damage": damage(c, t); break;
                case "effect": effect(c, t); break;
                case "kill": kill(c, t); break;
                case "tp": case "teleport": tp(c, t); break;
                case "summon": summon(c, t); break;
                case "particle": particle(c, t); break;
                case "playanimation": playAnimation(c, t); break;
                case "playsound": playSound(c, t); break;
                case "stopsound": stopSound(c, t); break;
                case "camerashake": cameraShake(c, t); break;
                case "camera": camera(c, t); break;
                case "inputpermission": inputPermission(c, t); break;
                case "ride": ride(c, t); break;
                case "tag": tag(c, t); break;
                case "event": event(c, t); break;
                case "scoreboard": scoreboard(c, t); break;
                case "say": say(c, t); break;
                case "msg": case "tell": case "w": tell(c, t); break;
                case "title": title(c, t); break;
                case "gamemode": gamemode(c, t); break;
                case "setblock": setblock(c, t); break;
                case "gamerule": case "difficulty":
                    warn("world setting command ignored on purpose: " + line);
                    break;
                default:
                    warn("unsupported command: " + t.get(0));
            }
        } catch (RuntimeException ex) {
            warn("command failed: " + line + " -> " + ex);
        }
    }

    // =================================================================== selectors

    private static Selector selector(String s) {
        Selector sel = SELECTORS.get(s);
        if (sel == null) {
            sel = Selector.parse(s);
            if (SELECTORS.size() > 4096) SELECTORS.clear();
            SELECTORS.put(s, sel);
        }
        return sel;
    }

    private static final class T implements Selector.Target {
        final Entity e;
        final ServerLevel level;

        T(Entity e, ServerLevel level) {
            this.e = e;
            this.level = level;
        }

        public boolean isPlayer() { return e instanceof Player; }

        public boolean isType(String type) {
            if (e instanceof BedrockEntity b) return b.def().id().equals(type);
            if (e instanceof Player) return type.equals("player");
            if (e instanceof ItemEntity) return type.equals("item");
            ResourceLocation k = ForgeRegistries.ENTITY_TYPES.getKey(e.getType());
            if (k == null) return false;
            String p = k.getPath();
            return type.equals(p) || (type.equals("xp_orb") && p.equals("experience_orb")) || type.equals(k.toString());
        }

        public boolean inFamily(String family) { return McFilterContext.hasFamily(e, family); }

        public boolean hasTag(String tag) { return e.getTags().contains(tag); }

        public String name() { return e.getName().getString(); }

        public int gameMode() {
            return e instanceof ServerPlayer p ? p.gameMode.getGameModeForPlayer().getId() : -1;
        }

        public Integer score(String objective) {
            Scoreboard sb = level.getScoreboard();
            Objective o = sb.getObjective(objective);
            if (o == null || !sb.hasPlayerScore(e.getScoreboardName(), o)) return null;
            return sb.getOrCreatePlayerScore(e.getScoreboardName(), o).getScore();
        }

        public double x() { return e.getX(); }
        public double y() { return e.getY(); }
        public double z() { return e.getZ(); }
        public double width() { return e.getBbWidth(); }
        public double height() { return e.getBbHeight(); }
        public double yaw() { return e.getYRot(); }
        public double pitch() { return e.getXRot(); }
        public int xpLevel() { return e instanceof Player p ? p.experienceLevel : 0; }
    }

    private static List<Entity> select(Ctx c, String selStr) {
        Selector sel = selector(selStr);
        MinecraftServer server = c.level.getServer();
        List<T> cands = new ArrayList<>();
        if (sel.isSelf()) {
            if (c.self == null) return new ArrayList<>();
        } else if (sel.kind == 'a' || sel.kind == 'p' || sel.kind == 'n') {
            for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                if (sel.spatial() && p.level() != c.level) continue;
                cands.add(new T(p, p.serverLevel()));
            }
        } else {
            double r = sel.maxRadius();
            Iterable<Entity> src;
            if (!Double.isNaN(r) && !sel.hasOriginOverride()) {
                src = c.level.getEntities((Entity) null, new AABB(c.x - r, c.y - r, c.z - r, c.x + r, c.y + r, c.z + r), x -> true);
            } else {
                src = c.level.getAllEntities();
            }
            for (Entity e : src) if (e.isAlive() || e instanceof Player) cands.add(new T(e, c.level));
        }
        T self = c.self == null ? null : new T(c.self, c.level);
        List<T> res = sel.select(cands, c.x, c.y, c.z, self, RNG);
        List<Entity> out = new ArrayList<>(res.size());
        for (T t : res) out.add(t.e);
        return out;
    }

    private static List<ServerPlayer> players(Ctx c, String selStr) {
        List<ServerPlayer> out = new ArrayList<>();
        for (Entity e : select(c, selStr)) if (e instanceof ServerPlayer p) out.add(p);
        return out;
    }

    private static boolean isCoordToken(String s) {
        if (s.isEmpty()) return false;
        char ch = s.charAt(0);
        return ch == '~' || ch == '^' || ch == '-' || ch == '+' || ch == '.' || Character.isDigit(ch);
    }

    // =================================================================== execute

    private static double[] resolve(Ctx c, Pos p) {
        double oy = c.y;
        if (p.isLocal() && c.eyes && c.self != null) oy += c.self.getEyeHeight();
        return p.resolve(c.x, oy, c.z, c.yaw, c.pitch);
    }

    private static void face(Ctx c, double tx, double ty, double tz) {
        double oy = c.y + (c.eyes && c.self != null ? c.self.getEyeHeight() : 0);
        double dx = tx - c.x, dy = ty - oy, dz = tz - c.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        c.yaw = (float) (Math.toDegrees(Math.atan2(-dx, dz)));
        c.pitch = (float) (-Math.toDegrees(Math.atan2(dy, h)));
    }

    private static void walk(Ctx c, ExecChain ch, int idx, int depth) {
        if (idx >= ch.stages.size()) {
            if (ch.run != null) exec(c, ch.run, depth + 1);
            return;
        }
        ExecChain.Stage s = ch.stages.get(idx);
        switch (s.kind) {
            case AS:
                for (Entity e : select(c, s.sel)) {
                    Ctx n = c.copy();
                    n.self = e;
                    walk(n, ch, idx + 1, depth);
                }
                return;
            case AT:
                for (Entity e : select(c, s.sel)) {
                    Ctx n = c.copy();
                    n.x = e.getX();
                    n.y = e.getY();
                    n.z = e.getZ();
                    n.yaw = e.getYRot();
                    n.pitch = e.getXRot();
                    walk(n, ch, idx + 1, depth);
                }
                return;
            case POSITIONED: {
                Ctx n = c.copy();
                boolean local = s.pos.isLocal();
                double[] p = resolve(c, s.pos);
                n.x = p[0];
                n.y = p[1];
                n.z = p[2];
                if (local) n.eyes = false; // the eye offset is already part of the new position
                walk(n, ch, idx + 1, depth);
                return;
            }
            case POSITIONED_AS:
                for (Entity e : select(c, s.sel)) {
                    Ctx n = c.copy();
                    n.x = e.getX();
                    n.y = e.getY();
                    n.z = e.getZ();
                    walk(n, ch, idx + 1, depth);
                }
                return;
            case ROTATED: {
                Ctx n = c.copy();
                n.yaw = (float) Pos.rot(s.yaw, c.yaw);
                n.pitch = (float) Pos.rot(s.pitch, c.pitch);
                walk(n, ch, idx + 1, depth);
                return;
            }
            case ROTATED_AS:
                for (Entity e : select(c, s.sel)) {
                    Ctx n = c.copy();
                    n.yaw = e.getYRot();
                    n.pitch = e.getXRot();
                    walk(n, ch, idx + 1, depth);
                }
                return;
            case ANCHORED: {
                Ctx n = c.copy();
                n.eyes = "eyes".equals(s.sel);
                walk(n, ch, idx + 1, depth);
                return;
            }
            case FACING_POS: {
                Ctx n = c.copy();
                double[] p = resolve(c, s.pos);
                face(n, p[0], p[1], p[2]);
                walk(n, ch, idx + 1, depth);
                return;
            }
            case FACING_ENTITY: {
                List<Entity> l = select(c, s.sel);
                if (l.isEmpty()) return;
                Ctx n = c.copy();
                face(n, l.get(0).getX(), l.get(0).getY(), l.get(0).getZ());
                walk(n, ch, idx + 1, depth);
                return;
            }
            case IF_ENTITY:
                if (select(c, s.sel).isEmpty() != s.negate) return;
                break;
            case IF_BLOCK: {
                double[] p = resolve(c, s.pos);
                if (blockMatches(c.level, BlockPos.containing(p[0], p[1], p[2]), s.sel) == s.negate) return;
                break;
            }
            case IF_SCORE_MATCHES: {
                boolean any = false;
                for (Entity e : select(c, s.sel)) {
                    Integer v = new T(e, c.level).score(s.objective);
                    if (v != null && s.range.test(v)) any = true;
                }
                if (any == s.negate) return;
                break;
            }
            case IF_SCORE_COMPARE: {
                boolean ok = false;
                List<Entity> a = select(c, s.sel), b = select(c, s.source);
                if (!a.isEmpty() && !b.isEmpty()) {
                    Integer va = new T(a.get(0), c.level).score(s.objective), vb = new T(b.get(0), c.level).score(s.objective2);
                    if (va != null && vb != null) {
                        switch (s.op) {
                            case "=": ok = va.intValue() == vb.intValue(); break;
                            case "<": ok = va < vb; break;
                            case "<=": ok = va <= vb; break;
                            case ">": ok = va > vb; break;
                            case ">=": ok = va >= vb; break;
                            default: break;
                        }
                    }
                }
                if (ok == s.negate) return;
                break;
            }
            default:
                break; // ALIGN, IN: ignored
        }
        walk(c, ch, idx + 1, depth);
    }

    private static boolean blockMatches(ServerLevel level, BlockPos pos, String id) {
        if (!level.isLoaded(pos)) return false; // unloaded chunks never match (also avoids loading chunks)
        BlockState st = level.getBlockState(pos);
        String name = id.startsWith("minecraft:") ? id.substring(10) : id;
        if (name.equals("air")) return st.isAir();
        if (name.equals("leaves") || name.equals("leaves2")) return st.is(BlockTags.LEAVES);
        Block b = blockById(id);
        return b != null && st.is(b);
    }

    private static Block blockById(String id) {
        ResourceLocation rl;
        int col = id.indexOf(':');
        if (col >= 0 && (id.startsWith("ho:") || id.startsWith("bd:"))) rl = new ResourceLocation("sirenhead", id.substring(col + 1));
        else rl = new ResourceLocation(id.contains(":") ? id : "minecraft:" + id);
        return ForgeRegistries.BLOCKS.containsKey(rl) ? ForgeRegistries.BLOCKS.getValue(rl) : null;
    }

    private static void function(Ctx c, List<String> t, int depth) {
        String path = t.get(1);
        String text = BedrockLibraries.source().readText(BedrockPaths.BP + "/functions/" + path + ".mcfunction");
        if (text == null) {
            warn("unknown function " + path);
            return;
        }
        for (String line : text.split("\\r?\\n")) exec(c, line, depth + 1);
    }

    // =================================================================== simple commands

    private static DamageSource damageSource(Ctx c, String cause, Entity attacker) {
        var ds = c.level.damageSources();
        LivingEntity la = attacker instanceof LivingEntity l ? l : null;
        switch (cause == null ? "" : cause) {
            case "magic":
                return la != null ? ds.indirectMagic(la, la) : ds.magic();
            case "fire":
            case "fire_tick":
                return ds.onFire();
            case "void":
                return ds.fellOutOfWorld();
            case "fall":
                return ds.fall();
            default:
                return la != null ? ds.mobAttack(la) : ds.generic();
        }
    }

    private static void damage(Ctx c, List<String> t) {
        float amount = Float.parseFloat(t.get(2));
        String cause = t.size() > 3 ? t.get(3) : null;
        Entity attacker = null;
        if (t.size() > 5 && t.get(4).equals("entity")) {
            List<Entity> a = select(c, t.get(5));
            if (!a.isEmpty()) attacker = a.get(0);
        }
        for (Entity e : select(c, t.get(1))) {
            if (e instanceof LivingEntity le && le != attacker) le.hurt(damageSource(c, cause, attacker), amount);
        }
    }

    private static MobEffect effectById(String name) {
        String n = name.startsWith("minecraft:") ? name.substring(10) : name;
        ResourceLocation rl = new ResourceLocation("minecraft", n);
        return ForgeRegistries.MOB_EFFECTS.containsKey(rl) ? ForgeRegistries.MOB_EFFECTS.getValue(rl) : null;
    }

    private static void effect(Ctx c, List<String> t) {
        List<Entity> targets = select(c, t.get(1));
        if (t.size() < 3) return;
        String what = t.get(2);
        if (what.equals("clear")) {
            MobEffect only = t.size() > 3 ? effectById(t.get(3)) : null;
            for (Entity e : targets) {
                if (!(e instanceof LivingEntity le)) continue;
                if (only == null) le.removeAllEffects();
                else le.removeEffect(only);
            }
            return;
        }
        MobEffect eff = effectById(what);
        if (eff == null) {
            warn("unknown effect " + what);
            return;
        }
        double seconds = t.size() > 3 ? Double.parseDouble(t.get(3)) : 30;
        int amp = t.size() > 4 ? Math.min(255, Integer.parseInt(t.get(4))) : 0;
        boolean hide = t.size() > 5 && t.get(5).equals("true");
        for (Entity e : targets) {
            if (!(e instanceof LivingEntity le)) continue;
            if (seconds <= 0) {
                le.removeEffect(eff);
                continue;
            }
            int ticks = eff.isInstantenous() ? 1 : (int) Math.min(Integer.MAX_VALUE / 2.0, seconds * 20.0);
            le.addEffect(new MobEffectInstance(eff, ticks, amp, false, !hide));
        }
    }

    private static void kill(Ctx c, List<String> t) {
        List<Entity> l = t.size() > 1 ? select(c, t.get(1)) : (c.self == null ? new ArrayList<>() : List.of(c.self));
        for (Entity e : l) {
            if (e instanceof ServerPlayer p) p.hurt(c.level.damageSources().genericKill(), Float.MAX_VALUE);
            else e.kill();
        }
    }

    private static void tp(Ctx c, List<String> t) {
        int i = 1;
        List<Entity> victims;
        double[] dest = null;
        Entity destEntity = null;
        if (isCoordToken(t.get(i))) {
            victims = c.self == null ? new ArrayList<>() : List.of(c.self);
        } else {
            victims = select(c, t.get(i));
            i++;
            if (i < t.size() && !isCoordToken(t.get(i))) {
                List<Entity> d = select(c, t.get(i));
                if (d.isEmpty()) return;
                destEntity = d.get(0);
                i++;
            } else if (i >= t.size()) {
                // tp <destination>: the first selector was the destination for the executor
                if (!victims.isEmpty() && c.self != null) {
                    destEntity = victims.get(0);
                    victims = List.of(c.self);
                } else return;
            }
        }
        float yaw = c.yaw, pitch = c.pitch;
        boolean setRot = false;
        if (destEntity == null) {
            Pos.Parsed p = Pos.parse(t, i);
            i += p.used;
            dest = resolve(c, p.pos);
        } else {
            dest = new double[]{destEntity.getX(), destEntity.getY(), destEntity.getZ()};
        }
        if (i < t.size() && t.get(i).equals("facing")) {
            i++;
            double[] f;
            if (i < t.size() && isCoordToken(t.get(i))) {
                f = resolve(c, Pos.parse(t, i).pos);
            } else {
                List<Entity> fe = select(c, t.get(i));
                if (fe.isEmpty()) return; // Bedrock: the command fails when the facing target does not exist
                f = new double[]{fe.get(0).getX(), fe.get(0).getEyeY(), fe.get(0).getZ()};
            }
            double dx = f[0] - dest[0], dz = f[2] - dest[2];
            double dy = f[1] - (dest[1]);
            yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
            pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
            setRot = true;
        } else if (i < t.size() && isCoordToken(t.get(i))) {
            List<Pos.Coord> rc = new ArrayList<>();
            while (rc.size() < 2 && i < t.size() && isCoordToken(t.get(i))) rc.addAll(Pos.parseToken(t.get(i++)));
            if (rc.size() >= 2) {
                yaw = (float) Pos.rot(rc.get(0), c.yaw);
                pitch = (float) Pos.rot(rc.get(1), c.pitch);
                setRot = true;
            }
        }
        boolean void_ = Math.abs(dest[0]) > 3.0E7 || Math.abs(dest[2]) > 3.0E7 || dest[1] < -4096 || dest[1] > 4096;
        for (Entity v : victims) {
            if (void_) {
                if (!(v instanceof Player)) v.discard(); // the add-on "teleports" mobs out of the world to get rid of them
                continue;
            }
            if (v instanceof ServerPlayer sp) {
                sp.teleportTo(c.level, dest[0], dest[1], dest[2], setRot ? yaw : sp.getYRot(), setRot ? pitch : sp.getXRot());
            } else {
                v.moveTo(dest[0], dest[1], dest[2], setRot ? yaw : v.getYRot(), setRot ? pitch : v.getXRot());
                if (setRot && v instanceof LivingEntity le) {
                    le.setYHeadRot(yaw);
                    le.setYBodyRot(yaw);
                }
            }
        }
    }

    private static void summon(Ctx c, List<String> t) {
        String id = t.get(1);
        double[] p = {c.x, c.y, c.z};
        int i = 2;
        if (i < t.size() && isCoordToken(t.get(i))) {
            Pos.Parsed pp = Pos.parse(t, i);
            i += pp.used;
            p = resolve(c, pp.pos);
        }
        float yaw = c.yaw, pitch = c.pitch;
        if (i < t.size() && isCoordToken(t.get(i))) {
            List<Pos.Coord> rc = new ArrayList<>();
            while (rc.size() < 2 && i < t.size() && isCoordToken(t.get(i))) rc.addAll(Pos.parseToken(t.get(i++)));
            if (rc.size() >= 2) {
                yaw = (float) Pos.rot(rc.get(0), c.yaw);
                pitch = (float) Pos.rot(rc.get(1), c.pitch);
            }
        }
        String event = i < t.size() ? t.get(i) : null;
        String[] spec = BedrockSpawn.splitEvent(id);
        Entity e = BedrockSpawn.spawn(c.level, spec[0], p[0], p[1], p[2], yaw, pitch, event != null ? event : spec[1]);
        if (e instanceof BedrockEntity be && c.self != null) be.setBedrockOwner(c.self);
    }

    private static void particle(Ctx c, List<String> t) {
        double[] p = {c.x, c.y, c.z};
        if (t.size() > 2) p = resolve(c, Pos.parse(t, 2).pos);
        BedrockNetwork.toNear(c.level, p[0], p[1], p[2], 96, new BedrockNetwork.SpawnParticle(t.get(1), p[0], p[1], p[2], c.yaw));
    }

    private static void playAnimation(Ctx c, List<String> t) {
        String anim = t.get(2);
        String next = t.size() > 3 ? t.get(3) : null;
        float blend = t.size() > 4 ? Float.parseFloat(t.get(4)) : 0f;
        String stop = t.size() > 5 ? t.get(5) : null;
        String ctl = t.size() > 6 ? t.get(6) : null;
        for (Entity e : select(c, t.get(1))) {
            if (e instanceof Player) continue; // player models are not GeckoLib models
            BedrockNetwork.toTracking(e, new BedrockNetwork.PlayAnim(e.getId(), anim, next, blend, stop, ctl));
        }
    }

    private static SoundEvent sound(String name) {
        return SOUNDS.computeIfAbsent(name, n -> SoundEvent.createVariableRangeEvent(new ResourceLocation(SirenHeadMod.MOD_ID, n)));
    }

    private static void playSound(Ctx c, List<String> t) {
        SoundEvent ev = sound(t.get(1));
        float vol = 1f, pitch = 1f;
        double[] pos = null;
        List<ServerPlayer> targets = null;
        if (t.size() > 2) targets = players(c, t.get(2));
        if (t.size() > 3) pos = resolve(c, Pos.parse(t, 3).pos);
        int vi = t.size() > 3 ? 3 + Pos.parse(t, 3).used : 3;
        if (t.size() > vi) vol = Float.parseFloat(t.get(vi));
        if (t.size() > vi + 1) pitch = Float.parseFloat(t.get(vi + 1));
        if (targets == null) {
            double[] p = pos != null ? pos : new double[]{c.x, c.y, c.z};
            c.level.playSound(null, p[0], p[1], p[2], ev, SoundSource.HOSTILE, Math.max(vol, 1f) * 4f, pitch);
            return;
        }
        for (ServerPlayer p : targets) {
            double[] at = pos != null ? pos : new double[]{p.getX(), p.getY(), p.getZ()};
            p.connection.send(new ClientboundSoundPacket(Holder.direct(ev), SoundSource.HOSTILE, at[0], at[1], at[2], vol, pitch, c.level.random.nextLong()));
        }
    }

    private static void stopSound(Ctx c, List<String> t) {
        ResourceLocation rl = t.size() > 2 ? new ResourceLocation(SirenHeadMod.MOD_ID, t.get(2)) : null;
        for (ServerPlayer p : players(c, t.get(1))) p.connection.send(new ClientboundStopSoundPacket(rl, null));
    }

    private static void cameraShake(Ctx c, List<String> t) {
        String mode = t.get(1);
        if (mode.equals("stop")) {
            for (ServerPlayer p : players(c, t.get(2))) BedrockNetwork.toPlayer(p, new BedrockNetwork.CameraShake(0, 0, true));
            return;
        }
        float intensity = Float.parseFloat(t.get(3));
        float seconds = t.size() > 4 ? Float.parseFloat(t.get(4)) : 1f;
        boolean positional = t.size() <= 5 || !t.get(5).equals("rotational");
        for (ServerPlayer p : players(c, t.get(2))) BedrockNetwork.toPlayer(p, new BedrockNetwork.CameraShake(intensity, seconds, positional));
    }

    private static void camera(Ctx c, List<String> t) {
        List<ServerPlayer> ps = players(c, t.get(1));
        if (t.size() < 3) return;
        String sub = t.get(2);
        if (sub.equals("clear")) {
            for (ServerPlayer p : ps) BedrockNetwork.toPlayer(p, new BedrockNetwork.CameraSet(false, 0, 0, 0, -1, false, 0, 0, 0));
            return;
        }
        if (!sub.equals("set")) return; // fade / target_ ... are not supported
        double[] pos = {c.x, c.y, c.z};
        int facingEntity = -1;
        boolean hasFacingPos = false;
        double[] fp = {0, 0, 0};
        for (int i = 4; i < t.size(); i++) {
            String k = t.get(i);
            if (k.equals("pos")) {
                Pos.Parsed pp = Pos.parse(t, i + 1);
                pos = resolve(c, pp.pos);
                i += pp.used;
            } else if (k.equals("facing") && i + 1 < t.size()) {
                if (isCoordToken(t.get(i + 1))) {
                    Pos.Parsed pp = Pos.parse(t, i + 1);
                    fp = resolve(c, pp.pos);
                    hasFacingPos = true;
                    i += pp.used;
                } else {
                    List<Entity> f = select(c, t.get(i + 1));
                    if (!f.isEmpty()) facingEntity = f.get(0).getId();
                    i++;
                }
            }
        }
        for (ServerPlayer p : ps) BedrockNetwork.toPlayer(p, new BedrockNetwork.CameraSet(true, pos[0], pos[1], pos[2], facingEntity, hasFacingPos, fp[0], fp[1], fp[2]));
    }

    private static void inputPermission(Ctx c, List<String> t) {
        if (t.size() < 5 || !t.get(1).equals("set")) return;
        boolean enabled = t.get(4).equals("enabled");
        for (ServerPlayer p : players(c, t.get(2))) {
            boolean[] st = INPUT.computeIfAbsent(p.getUUID(), k -> new boolean[]{true, true});
            if (t.get(3).equals("movement")) st[0] = enabled;
            else if (t.get(3).equals("camera")) st[1] = enabled;
            BedrockNetwork.toPlayer(p, new BedrockNetwork.InputPermission(st[0], st[1]));
            if (st[0] && st[1]) INPUT.remove(p.getUUID());
        }
    }

    private static void ride(Ctx c, List<String> t) {
        List<Entity> subjects = select(c, t.get(1));
        if (t.size() < 3) return;
        switch (t.get(2)) {
            case "start_riding": {
                List<Entity> rides = select(c, t.get(3));
                if (rides.isEmpty()) return;
                Entity mount = rides.get(0);
                boolean tpRider = t.contains("teleport_rider");
                for (Entity rider : subjects) {
                    if (rider == mount) continue;
                    if (tpRider) rider.teleportTo(mount.getX(), mount.getY(), mount.getZ());
                    rider.startRiding(mount, true);
                }
                break;
            }
            case "stop_riding":
                for (Entity e : subjects) e.stopRiding();
                break;
            case "evict_riders":
                for (Entity e : subjects) e.ejectPassengers();
                break;
            case "summon_rider": {
                String[] spec = BedrockSpawn.splitEvent(t.get(3));
                for (Entity e : subjects) {
                    Entity r = BedrockSpawn.spawn(c.level, spec[0], e.getX(), e.getY(), e.getZ(), e.getYRot(), 0, t.size() > 4 ? t.get(4) : spec[1]);
                    if (r != null) r.startRiding(e, true);
                }
                break;
            }
            case "summon_ride": {
                String[] spec = BedrockSpawn.splitEvent(t.get(3));
                for (Entity e : subjects) {
                    Entity r = BedrockSpawn.spawn(c.level, spec[0], e.getX(), e.getY(), e.getZ(), e.getYRot(), 0, spec[1]);
                    if (r != null) e.startRiding(r, true);
                }
                break;
            }
            default:
                break;
        }
    }

    private static void tag(Ctx c, List<String> t) {
        if (t.size() < 4) return;
        for (Entity e : select(c, t.get(1))) {
            if (t.get(2).equals("add")) e.addTag(t.get(3));
            else if (t.get(2).equals("remove")) e.removeTag(t.get(3));
        }
    }

    private static void event(Ctx c, List<String> t) {
        // event entity <selector> <event>
        if (t.size() < 4) return;
        for (Entity e : select(c, t.get(2))) if (e instanceof BedrockEntity be) be.triggerEvent(t.get(3), c.self);
    }

    // =================================================================== scoreboard

    private static String scoreName(Ctx c, String who, List<Entity> out) {
        if (Lex.isSelector(who)) {
            out.addAll(select(c, who));
            return null;
        }
        return who.replace("\"", "");
    }

    private static void scoreboard(Ctx c, List<String> t) {
        Scoreboard sb = c.level.getScoreboard();
        if (t.size() < 3) return;
        if (t.get(1).equals("objectives")) {
            if (t.get(2).equals("add") && t.size() >= 4) {
                if (sb.getObjective(t.get(3)) == null) {
                    String display = t.size() > 5 ? Lex.rest(t, 5).replace("\"", "") : t.get(3);
                    sb.addObjective(t.get(3), ObjectiveCriteria.DUMMY, Component.literal(display), ObjectiveCriteria.RenderType.INTEGER);
                }
            } else if (t.get(2).equals("remove") && t.size() >= 4) {
                Objective o = sb.getObjective(t.get(3));
                if (o != null) sb.removeObjective(o);
            }
            return;
        }
        if (!t.get(1).equals("players") || t.size() < 5) return;
        String op = t.get(2);
        Objective obj = sb.getObjective(t.get(4));
        if (obj == null) {
            warn("scoreboard objective missing: " + t.get(4));
            return;
        }
        List<Entity> ents = new ArrayList<>();
        String fake = scoreName(c, t.get(3), ents);
        List<String> names = new ArrayList<>();
        if (fake != null) names.add(fake);
        for (Entity e : ents) names.add(e.getScoreboardName());
        for (String n : names) {
            switch (op) {
                case "add": sb.getOrCreatePlayerScore(n, obj).add(Integer.parseInt(t.get(5))); break;
                case "remove": sb.getOrCreatePlayerScore(n, obj).add(-Integer.parseInt(t.get(5))); break;
                case "set": sb.getOrCreatePlayerScore(n, obj).setScore(Integer.parseInt(t.get(5))); break;
                case "reset": sb.resetPlayerScore(n, obj); break;
                case "random": {
                    int lo = Integer.parseInt(t.get(5)), hi = Integer.parseInt(t.get(6));
                    sb.getOrCreatePlayerScore(n, obj).setScore(lo + RNG.nextInt(Math.max(1, hi - lo + 1)));
                    break;
                }
                default:
                    break;
            }
        }
    }

    // =================================================================== chat / players / blocks

    private static String expandSelectors(Ctx c, String msg) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < msg.length(); i++) {
            char ch = msg.charAt(i);
            if (ch == '@' && i + 1 < msg.length() && "aepsr".indexOf(msg.charAt(i + 1)) >= 0) {
                List<Entity> l = select(c, msg.substring(i, i + 2));
                StringBuilder names = new StringBuilder();
                for (Entity e : l) {
                    if (names.length() > 0) names.append(", ");
                    names.append(e.getName().getString());
                }
                out.append(names);
                i++;
            } else out.append(ch);
        }
        return out.toString();
    }

    private static void say(Ctx c, List<String> t) {
        String msg = expandSelectors(c, Lex.rest(t, 1));
        String who = c.self == null ? "Server" : c.self.getName().getString();
        c.level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("[" + who + "] " + msg), false);
    }

    private static void tell(Ctx c, List<String> t) {
        String msg = expandSelectors(c, Lex.rest(t, 2));
        for (ServerPlayer p : players(c, t.get(1))) p.sendSystemMessage(Component.literal(msg));
    }

    private static void title(Ctx c, List<String> t) {
        if (t.size() < 4) return;
        Component text = Component.literal(expandSelectors(c, Lex.rest(t, 3)));
        for (ServerPlayer p : players(c, t.get(1))) {
            switch (t.get(2)) {
                case "title": p.connection.send(new ClientboundSetTitleTextPacket(text)); break;
                case "subtitle": p.connection.send(new ClientboundSetSubtitleTextPacket(text)); break;
                case "actionbar": p.connection.send(new ClientboundSetActionBarTextPacket(text)); break;
                default: break;
            }
        }
    }

    private static void gamemode(Ctx c, List<String> t) {
        GameType gt;
        switch (t.get(1)) {
            case "s": case "survival": case "0": gt = GameType.SURVIVAL; break;
            case "c": case "creative": case "1": gt = GameType.CREATIVE; break;
            case "a": case "adventure": case "2": gt = GameType.ADVENTURE; break;
            case "spectator": case "6": gt = GameType.SPECTATOR; break;
            default: return;
        }
        List<ServerPlayer> targets;
        if (t.size() > 2) targets = players(c, Lex.isSelector(t.get(2)) ? t.get(2) : Lex.rest(t, 2));
        else targets = c.self instanceof ServerPlayer sp ? List.of(sp) : List.of();
        for (ServerPlayer p : targets) p.setGameMode(gt);
    }

    private static void setblock(Ctx c, List<String> t) {
        Pos.Parsed pp = Pos.parse(t, 1);
        double[] p = resolve(c, pp.pos);
        int bi = 1 + pp.used;
        if (bi >= t.size()) return;
        Block b = blockById(t.get(bi));
        if (b == null) {
            warn("unknown block " + t.get(bi));
            return;
        }
        BlockPos bp = BlockPos.containing(p[0], p[1], p[2]);
        if (c.level.isLoaded(bp)) c.level.setBlock(bp, b.defaultBlockState(), 3);
    }
}
