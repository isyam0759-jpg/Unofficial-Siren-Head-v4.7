package com.sirenhead.mod.item;

import com.sirenhead.mod.BedrockEntities;
import com.sirenhead.mod.SirenHeadMod;
import com.sirenhead.mod.block.SirenBlocks;
import com.sirenhead.mod.entity.BedrockEntity;
import com.sirenhead.mod.entity.BedrockEntityDef;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Items of the add-on: block items, one spawn egg per spawnable entity, and (see {@link SirenGear}) weapons and armor. */
public final class SirenItems {
    private SirenItems() {
    }

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, SirenHeadMod.MOD_ID);

    /** Every registered item in creative-tab order. */
    public static final List<RegistryObject<? extends Item>> ALL = new ArrayList<>();
    public static final Map<String, RegistryObject<Item>> SPAWN_EGGS = new LinkedHashMap<>();

    public static RegistryObject<Item> SIREN_HEAD_HEAD;
    public static RegistryObject<Item> BD_LIGHTER;

    public static void register(IEventBus bus) {
        SIREN_HEAD_HEAD = ITEMS.register("siren_head_head", () -> new BlockItem(SirenBlocks.SIREN_HEAD_HEAD.get(), new Item.Properties()));
        BD_LIGHTER = ITEMS.register("bd_lighter", () -> new BlockItem(SirenBlocks.BD_LIGHTER.get(), new Item.Properties()));
        ALL.add(SIREN_HEAD_HEAD);
        ALL.add(BD_LIGHTER);

        for (BedrockEntityDef def : BedrockEntities.definitions()) {
            if (!def.behavior().spawnable()) continue;
            RegistryObject<EntityType<BedrockEntity>> type = BedrockEntities.TYPES.get(def.id());
            RegistryObject<Item> egg = ITEMS.register(def.javaPath() + "_spawn_egg",
                    () -> new ForgeSpawnEggItem(type, def.eggBase(), def.eggOverlay(), new Item.Properties()));
            SPAWN_EGGS.put(def.id(), egg);
            ALL.add(egg);
        }

        SirenGear.register(ITEMS, ALL);
        ITEMS.register(bus);
    }
}
