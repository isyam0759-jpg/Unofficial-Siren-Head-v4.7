package com.sirenhead.mod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.sirenhead.bedrock.anim.RenderControllerDef;
import com.sirenhead.mod.entity.BedrockEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

/** GeckoLib renderer for every add-on entity; geometry/texture/material are chosen by the Bedrock render controller. */
public class BedrockEntityRenderer extends GeoEntityRenderer<BedrockEntity> {
    public BedrockEntityRenderer(EntityRendererProvider.Context context) {
        super(context, new BedrockGeoModel());
    }

    @Override
    public void render(BedrockEntity entity, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight) {
        // resolves the render controller and advances the RP animator; must happen before GeckoLib asks for model/texture
        ClientEntityState.of(entity).update(partialTick);
        float s = entity.getBedrockScale();
        this.shadowRadius = Math.min(4f, 0.5f * entity.getBbWidth() * s);
        poseStack.pushPose();
        if (s != 1f) poseStack.scale(s, s, s);
        super.render(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
        poseStack.popPose();
    }

    @Override
    public RenderType getRenderType(BedrockEntity animatable, ResourceLocation texture, MultiBufferSource bufferSource, float partialTick) {
        RenderControllerDef.Choice c = ClientEntityState.of(animatable).choice();
        String material = c == null || c.material() == null ? "" : c.material();
        switch (material) {
            case "slime":
                return RenderType.entityTranslucent(texture);
            case "charged_creeper":
                return RenderType.eyes(texture);
            default:
                return RenderType.entityCutoutNoCull(texture);
        }
    }

    /** Add-on mobs do not tip over when they die. (Plain method on purpose: harmless if GeckoLib renames the hook.) */
    protected float getDeathMaxRotation(BedrockEntity animatable) {
        return 0f;
    }
}
