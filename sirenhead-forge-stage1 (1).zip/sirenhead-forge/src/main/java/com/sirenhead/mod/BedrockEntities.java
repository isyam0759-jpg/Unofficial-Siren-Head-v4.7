package com.sirenhead.mod;

import com.sirenhead.mod.entity.BedrockEntity;
import com.sirenhead.mod.entity.BedrockEntityDef;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.LinkedHashMap;
import java.util.Map;

/** One {@link EntityType} per BP entity (all backed by {@link BedrockEntity}). */
public final class BedrockEntities {
    private BedrockEntities() {
    }

    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, SirenHeadMod.MOD_ID);

    /** Keyed by Bedrock identifier. */
    public static final Map<String, RegistryObject<EntityType<BedrockEntity>>> TYPES = new LinkedHashMap<>();

    public static java.util.Collection<BedrockEntityDef> definitions() {
        return BedrockLibraries.entities().values();
    }

    public static void register(IEventBus bus) {
        for (BedrockEntityDef def : BedrockLibraries.entities().values()) {
            RegistryObject<EntityType<BedrockEntity>> ro = ENTITY_TYPES.register(def.javaPath(), () -> {
                EntityType.Builder<BedrockEntity> b = EntityType.Builder.<BedrockEntity>of((type, level) -> new BedrockEntity(type, level, def), def.category())
                        .sized(def.hitWidth(), def.hitHeight())
                        .clientTrackingRange(def.hitHeight() > 8 ? 32 : 10)
                        .updateInterval(2);
                if (def.fireImmune()) b.fireImmune();
                if (!def.behavior().summonable()) b.noSummon();
                return b.build(def.javaId().toString());
            });
            TYPES.put(def.id(), ro);
        }
        ENTITY_TYPES.register(bus);
    }

    public static AttributeSupplier.Builder attributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.ATTACK_DAMAGE, 0.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.0)
                .add(Attributes.FOLLOW_RANGE, 64.0);
    }

    public static void onAttributes(EntityAttributeCreationEvent event) {
        for (RegistryObject<EntityType<BedrockEntity>> ro : TYPES.values()) event.put(ro.get(), attributes().build());
    }

    /** Entity type for a Bedrock id (e.g. {@code ho:sirenhead}), or null. */
    public static EntityType<BedrockEntity> type(String bedrockId) {
        RegistryObject<EntityType<BedrockEntity>> ro = TYPES.get(bedrockId);
        return ro == null ? null : ro.get();
    }
}
