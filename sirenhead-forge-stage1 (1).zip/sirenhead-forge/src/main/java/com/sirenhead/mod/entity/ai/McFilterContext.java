package com.sirenhead.mod.entity.ai;

import com.sirenhead.bedrock.behavior.FilterContext;
import com.sirenhead.mod.entity.BedrockEntity;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.Pillager;
import net.minecraft.world.entity.monster.Ravager;
import net.minecraft.world.entity.monster.AbstractIllager;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.SnowGolem;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.npc.WanderingTrader;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.function.Function;

/** Bedrock filter facts for a Minecraft entity (optionally with the damage that is currently being processed). */
public final class McFilterContext implements FilterContext {
    private final Entity e;
    private final DamageSource damage;
    private final BedrockEntity behaviourOwner;

    public McFilterContext(Entity e, DamageSource damage, BedrockEntity behaviourOwner) {
        this.e = e;
        this.damage = damage;
        this.behaviourOwner = behaviourOwner;
    }

    /** subject -> context, for filters that talk about {@code self} and one {@code other} entity. */
    public static Function<String, FilterContext> subjects(BedrockEntity self, Entity other) {
        return s -> switch (s) {
            case "self" -> new McFilterContext(self, null, self);
            case "other", "target", "damager" -> other == null ? null : new McFilterContext(other, null, self);
            default -> null;
        };
    }

    @Override
    public Object fact(String test, String domain, String arg) {
        switch (test) {
            case "is_family":
                return arg != null && hasFamily(e, arg);
            case "has_damage":
                return damage != null && arg != null && causeMatches(damage, arg);
            case "has_tag":
                return arg != null && e.getTags().contains(arg);
            case "has_target":
                return e instanceof Mob m && m.getTarget() != null;
            case "target_distance": {
                if (e instanceof Mob m && m.getTarget() != null) return (double) m.distanceTo(m.getTarget());
                return 99999.0;
            }
            case "distance_to_nearest_player": {
                Player p = e.level().getNearestPlayer(e, -1);
                return p == null ? 99999.0 : (double) p.distanceTo(e);
            }
            case "hourly_clock_time":
                return (double) (e.level().getDayTime() % 24000L);
            case "on_ground":
                return e.onGround();
            case "in_water":
                return e.isInWater();
            case "is_riding":
                return e.isPassenger();
            case "is_sneaking":
                return e.isShiftKeyDown();
            case "has_equipment": {
                if (!(e instanceof LivingEntity l) || arg == null) return false;
                ItemStack st = l.getMainHandItem();
                if (st.isEmpty()) return false;
                ResourceLocation k = BuiltInRegistries.ITEM.getKey(st.getItem());
                return k.toString().equals(arg) || k.getPath().equals(arg);
            }
            default:
                return null;
        }
    }

    public static boolean hasFamily(Entity e, String fam) {
        if (e instanceof BedrockEntity b && b.families().contains(fam)) return true;
        switch (fam) {
            case "player":
                return e instanceof Player;
            case "monster":
                return e instanceof Enemy;
            case "mob":
                return e instanceof Mob;
            case "undead":
                return e instanceof LivingEntity l && l.getMobType() == MobType.UNDEAD;
            case "arthropod":
                return e instanceof LivingEntity l && l.getMobType() == MobType.ARTHROPOD;
            case "illager":
                return e instanceof AbstractIllager;
            case "pillager":
                return e instanceof Pillager;
            case "ravager":
                return e instanceof Ravager;
            case "villager":
                return e instanceof Villager;
            case "wandering_trader":
                return e instanceof WanderingTrader;
            case "irongolem":
                return e instanceof IronGolem;
            case "snowgolem":
                return e instanceof SnowGolem;
            case "inanimate":
                return !(e instanceof LivingEntity) || e instanceof ArmorStand;
            default:
                break;
        }
        ResourceLocation k = ForgeRegistries.ENTITY_TYPES.getKey(e.getType());
        return k != null && k.getPath().equals(fam);
    }

    /** Bedrock damage cause names -> Java damage sources. */
    public static boolean causeMatches(DamageSource s, String cause) {
        switch (cause) {
            case "all":
                return true;
            case "attack":
                return s.getMsgId().equals("mob") || s.getMsgId().equals("player");
            case "projectile":
                return s.is(DamageTypeTags.IS_PROJECTILE);
            case "fall":
                return s.is(DamageTypeTags.IS_FALL);
            case "entity_explosion":
            case "block_explosion":
                return s.is(DamageTypeTags.IS_EXPLOSION);
            case "fire":
            case "fire_tick":
                return s.is(DamageTypeTags.IS_FIRE);
            case "drowning":
                return s.is(DamageTypeTags.IS_DROWNING);
            case "lightning":
                return s.is(DamageTypeTags.IS_LIGHTNING);
            case "lava":
                return s.getMsgId().equals("lava");
            case "suffocation":
                return s.getMsgId().equals("inWall");
            case "magic":
                return s.getMsgId().equals("magic");
            case "void":
                return s.getMsgId().equals("outOfWorld");
            case "suicide":
                return s.getMsgId().equals("genericKill") || s.getMsgId().equals("generic");
            case "contact":
                return s.getMsgId().equals("cactus") || s.getMsgId().equals("sweetBerryBush");
            default:
                return s.getMsgId().equalsIgnoreCase(cause);
        }
    }
}
