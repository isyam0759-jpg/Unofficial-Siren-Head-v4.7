package com.sirenhead.mod;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sirenhead.bedrock.BedrockPaths;
import com.sirenhead.bedrock.anim.BedrockAnimLibrary;
import com.sirenhead.bedrock.anim.Rig;
import com.sirenhead.bedrock.behavior.BehaviorDef;
import com.sirenhead.bedrock.json.Jsons;
import com.sirenhead.bedrock.particle.ParticleLibrary;
import com.sirenhead.bedrock.res.ClasspathResourceSource;
import com.sirenhead.bedrock.res.ResourceSource;
import com.sirenhead.mod.entity.BedrockEntityDef;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Lazily loaded, immutable Bedrock libraries (read from the mod jar). */
public final class BedrockLibraries {
    private BedrockLibraries() {
    }

    private static ResourceSource source;
    private static BedrockAnimLibrary rp;
    private static BedrockAnimLibrary bp;
    private static ParticleLibrary particles;
    private static Map<String, BedrockEntityDef> entities;
    private static Map<String, String> geoIndex;
    private static final Map<String, Rig> RIGS = new ConcurrentHashMap<>();

    public static synchronized ResourceSource source() {
        if (source == null) {
            source = new ClasspathResourceSource(BedrockLibraries.class.getClassLoader(), BedrockPaths.RP_INDEX, BedrockPaths.BP_INDEX);
        }
        return source;
    }

    /** Resource pack animations / controllers / client entities / render controllers (client). */
    public static synchronized BedrockAnimLibrary rp() {
        if (rp == null) rp = BedrockAnimLibrary.load(source(), BedrockPaths.RP);
        return rp;
    }

    /** Behavior pack animations / controllers (server). */
    public static synchronized BedrockAnimLibrary bp() {
        if (bp == null) bp = BedrockAnimLibrary.load(source(), BedrockPaths.BP);
        return bp;
    }

    public static synchronized ParticleLibrary particles() {
        if (particles == null) particles = ParticleLibrary.load(source(), BedrockPaths.RP);
        return particles;
    }

    /** Every BP entity, keyed by Bedrock identifier ({@code ho:sirenhead}). */
    public static synchronized Map<String, BedrockEntityDef> entities() {
        if (entities == null) {
            Map<String, BedrockEntityDef> m = new LinkedHashMap<>();
            ResourceSource src = source();
            for (String path : src.list(BedrockPaths.BP + "/entities", ".json")) {
                String text = src.readText(path);
                if (text == null) continue;
                try {
                    BehaviorDef b = BehaviorDef.parse(Jsons.parseObject(text));
                    m.put(b.identifier(), BedrockEntityDef.create(b));
                } catch (RuntimeException ex) {
                    SirenHeadMod.LOGGER.error("Cannot parse BP entity {}", path, ex);
                }
            }
            entities = Collections.unmodifiableMap(m);
        }
        return entities;
    }

    private static Map<String, com.sirenhead.bedrock.anim.ClientEntityDef> clientEntities;

    /** Client entity (RP) definitions, parsed without loading the animation library. */
    public static synchronized com.sirenhead.bedrock.anim.ClientEntityDef clientEntity(String bedrockId) {
        if (clientEntities == null) {
            Map<String, com.sirenhead.bedrock.anim.ClientEntityDef> m = new java.util.HashMap<>();
            ResourceSource src = source();
            for (String path : src.list(BedrockPaths.RP + "/entity", ".json")) {
                String text = src.readText(path);
                if (text == null) continue;
                try {
                    com.sirenhead.bedrock.anim.ClientEntityDef cd = com.sirenhead.bedrock.anim.ClientEntityDef.parse(Jsons.parseObject(text));
                    if (cd != null && cd.identifier() != null) m.put(cd.identifier(), cd);
                } catch (RuntimeException ex) {
                    SirenHeadMod.LOGGER.error("Cannot parse client entity {}", path, ex);
                }
            }
            clientEntities = m;
        }
        return clientEntities.get(bedrockId);
    }

    public static BedrockEntityDef entity(String bedrockId) {
        return entities().get(bedrockId);
    }

    /** {@code geometry.siren_head_bd} -> {@code sirenhead:geo/siren_head_bd.geo.json}; null if unknown. */
    public static synchronized String geoResource(String geometryId) {
        if (geoIndex == null) {
            Map<String, String> m = new java.util.HashMap<>();
            String text = source().readText(BedrockPaths.GEOMETRY_INDEX);
            if (text != null) {
                JsonObject o = Jsons.parseObject(text);
                for (Map.Entry<String, JsonElement> en : o.entrySet()) m.put(en.getKey(), en.getValue().getAsString());
            }
            geoIndex = m;
        }
        return geoIndex.get(geometryId);
    }

    /** Parsed rig (bones, pivots, locators) of a geometry, for locator world positions. */
    public static Rig rig(String geometryId) {
        return RIGS.computeIfAbsent(geometryId, id -> {
            String res = geoResource(id);
            if (res == null) return Rig.parse("{}");
            String path = "assets/" + res.replace(':', '/');
            String text = source().readText(path);
            return text == null ? Rig.parse("{}") : Rig.parse(text);
        });
    }
}
