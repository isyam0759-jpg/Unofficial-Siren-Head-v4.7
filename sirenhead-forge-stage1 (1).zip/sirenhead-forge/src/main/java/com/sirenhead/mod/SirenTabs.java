package com.sirenhead.mod;

import com.sirenhead.mod.item.SirenItems;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

/** Creative tab holding everything the add-on adds. */
public final class SirenTabs {
    private SirenTabs() {
    }

    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, SirenHeadMod.MOD_ID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.sirenhead.main"))
            .icon(() -> {
                var egg = SirenItems.SPAWN_EGGS.get("ho:sirenhead");
                if (egg != null) return new ItemStack(egg.get());
                return new ItemStack(SirenItems.SIREN_HEAD_HEAD.get());
            })
            .displayItems((params, output) -> {
                for (var ro : SirenItems.ALL) output.accept(ro.get());
            })
            .build());

    public static void register(IEventBus bus) {
        TABS.register(bus);
    }
}
