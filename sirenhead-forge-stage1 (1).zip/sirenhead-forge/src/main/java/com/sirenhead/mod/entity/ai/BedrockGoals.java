package com.sirenhead.mod.entity.ai;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sirenhead.bedrock.behavior.Filters;
import com.sirenhead.bedrock.json.Jsons;
import com.sirenhead.mod.entity.BedrockEntity;
import com.sirenhead.mod.server.command.BedrockSpawn;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

/** Java goals that implement the Bedrock {@code minecraft:behavior.*} components used by the add-on. */
public final class BedrockGoals {
    private BedrockGoals() {
    }

    private static boolean busy(BedrockEntity e) {
        return e.isStunned() || e.getHealth() <= 0;
    }

    // ------------------------------------------------------------------ random_stroll
    public static final class Stroll extends Goal {
        private final BedrockEntity mob;
        private final double speed;
        private final int interval;
        private final int xz;
        private final int y;
        private Vec3 wanted;

        public Stroll(BedrockEntity mob, JsonObject c) {
            this.mob = mob;
            this.speed = Jsons.num(c, "speed_multiplier", 1);
            this.interval = Math.max(1, (int) Jsons.num(c, "interval", 120));
            this.xz = (int) Jsons.num(c, "xz_dist", 10);
            this.y = (int) Jsons.num(c, "y_dist", 7);
            setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (busy(mob) || mob.isVehicle() || mob.getTarget() != null) return false;
            if (mob.getRandom().nextInt(interval) != 0) return false;
            wanted = DefaultRandomPos.getPos(mob, xz, y);
            return wanted != null;
        }

        @Override
        public boolean canContinueToUse() {
            return !mob.getNavigation().isDone() && !mob.isVehicle() && !busy(mob);
        }

        @Override
        public void start() {
            mob.getNavigation().moveTo(wanted.x, wanted.y, wanted.z, speed);
        }

        @Override
        public void stop() {
            mob.getNavigation().stop();
        }
    }

    // ------------------------------------------------------------------ melee_attack (also used as "stand and face the target")
    public static final class Melee extends Goal {
        private final BedrockEntity mob;
        private final double speed;
        private final double reach;
        private int cooldown;
        private int repath;

        public Melee(BedrockEntity mob, JsonObject c) {
            this.mob = mob;
            this.speed = Jsons.num(c, "speed_multiplier", 1);
            this.reach = Jsons.num(c, "reach_multiplier", 2);
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity t = mob.getTarget();
            return !busy(mob) && t != null && t.isAlive();
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }

        @Override
        public void start() {
            repath = 0;
        }

        @Override
        public void stop() {
            mob.getNavigation().stop();
        }

        @Override
        public void tick() {
            LivingEntity t = mob.getTarget();
            if (t == null) return;
            mob.getLookControl().setLookAt(t, 30f, 30f);
            if (speed > 0) {
                if (--repath <= 0) {
                    repath = 4 + mob.getRandom().nextInt(7);
                    mob.getNavigation().moveTo(t, speed);
                }
            } else {
                mob.getNavigation().stop();
            }
            if (cooldown > 0) cooldown--;
            double r = Math.max(1.0, mob.getBbWidth() * reach);
            if (cooldown <= 0 && mob.distanceToSqr(t) <= r * r + t.getBbWidth() && mob.getAttributeValue(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE) > 0) {
                cooldown = 20;
                mob.swing(net.minecraft.world.InteractionHand.MAIN_HAND);
                mob.doHurtTarget(t);
            }
        }
    }

    // ------------------------------------------------------------------ look_at_target
    public static final class LookAtTarget extends Goal {
        private final BedrockEntity mob;

        public LookAtTarget(BedrockEntity mob, JsonObject c) {
            this.mob = mob;
            setFlags(EnumSet.of(Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity t = mob.getTarget();
            return !busy(mob) && t != null && t.isAlive();
        }

        @Override
        public void tick() {
            LivingEntity t = mob.getTarget();
            if (t != null) mob.getLookControl().setLookAt(t, 30f, 30f);
        }
    }

    // ------------------------------------------------------------------ ranged_attack (+ minecraft:shooter)
    public static final class Ranged extends Goal {
        private final BedrockEntity mob;
        private final double radius;
        private final double shootAt;
        private final int burstShots;
        private final int burstInterval;
        private final String shooterDef;
        private int charge;
        private int cooldown;

        public Ranged(BedrockEntity mob, JsonObject c, String shooterDef) {
            this.mob = mob;
            this.radius = Jsons.num(c, "attack_radius", 16);
            this.shootAt = Jsons.num(c, "charge_shoot_trigger", 1.0);
            this.burstShots = Math.max(1, (int) Jsons.num(c, "burst_shots", 1));
            this.burstInterval = Math.max(1, (int) (Jsons.num(c, "burst_interval", 0.1) * 20));
            this.shooterDef = shooterDef;
            setFlags(EnumSet.of(Flag.LOOK, Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            LivingEntity t = mob.getTarget();
            return !busy(mob) && t != null && t.isAlive() && mob.distanceTo(t) <= radius;
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }

        @Override
        public void start() {
            charge = 0;
        }

        @Override
        public void stop() {
            mob.getNavigation().stop();
        }

        @Override
        public void tick() {
            LivingEntity t = mob.getTarget();
            if (t == null) return;
            mob.getLookControl().setLookAt(t, 30f, 30f);
            mob.getNavigation().stop();
            if (cooldown > 0) {
                cooldown--;
                return;
            }
            charge++;
            if (charge >= Math.max(1, (int) (shootAt * 20)) && shooterDef != null) {
                for (int i = 0; i < burstShots; i++) shoot(t);
                charge = 0;
                cooldown = burstInterval * burstShots + 20;
            }
        }

        private void shoot(LivingEntity t) {
            Vec3 from = mob.getEyePosition();
            Vec3 d = t.getEyePosition().subtract(from);
            float yaw = (float) (Mth.atan2(d.z, d.x) * (180.0 / Math.PI)) - 90.0f;
            float pitch = (float) -(Mth.atan2(d.y, Math.sqrt(d.x * d.x + d.z * d.z)) * (180.0 / Math.PI));
            Entity p = BedrockSpawn.spawn(mob.level(), shooterDef, from.x, from.y, from.z, yaw, pitch, null);
            if (p instanceof BedrockEntity be) be.setBedrockOwner(mob);
        }
    }

    // ------------------------------------------------------------------ delayed_attack
    public static final class DelayedAttack extends Goal {
        private final BedrockEntity mob;
        private final double speed;
        private final double reach;
        private final int duration;
        private final int hitAt;
        private int timer = -1;
        private int cooldown;
        private int repath;

        public DelayedAttack(BedrockEntity mob, JsonObject c) {
            this.mob = mob;
            this.speed = Jsons.num(c, "speed_multiplier", 1);
            this.reach = Jsons.num(c, "reach_multiplier", 2);
            this.duration = Math.max(1, (int) (Jsons.num(c, "attack_duration", 0.75) * 20));
            this.hitAt = (int) (duration * Jsons.num(c, "hit_delay_pct", 0.5));
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity t = mob.getTarget();
            return !busy(mob) && t != null && t.isAlive();
        }

        @Override
        public boolean canContinueToUse() {
            return canUse() || timer >= 0;
        }

        @Override
        public void stop() {
            timer = -1;
            mob.setFlag(BedrockEntity.F_DELAYED, false);
            mob.getNavigation().stop();
        }

        @Override
        public void tick() {
            LivingEntity t = mob.getTarget();
            if (t == null) {
                stop();
                return;
            }
            mob.getLookControl().setLookAt(t, 30f, 30f);
            double r = Math.max(1.0, mob.getBbWidth() * reach);
            if (timer >= 0) {
                timer++;
                if (timer == hitAt && mob.distanceToSqr(t) <= (r + t.getBbWidth()) * (r + t.getBbWidth())) mob.doHurtTarget(t);
                if (timer >= duration) {
                    timer = -1;
                    cooldown = 20;
                    mob.setFlag(BedrockEntity.F_DELAYED, false);
                }
                return;
            }
            if (--repath <= 0) {
                repath = 4 + mob.getRandom().nextInt(7);
                if (speed > 0) mob.getNavigation().moveTo(t, speed);
            }
            if (cooldown > 0) cooldown--;
            else if (mob.distanceToSqr(t) <= r * r) {
                timer = 0;
                mob.getNavigation().stop();
                mob.setFlag(BedrockEntity.F_DELAYED, true);
            }
        }
    }

    // ------------------------------------------------------------------ knockback_roar
    public static final class KnockbackRoar extends Goal {
        private final BedrockEntity mob;
        private final JsonObject c;
        private int age = -1;
        private int cooldown;

        public KnockbackRoar(BedrockEntity mob, JsonObject c) {
            this.mob = mob;
            this.c = c;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            if (cooldown > 0) {
                cooldown--;
                return false;
            }
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return age >= 0;
        }

        @Override
        public void start() {
            age = 0;
        }

        @Override
        public void tick() {
            age++;
            int attackTick = (int) (Jsons.num(c, "attack_time", 0.5) * 20);
            int end = Math.max(attackTick + 1, (int) (Jsons.num(c, "duration", 1.0) * 20));
            if (age == attackTick) roar();
            if (age >= end) {
                age = -1;
                cooldown = (int) (Jsons.num(c, "cooldown_time", 0.1) * 20);
                JsonObject ev = Jsons.obj(c, "on_roar_end");
                if (ev != null) mob.triggerEvent(Jsons.str(ev, "event", ""));
            }
        }

        private void roar() {
            double range = Jsons.num(c, "knockback_range", 4);
            double dmg = Jsons.num(c, "knockback_damage", 6);
            double hs = Jsons.num(c, "knockback_horizontal_strength", 3) * 0.4;
            double vs = Jsons.num(c, "knockback_vertical_strength", 3) * 0.2;
            JsonElement filters = c.get("knockback_filters");
            for (LivingEntity e : mob.level().getEntitiesOfClass(LivingEntity.class, mob.getBoundingBox().inflate(range))) {
                if (e == mob || e.distanceTo(mob) > range) continue;
                if (filters != null && !Filters.test(filtersWrap(filters), McFilterContext.subjects(mob, e))) continue;
                Vec3 d = e.position().subtract(mob.position());
                double h = Math.max(1.0E-4, Math.sqrt(d.x * d.x + d.z * d.z));
                e.hurt(mob.damageSources().mobAttack(mob), (float) dmg);
                e.push(d.x / h * hs, vs, d.z / h * hs);
                e.hurtMarked = true;
            }
        }

        private static JsonElement filtersWrap(JsonElement f) {
            return f;
        }
    }

    // ------------------------------------------------------------------ summon_entity (casting)
    public static final class Summon extends Goal {
        private final BedrockEntity mob;
        private final JsonArray choices;
        private JsonObject active;
        private int age = -1;
        private int cooldown;

        public Summon(BedrockEntity mob, JsonObject c) {
            this.mob = mob;
            this.choices = Jsons.arr(c, "summon_choices");
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            if (choices == null || busy(mob)) return false;
            if (cooldown > 0) {
                cooldown--;
                return false;
            }
            LivingEntity t = mob.getTarget();
            if (t == null) return false;
            double d = mob.distanceTo(t);
            List<JsonObject> ok = new ArrayList<>();
            for (JsonElement e : choices) {
                if (!e.isJsonObject()) continue;
                JsonObject o = e.getAsJsonObject();
                if (d >= Jsons.num(o, "min_activation_range", 0) && d <= Jsons.num(o, "max_activation_range", 1000)) ok.add(o);
            }
            if (ok.isEmpty()) return false;
            active = ok.get(mob.getRandom().nextInt(ok.size()));
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return age >= 0;
        }

        @Override
        public void start() {
            age = 0;
            mob.setFlag(BedrockEntity.F_CASTING, true);
            mob.getNavigation().stop();
        }

        @Override
        public void tick() {
            age++;
            LivingEntity t = mob.getTarget();
            if (t != null) mob.getLookControl().setLookAt(t, 30f, 30f);
            if (age >= (int) (Jsons.num(active, "cast_duration", 1) * 20)) {
                JsonArray seq = Jsons.arr(active, "sequence");
                if (seq != null && t != null) {
                    for (JsonElement e : seq) {
                        if (!e.isJsonObject()) continue;
                        JsonObject s = e.getAsJsonObject();
                        String type = Jsons.str(s, "entity_type", "");
                        int n = (int) Jsons.num(s, "num_entities_spawned", 1);
                        for (int i = 0; i < n && !type.isEmpty(); i++) {
                            Entity ne = BedrockSpawn.spawn(mob.level(), type, t.getX() + (mob.getRandom().nextDouble() - 0.5) * 2, t.getY(), t.getZ() + (mob.getRandom().nextDouble() - 0.5) * 2, 0, 0, null);
                            if (ne instanceof BedrockEntity be) be.setBedrockOwner(mob);
                        }
                    }
                }
                cooldown = (int) (Jsons.num(active, "cooldown_time", 5) * 20);
                age = -1;
            }
        }

        @Override
        public void stop() {
            age = -1;
            mob.setFlag(BedrockEntity.F_CASTING, false);
        }
    }

    // ------------------------------------------------------------------ lay_down
    public static final class LayDown extends Goal {
        private final BedrockEntity mob;
        private final int startInterval;
        private final int stopInterval;

        public LayDown(BedrockEntity mob, JsonObject c) {
            this.mob = mob;
            this.startInterval = Math.max(1, (int) Jsons.num(c, "random_interval", 200));
            this.stopInterval = Math.max(1, (int) Jsons.num(c, "random_stop_interval", 2000));
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            return mob.getTarget() == null && !mob.isVehicle() && mob.getRandom().nextInt(startInterval) == 0;
        }

        @Override
        public boolean canContinueToUse() {
            return mob.getTarget() == null && mob.getRandom().nextInt(Math.max(1, stopInterval / 20)) != 0;
        }

        @Override
        public void start() {
            mob.getNavigation().stop();
            mob.setFlag(BedrockEntity.F_LAYING, true);
        }

        @Override
        public void stop() {
            mob.setFlag(BedrockEntity.F_LAYING, false);
        }
    }

    // ------------------------------------------------------------------ nearest_(prioritized_)attackable_target
    public static final class NearestTarget extends Goal {
        private final BedrockEntity mob;
        private final JsonObject c;
        private final int interval;
        private final double defaultRange;
        private LivingEntity found;
        private int tick;

        public NearestTarget(BedrockEntity mob, JsonObject c) {
            this.mob = mob;
            this.c = c;
            this.interval = Math.max(1, (int) Jsons.num(c, "attack_interval", 10));
            this.defaultRange = Jsons.num(c, "within_radius", 0);
            setFlags(EnumSet.of(Flag.TARGET));
        }

        @Override
        public boolean canUse() {
            if (busy(mob)) return false;
            if (mob.getTarget() != null && mob.getTarget().isAlive() && !Jsons.bool(c, "reselect_targets", false)) return false;
            if (++tick < interval) return false;
            tick = 0;
            found = search();
            return found != null && found != mob.getTarget();
        }

        @Override
        public boolean canContinueToUse() {
            LivingEntity t = mob.getTarget();
            return t != null && t.isAlive() && !(t instanceof Player p && (p.isCreative() || p.isSpectator()));
        }

        @Override
        public void start() {
            mob.setTarget(found);
        }

        @Override
        public void stop() {
            if (mob.getTarget() != null && !mob.getTarget().isAlive()) mob.setTarget(null);
        }

        private LivingEntity search() {
            JsonArray types = Jsons.arr(c, "entity_types");
            if (types == null) return null;
            double follow = mob.getAttributeValue(net.minecraft.world.entity.ai.attributes.Attributes.FOLLOW_RANGE);
            List<LivingEntity> cands = new ArrayList<>();
            double boxR = Math.min(Math.max(follow, 16), 64);
            cands.addAll(mob.level().getEntitiesOfClass(LivingEntity.class, mob.getBoundingBox().inflate(boxR), e -> e != mob));
            for (Player p : mob.level().players()) if (!cands.contains(p)) cands.add(p);
            LivingEntity best = null;
            double bestD = Double.MAX_VALUE;
            for (LivingEntity e : cands) {
                if (!e.isAlive() || e == mob) continue;
                if (e instanceof Player p && (p.isCreative() || p.isSpectator())) continue;
                double d = mob.distanceTo(e);
                for (JsonElement te : types) {
                    if (!te.isJsonObject()) continue;
                    JsonObject t = te.getAsJsonObject();
                    double max = Jsons.num(t, "max_dist", defaultRange > 0 ? defaultRange : follow);
                    if (d > max) continue;
                    if (t.has("filters") && !Filters.test(t.get("filters"), McFilterContext.subjects(mob, e))) continue;
                    boolean mustSee = Jsons.bool(t, "must_see", Jsons.bool(c, "must_see", false));
                    if (mustSee && !mob.hasLineOfSight(e)) continue;
                    if (d < bestD) {
                        bestD = d;
                        best = e;
                    }
                    break;
                }
            }
            return best;
        }
    }
}
