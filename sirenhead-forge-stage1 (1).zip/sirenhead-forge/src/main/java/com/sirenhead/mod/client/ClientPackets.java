package com.sirenhead.mod.client;

import com.sirenhead.mod.entity.BedrockEntity;
import com.sirenhead.mod.network.BedrockNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Marker;
import net.minecraft.world.phys.Vec3;

import java.util.Random;

/** Client side of the packets in {@link BedrockNetwork}, plus the small state they drive (camera shake, free camera, input lock). */
public final class ClientPackets {
    private ClientPackets() {
    }

    // ------------------------------------------------------------------ animation / particles

    public static void playAnimation(BedrockNetwork.PlayAnim m) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        Entity e = mc.level.getEntity(m.entityId);
        if (!(e instanceof BedrockEntity be)) return;
        ClientEntityState st = ClientEntityState.of(be);
        if (st.animator() == null) return;
        st.animator().playForced(m.animation, m.nextState, m.blendOut, m.stopExpression, m.controller);
    }

    public static void particle(BedrockNetwork.SpawnParticle m) {
        BedrockParticles.spawn(m.effect, m.x, m.y, m.z, m.yaw);
    }

    // ------------------------------------------------------------------ camera shake

    private static final Random RNG = new Random();
    private static float shakeIntensity, shakeLeft, shakeTotal;
    private static long shakeLastNanos;

    public static void cameraShake(BedrockNetwork.CameraShake m) {
        if (m.seconds <= 0 || m.intensity <= 0) {
            shakeLeft = 0;
            return;
        }
        // overlapping shakes: the stronger one wins, otherwise the longer one
        float remainingStrength = shakeLeft > 0 ? shakeIntensity * (shakeLeft / Math.max(0.001f, shakeTotal)) : 0;
        if (m.intensity >= remainingStrength) {
            shakeIntensity = m.intensity;
            shakeLeft = m.seconds;
            shakeTotal = m.seconds;
        }
    }

    /** Returns {yawOffset, pitchOffset, rollOffset} in degrees for this frame (zeros when idle). */
    public static float[] shakeOffsets() {
        long now = System.nanoTime();
        float dt = shakeLastNanos == 0 ? 0 : Math.min(0.1f, (now - shakeLastNanos) / 1.0e9f);
        shakeLastNanos = now;
        if (shakeLeft <= 0) return new float[]{0, 0, 0};
        shakeLeft -= dt;
        float fade = Mth.clamp(shakeLeft / Math.max(0.001f, shakeTotal), 0f, 1f);
        float amp = Math.min(6f, shakeIntensity * 0.6f) * fade;
        return new float[]{(RNG.nextFloat() - 0.5f) * 2f * amp, (RNG.nextFloat() - 0.5f) * 2f * amp, (RNG.nextFloat() - 0.5f) * amp};
    }

    // ------------------------------------------------------------------ free camera (/camera ... set minecraft:free)

    private static Marker cameraEntity;
    private static boolean cameraActive;
    private static double camX, camY, camZ;
    private static int facingEntity = -1;
    private static boolean hasFacingPos;
    private static double facingX, facingY, facingZ;

    public static void cameraSet(BedrockNetwork.CameraSet m) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        if (!m.active) {
            releaseCamera();
            return;
        }
        camX = m.x;
        camY = m.y;
        camZ = m.z;
        facingEntity = m.facingEntity;
        hasFacingPos = m.hasFacingPos;
        facingX = m.fx;
        facingY = m.fy;
        facingZ = m.fz;
        if (cameraEntity == null || cameraEntity.level() != mc.level) cameraEntity = new Marker(EntityType.MARKER, mc.level);
        cameraActive = true;
        updateCamera();
        mc.setCameraEntity(cameraEntity);
    }

    private static void updateCamera() {
        Minecraft mc = Minecraft.getInstance();
        if (!cameraActive || cameraEntity == null || mc.level == null) return;
        Vec3 target = null;
        if (facingEntity >= 0) {
            Entity e = mc.level.getEntity(facingEntity);
            if (e != null) target = new Vec3(e.getX(), e.getY() + e.getBbHeight() * 0.6, e.getZ());
        } else if (hasFacingPos) {
            target = new Vec3(facingX, facingY, facingZ);
        }
        float yaw = cameraEntity.getYRot(), pitch = cameraEntity.getXRot();
        if (target != null) {
            double dx = target.x - camX, dy = target.y - camY, dz = target.z - camZ;
            yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
            pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        }
        cameraEntity.xo = cameraEntity.xOld = cameraEntity.getX();
        cameraEntity.yo = cameraEntity.yOld = cameraEntity.getY();
        cameraEntity.zo = cameraEntity.zOld = cameraEntity.getZ();
        cameraEntity.setPos(camX, camY, camZ);
        cameraEntity.yRotO = cameraEntity.getYRot();
        cameraEntity.xRotO = cameraEntity.getXRot();
        cameraEntity.setYRot(yaw);
        cameraEntity.setXRot(pitch);
    }

    private static void releaseCamera() {
        Minecraft mc = Minecraft.getInstance();
        cameraActive = false;
        facingEntity = -1;
        hasFacingPos = false;
        if (mc.player != null && mc.getCameraEntity() == cameraEntity) mc.setCameraEntity(mc.player);
    }

    // ------------------------------------------------------------------ input permission

    public static boolean movementEnabled = true;
    public static boolean cameraInputEnabled = true;
    private static float lockedYaw, lockedPitch;

    public static void inputPermission(BedrockNetwork.InputPermission m) {
        movementEnabled = m.movement;
        if (cameraInputEnabled && !m.camera && Minecraft.getInstance().player != null) {
            lockedYaw = Minecraft.getInstance().player.getYRot();
            lockedPitch = Minecraft.getInstance().player.getXRot();
        }
        cameraInputEnabled = m.camera;
    }

    // ------------------------------------------------------------------ per tick / lifecycle

    public static void clientTick() {
        updateCamera();
        LocalPlayer p = Minecraft.getInstance().player;
        if (p != null && !cameraInputEnabled) {
            p.setYRot(lockedYaw);
            p.setXRot(lockedPitch);
        }
    }

    public static void reset() {
        shakeLeft = 0;
        movementEnabled = true;
        cameraInputEnabled = true;
        cameraActive = false;
        cameraEntity = null;
        facingEntity = -1;
        hasFacingPos = false;
        BedrockParticles.clear();
    }
}
