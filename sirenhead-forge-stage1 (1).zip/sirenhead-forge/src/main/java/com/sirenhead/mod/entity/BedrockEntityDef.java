package com.sirenhead.mod.entity;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sirenhead.bedrock.BedrockPaths;
import com.sirenhead.bedrock.anim.ClientEntityDef;
import com.sirenhead.bedrock.behavior.BehaviorDef;
import com.sirenhead.bedrock.json.Jsons;
import com.sirenhead.mod.BedrockLibraries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.MobCategory;

import java.util.HashSet;
import java.util.Set;

/**
 * Static description of one Bedrock entity: its BP definition plus what Forge needs at registration time.
 * <p>
 * Hit box mapping: if the BP has {@code minecraft:custom_hit_test} its first/largest hitbox (width, height) is used as the
 * Java bounding box (that is what players attack), otherwise {@code minecraft:collision_box} multiplied by {@code minecraft:scale}.
 */
public final class BedrockEntityDef {
    private final String id;
    private final ResourceLocation javaId;
    private final BehaviorDef behavior;
    private final float hitWidth;
    private final float hitHeight;
    private final MobCategory category;
    private final boolean fireImmune;
    private final Set<String> baseFamilies = new HashSet<>();
    private int eggBase = 0x808080;
    private int eggOverlay = 0x303030;

    private BedrockEntityDef(String id, BehaviorDef b, float w, float h, MobCategory category, boolean fireImmune) {
        this.id = id;
        this.javaId = new ResourceLocation(BedrockPaths.javaId(id));
        this.behavior = b;
        this.hitWidth = w;
        this.hitHeight = h;
        this.category = category;
        this.fireImmune = fireImmune;
    }

    public static BedrockEntityDef create(BehaviorDef b) {
        JsonObject c = b.components();
        double scale = 1;
        JsonObject sc = Jsons.obj(c, "minecraft:scale");
        if (sc != null) scale = Jsons.num(sc, "value", 1);
        double w = 0.6, h = 1.8;
        JsonObject cb = Jsons.obj(c, "minecraft:collision_box");
        if (cb != null) {
            w = Jsons.num(cb, "width", 1) * scale;
            h = Jsons.num(cb, "height", 1) * scale;
        }
        JsonObject ht = Jsons.obj(c, "minecraft:custom_hit_test");
        JsonArray boxes = ht == null ? null : Jsons.arr(ht, "hitboxes");
        if (boxes != null && boxes.size() > 0) {
            double bw = 0, bh = 0;
            for (JsonElement e : boxes) {
                if (!e.isJsonObject()) continue;
                bw = Math.max(bw, Jsons.num(e.getAsJsonObject(), "width", 0));
                bh = Math.max(bh, Jsons.num(e.getAsJsonObject(), "height", 0));
            }
            if (bw > 0 && bh > 0) {
                w = bw;
                h = bh;
            }
        }
        Set<String> fam = new HashSet<>();
        collectFamilies(c.get("minecraft:type_family"), fam);
        for (JsonObject g : b.componentGroups().values()) collectFamilies(g.get("minecraft:type_family"), fam);
        MobCategory cat = fam.contains("monster") ? MobCategory.MONSTER : MobCategory.MISC;
        boolean fire = c.has("minecraft:fire_immune");
        BedrockEntityDef d = new BedrockEntityDef(b.identifier(), b, (float) Math.max(0.1, w), (float) Math.max(0.1, h), cat, fire);
        collectFamilies(c.get("minecraft:type_family"), d.baseFamilies);
        d.parseEgg();
        return d;
    }

    private static void collectFamilies(JsonElement e, Set<String> out) {
        if (e == null || !e.isJsonObject()) return;
        JsonElement f = e.getAsJsonObject().get("family");
        if (f != null && f.isJsonArray()) for (JsonElement x : f.getAsJsonArray()) out.add(x.getAsString());
    }

    private void parseEgg() {
        try {
            ClientEntityDef cd = BedrockLibraries.clientEntity(id);
            JsonObject egg = cd == null ? null : cd.spawnEgg();
            if (egg != null) {
                eggBase = parseColor(Jsons.str(egg, "base_color", null), eggBase);
                eggOverlay = parseColor(Jsons.str(egg, "overlay_color", null), eggOverlay);
            }
        } catch (RuntimeException ignored) {
        }
    }

    private static int parseColor(String s, int def) {
        if (s == null) return def;
        try {
            String t = s.startsWith("#") ? s.substring(1) : s;
            return (int) (Long.parseLong(t, 16) & 0xFFFFFF);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    /** Bedrock identifier, e.g. {@code ho:sirenhead}. */
    public String id() {
        return id;
    }

    public ResourceLocation javaId() {
        return javaId;
    }

    public String javaPath() {
        return javaId.getPath();
    }

    public BehaviorDef behavior() {
        return behavior;
    }

    public float hitWidth() {
        return hitWidth;
    }

    public float hitHeight() {
        return hitHeight;
    }

    public MobCategory category() {
        return category;
    }

    public boolean fireImmune() {
        return fireImmune;
    }

    public Set<String> families() {
        return baseFamilies;
    }

    public int eggBase() {
        return eggBase;
    }

    public int eggOverlay() {
        return eggOverlay;
    }

    /** Client entity (RP) definition or null. Only call on the client or after the RP library is available. */
    public ClientEntityDef client() {
        return BedrockLibraries.clientEntity(id);
    }
}
