package com.sirenhead.mod.molang;

import com.sirenhead.bedrock.molang.MolangEnv;
import com.sirenhead.bedrock.molang.MolangEnvBase;
import com.sirenhead.mod.entity.BedrockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.Locale;
import java.util.Random;

/**
 * Molang environment of one entity (vanilla or Bedrock-backed). Holds the persistent {@code v.*} storage of that entity
 * for the side it lives on and answers {@code query.*} from live game state.
 */
public class EntityMolangEnv extends MolangEnvBase {
    protected final Entity entity;
    /** Fractional tick for smooth values; set by the renderer before animating. */
    private float partialTick;

    public EntityMolangEnv(Entity entity) {
        this.entity = entity;
        this.rng = new Random(entity.getUUID().getLeastSignificantBits() ^ 0x5DEECE66DL);
    }

    public Entity entity() {
        return entity;
    }

    public void setPartialTick(float pt) {
        this.partialTick = pt;
    }

    private static Double b(boolean v) {
        return v ? 1.0 : 0.0;
    }

    private BedrockEntity be() {
        return entity instanceof BedrockEntity e ? e : null;
    }

    private static String str(Object[] a, int i) {
        return a != null && a.length > i && a[i] != null ? String.valueOf(a[i]) : "";
    }

    private static double num(Object[] a, int i, double def) {
        if (a == null || a.length <= i || a[i] == null) return def;
        try {
            return a[i] instanceof Number n ? n.doubleValue() : Double.parseDouble(String.valueOf(a[i]));
        } catch (NumberFormatException e) {
            return def;
        }
    }

    @Override
    public Object query(String name, Object[] args) {
        BedrockEntity be = be();
        LivingEntity living = entity instanceof LivingEntity l ? l : null;
        switch (name.toLowerCase(Locale.ROOT)) {
            case "life_time":
                return (entity.tickCount + partialTick) / 20.0;
            case "property":
                return be == null ? 0.0 : be.getProperty(str(args, 0));
            case "variant":
                return be == null ? 0.0 : (double) be.getVariant();
            case "mark_variant":
                return be == null ? 0.0 : (double) be.getMarkVariant();
            case "skin_id":
                return be == null ? 0.0 : (double) be.getSkinId();
            case "model_scale":
                return be == null ? 1.0 : be.getBedrockScale();
            case "has_target":
                return b(be != null ? be.hasBedrockTarget() : entity instanceof Mob m && m.getTarget() != null);
            case "target": {
                Entity t = be != null ? be.getBedrockTargetEntity() : entity instanceof Mob m ? m.getTarget() : null;
                return t;
            }
            case "is_stunned":
                return b(be != null && be.isStunned());
            case "is_casting":
                return b(be != null && be.isCasting());
            case "is_delayed_attacking":
                return b(be != null && be.isDelayedAttacking());
            case "is_laying_down":
                return b(be != null && be.isLayingDown());
            case "is_alive":
                return b(entity.isAlive());
            case "is_riding":
                return b(entity.isPassenger());
            case "has_rider":
                return b(entity.isVehicle());
            case "get_ride":
                return entity.getVehicle();
            case "is_sneaking":
                return b(entity.isShiftKeyDown());
            case "is_sprinting":
                return b(entity.isSprinting());
            case "is_using_item":
                return b(living != null && living.isUsingItem());
            case "is_wall_climbing":
                return b(living != null && living.onClimbable());
            case "is_levitating":
                return b(living != null && living.hasEffect(MobEffects.LEVITATION));
            case "is_gliding":
                return b(living != null && living.isFallFlying());
            case "can_fly":
                return 0.0;
            case "is_moving": {
                Vec3 v = entity.getDeltaMovement();
                return b(v.x * v.x + v.z * v.z > 1.0E-5);
            }
            case "health":
                return living == null ? 0.0 : (double) living.getHealth();
            case "max_health":
                return living == null ? 0.0 : (double) living.getMaxHealth();
            case "ground_speed": {
                Vec3 v = entity.getDeltaMovement();
                return Math.sqrt(v.x * v.x + v.z * v.z) * 20.0;
            }
            case "modified_move_speed":
                return living == null ? 0.0 : (double) Math.min(1f, living.walkAnimation.speed(partialTick));
            case "modified_distance_moved":
                return living == null ? 0.0 : (double) living.walkAnimation.position(partialTick);
            case "delta_time":
                return 0.05;
            case "frame_alpha":
                return (double) partialTick;
            case "body_y_rotation":
                return living == null ? (double) entity.getYRot() : (double) Mth.rotLerp(partialTick, living.yBodyRotO, living.yBodyRot);
            case "target_x_rotation":
                return (double) Mth.wrapDegrees(Mth.lerp(partialTick, entity.xRotO, entity.getXRot()));
            case "target_y_rotation": {
                if (living == null) return 0.0;
                float head = Mth.rotLerp(partialTick, living.yHeadRotO, living.yHeadRot);
                float body = Mth.rotLerp(partialTick, living.yBodyRotO, living.yBodyRot);
                return (double) Mth.clamp(Mth.wrapDegrees(head - body), -90f, 90f);
            }
            case "owner_identifier": {
                Entity owner = be == null ? null : be.getBedrockOwner();
                Entity ref = owner != null ? owner : entity;
                return idOf(ref);
            }
            case "get_nearby_entities": {
                double r = num(args, 0, 16);
                String filter = str(args, 1);
                int n = 0;
                for (Entity e : entity.level().getEntities(entity, entity.getBoundingBox().inflate(r), x -> x != entity)) {
                    if (e.distanceToSqr(entity) > r * r) continue;
                    if (filter.isEmpty() || idOf(e).equals(filter) || (filter.equals("minecraft:player") && e instanceof Player)) n++;
                }
                return (double) n;
            }
            case "block_state": {
                BlockPos pos = entity.blockPosition();
                BlockState st = entity.level().getBlockState(pos);
                String prop = str(args, 0);
                if (prop.equals("minecraft:cardinal_direction") && st.hasProperty(net.minecraft.world.level.block.HorizontalDirectionalBlock.FACING)) {
                    Direction d = st.getValue(net.minecraft.world.level.block.HorizontalDirectionalBlock.FACING);
                    return d.getName();
                }
                return "";
            }
            case "cooldown_time_remaining":
            case "remaining_durability":
                return 0.0;
            default:
                return null;
        }
    }

    public static String idOf(Entity e) {
        if (e instanceof BedrockEntity b) return b.def().id();
        return String.valueOf(ForgeRegistries.ENTITY_TYPES.getKey(e.getType()));
    }

    @Override
    public MolangEnv resolveEntity(Object ref) {
        if (!(ref instanceof Entity e)) return null;
        if (e instanceof BedrockEntity b) return b.molang();
        return new EntityMolangEnv(e);
    }

    @Override
    public double random() {
        return rng.nextDouble();
    }
}
