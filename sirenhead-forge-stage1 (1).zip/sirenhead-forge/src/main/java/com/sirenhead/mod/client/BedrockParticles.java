package com.sirenhead.mod.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.platform.GlStateManager;
import com.sirenhead.bedrock.anim.Pose;
import com.sirenhead.bedrock.anim.Rig;
import com.sirenhead.bedrock.molang.Molang;
import com.sirenhead.bedrock.molang.MolangEnvBase;
import com.sirenhead.bedrock.particle.BillboardMath;
import com.sirenhead.bedrock.particle.Particle;
import com.sirenhead.bedrock.particle.ParticleDef;
import com.sirenhead.bedrock.particle.ParticleEmitter;
import com.sirenhead.bedrock.particle.ParticleWorld;
import com.sirenhead.mod.BedrockLibraries;
import com.sirenhead.mod.SirenHeadMod;
import com.sirenhead.mod.entity.BedrockEntity;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Runs the add-on's Bedrock particle effects ({@link ParticleEmitter}) on the client and draws them as camera-facing quads
 * after vanilla particles. The simulation (curves, Molang, emitters, collision, flipbooks) is the unchanged Bedrock JSON.
 */
public final class BedrockParticles {
    private BedrockParticles() {
    }

    private static final int MAX_EMITTERS = 256;
    private static final double MAX_DISTANCE_SQ = 160.0 * 160.0;
    private static final int FULL_BRIGHT = 0xF000F0;

    private static final class Active {
        ParticleEmitter emitter;
        int entityId = -1;
        ClientEntityState state;
        String locator;
    }

    private static final List<Active> ACTIVE = new ArrayList<>();
    private static final Map<String, ResourceLocation> TEXTURES = new HashMap<>();

    private static final ParticleWorld WORLD = new ParticleWorld() {
        @Override
        public String blockId(int x, int y, int z) {
            BlockState s = state(x, y, z);
            return s == null ? "minecraft:air" : BuiltInRegistries.BLOCK.getKey(s.getBlock()).toString();
        }

        @Override
        public boolean isSolid(int x, int y, int z) {
            BlockState s = state(x, y, z);
            ClientLevel l = Minecraft.getInstance().level;
            return s != null && l != null && !s.getCollisionShape(l, new BlockPos(x, y, z)).isEmpty();
        }

        private BlockState state(int x, int y, int z) {
            ClientLevel l = Minecraft.getInstance().level;
            if (l == null) return null;
            BlockPos p = new BlockPos(x, y, z);
            return l.isLoaded(p) ? l.getBlockState(p) : null;
        }
    };

    // =================================================================== spawning

    public static void clear() {
        ACTIVE.clear();
    }

    private static Map<String, Double> preEffectVariables(String script) {
        Map<String, Double> out = new HashMap<>();
        if (script == null || script.isBlank()) return out;
        try {
            MolangEnvBase env = new MolangEnvBase() {
                @Override
                public Object query(String name, Object[] args) {
                    return 0.0;
                }
            };
            Molang.compileLenient(script).eval(env);
            for (Map.Entry<String, Object> e : env.variables().entrySet()) out.put(e.getKey(), Molang.toNum(e.getValue()));
        } catch (RuntimeException ex) {
            SirenHeadMod.LOGGER.debug("pre_effect_script failed: {}", ex.toString());
        }
        return out;
    }

    private static ParticleEmitter create(String id, String pre) {
        ParticleDef def = BedrockLibraries.particles().get(id);
        if (def == null || ACTIVE.size() >= MAX_EMITTERS) return null;
        return new ParticleEmitter(def, preEffectVariables(pre), System.nanoTime(), WORLD);
    }

    /** World-fixed effect ({@code /particle}). */
    public static void spawn(String id, double x, double y, double z, float yaw) {
        ParticleEmitter em = create(id, null);
        if (em == null) return;
        em.setTransform(x, y, z, yaw);
        Active a = new Active();
        a.emitter = em;
        ACTIVE.add(a);
    }

    /** Effect that follows an entity (animation keyframe / controller state particle with an optional locator). */
    public static void spawnAttached(BedrockEntity entity, ClientEntityState state, String id, String locator, String pre) {
        ParticleEmitter em = create(id, pre);
        if (em == null) return;
        Active a = new Active();
        a.emitter = em;
        a.entityId = entity.getId();
        a.state = state;
        a.locator = locator;
        place(a, entity);
        ACTIVE.add(a);
    }

    /** Bedrock local space (x = entity left, y = up, z = backwards, pixels) -> world position via the entity transform. */
    private static void place(Active a, BedrockEntity e) {
        double left = 0, up = 0, fwd = 0;
        if (a.locator != null && a.state != null && a.state.choice() != null && a.state.choice().geometryId() != null) {
            Rig rig = BedrockLibraries.rig(a.state.choice().geometryId());
            Pose pose = a.state.animator() == null ? null : a.state.animator().pose();
            double[] p = rig.locator(a.locator, pose);
            if (p != null) {
                double s = e.getBedrockScale() / 16.0;
                left = p[0] * s;
                up = p[1] * s;
                fwd = -p[2] * s;
            }
        }
        double yaw = e.yBodyRot;
        double r = Math.toRadians(yaw);
        double fx = -Math.sin(r), fz = Math.cos(r), lx = Math.cos(r), lz = Math.sin(r);
        a.emitter.setTransform(e.getX() + left * lx + fwd * fx, e.getY() + up, e.getZ() + left * lz + fwd * fz, yaw);
    }

    // =================================================================== tick

    public static void tick() {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) {
            ACTIVE.clear();
            return;
        }
        for (int i = ACTIVE.size() - 1; i >= 0; i--) {
            Active a = ACTIVE.get(i);
            if (a.entityId >= 0) {
                Entity e = level.getEntity(a.entityId);
                if (e instanceof BedrockEntity be && be.isAlive()) place(a, be);
                else a.emitter.stop();
            }
            try {
                a.emitter.tick(0.05);
            } catch (RuntimeException ex) {
                a.emitter.kill();
                SirenHeadMod.LOGGER.debug("particle emitter failed: {}", ex.toString());
            }
            if (a.emitter.isDone()) ACTIVE.remove(i);
        }
    }

    // =================================================================== rendering

    private record Key(ResourceLocation texture, boolean additive) {
    }

    private static ResourceLocation textureOf(String bedrockPath) {
        return TEXTURES.computeIfAbsent(bedrockPath, p -> {
            String path = p;
            String ns = SirenHeadMod.MOD_ID;
            if (path.startsWith("textures/blocks/")) { // vanilla block texture
                ns = "minecraft";
                path = "textures/block/" + path.substring("textures/blocks/".length());
            }
            return new ResourceLocation(ns, path + ".png");
        });
    }

    private static final ResourceLocation[] GENERIC = new ResourceLocation[8];

    static {
        for (int i = 0; i < 8; i++) GENERIC[i] = new ResourceLocation("minecraft", "textures/particle/generic_" + i + ".png");
    }

    public static void render(PoseStack poseStack, Camera camera, float partialTick) {
        if (ACTIVE.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        Vec3 cp = camera.getPosition();
        Vector3f look = camera.getLookVector(), up = camera.getUpVector(), left = camera.getLeftVector();
        double[] camRight = {-left.x(), -left.y(), -left.z()};
        double[] camUp = {up.x(), up.y(), up.z()};
        double[] camFwd = {look.x(), look.y(), look.z()};
        double[] camOrigin = {0, 0, 0}; // positions below are camera relative
        double[] ax = new double[3], ay = new double[3], dir = new double[3];

        Map<Key, List<float[]>> buckets = new LinkedHashMap<>();
        for (Active a : ACTIVE) {
            ParticleEmitter em = a.emitter;
            double dx = em.x() - cp.x, dy = em.y() - cp.y, dz = em.z() - cp.z;
            if (dx * dx + dy * dy + dz * dz > MAX_DISTANCE_SQ) continue;
            ParticleDef def = em.def();
            boolean additive = def.additive();
            boolean legacyAtlas = def.texture().equals("textures/particle/particles");
            ResourceLocation baseTex = legacyAtlas ? null : textureOf(def.texture());
            for (Particle p : em.particles()) {
                if (p.dead) continue;
                double wx = p.pwx + (p.wx - p.pwx) * partialTick, wy = p.pwy + (p.wy - p.pwy) * partialTick, wz = p.pwz + (p.wz - p.pwz) * partialTick;
                double px = wx - cp.x, py = wy - cp.y, pz = wz - cp.z;
                dir[0] = p.dirX;
                dir[1] = p.dirY;
                dir[2] = p.dirZ;
                BillboardMath.axes(def.facing(), camOrigin, camRight, camUp, camFwd, px, py, pz, dir, em.cosYaw(), em.sinYaw(), p.rotDeg, ax, ay);
                double hw = BillboardMath.halfExtent(p.sizeX), hh = BillboardMath.halfExtent(p.sizeY);
                float u0 = p.u0, v0 = p.v0, u1 = p.u1, v1 = p.v1;
                ResourceLocation tex = baseTex;
                if (legacyAtlas) {
                    // Bedrock's legacy 128x128 particle sheet: row 0 holds the 8 "generic" frames, 8x8 each, last frame at x=0
                    int cell = Math.max(0, Math.min(7, (int) Math.round(u0 * 128.0 / 8.0)));
                    tex = GENERIC[7 - cell];
                    u0 = 0;
                    v0 = 0;
                    u1 = 1;
                    v1 = 1;
                }
                int light = FULL_BRIGHT;
                if (def.lighting()) light = LevelRenderer.getLightColor(level, BlockPos.containing(wx, wy, wz));
                float[] q = new float[40];
                double[][] corner = {{-1, -1, u0, v1}, {1, -1, u1, v1}, {1, 1, u1, v0}, {-1, 1, u0, v0}};
                for (int i = 0; i < 4; i++) {
                    double sx = corner[i][0] * hw, sy = corner[i][1] * hh;
                    int o = i * 10;
                    q[o] = (float) (px + ax[0] * sx + ay[0] * sy);
                    q[o + 1] = (float) (py + ax[1] * sx + ay[1] * sy);
                    q[o + 2] = (float) (pz + ax[2] * sx + ay[2] * sy);
                    q[o + 3] = (float) corner[i][2];
                    q[o + 4] = (float) corner[i][3];
                    q[o + 5] = p.r;
                    q[o + 6] = p.g;
                    q[o + 7] = p.b;
                    q[o + 8] = p.a;
                    q[o + 9] = Float.intBitsToFloat(light);
                }
                buckets.computeIfAbsent(new Key(tex, additive), k -> new ArrayList<>()).add(q);
            }
        }
        if (buckets.isEmpty()) return;

        mc.gameRenderer.lightTexture().turnOnLightLayer();
        PoseStack mv = RenderSystem.getModelViewStack();
        mv.pushPose();
        mv.mulPoseMatrix(poseStack.last().pose());
        RenderSystem.applyModelViewMatrix();
        RenderSystem.enableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);

        Tesselator tess = Tesselator.getInstance();
        for (Map.Entry<Key, List<float[]>> en : buckets.entrySet()) {
            Key k = en.getKey();
            RenderSystem.setShader(GameRenderer::getParticleShader);
            RenderSystem.setShaderTexture(0, k.texture());
            if (k.additive()) RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
            else RenderSystem.defaultBlendFunc();
            BufferBuilder bb = tess.getBuilder();
            bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.PARTICLE);
            for (float[] q : en.getValue()) {
                for (int i = 0; i < 4; i++) {
                    int o = i * 10;
                    bb.vertex(q[o], q[o + 1], q[o + 2]).uv(q[o + 3], q[o + 4]).color(q[o + 5], q[o + 6], q[o + 7], q[o + 8]).uv2(Float.floatToRawIntBits(q[o + 9])).endVertex();
                }
            }
            tess.end();
        }

        RenderSystem.defaultBlendFunc();
        RenderSystem.enableCull();
        RenderSystem.depthMask(true);
        RenderSystem.disableBlend();
        mv.popPose();
        RenderSystem.applyModelViewMatrix();
        mc.gameRenderer.lightTexture().turnOffLightLayer();
    }
}
