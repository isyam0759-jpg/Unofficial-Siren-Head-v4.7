package com.sirenhead.mod.network;

import com.sirenhead.mod.SirenHeadMod;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

/** Server -> client packets used by the Bedrock command engine (animations, particles, camera). */
public final class BedrockNetwork {
    private BedrockNetwork() {
    }

    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(SirenHeadMod.MOD_ID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, PlayAnim.class, PlayAnim::encode, PlayAnim::decode, PlayAnim::handle);
        CHANNEL.registerMessage(id++, SpawnParticle.class, SpawnParticle::encode, SpawnParticle::decode, SpawnParticle::handle);
        CHANNEL.registerMessage(id++, CameraShake.class, CameraShake::encode, CameraShake::decode, CameraShake::handle);
        CHANNEL.registerMessage(id++, CameraSet.class, CameraSet::encode, CameraSet::decode, CameraSet::handle);
        CHANNEL.registerMessage(id++, InputPermission.class, InputPermission::encode, InputPermission::decode, InputPermission::handle);
    }

    // ------------------------------------------------------------------ senders

    public static void toPlayer(ServerPlayer p, Object msg) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), msg);
    }

    public static void toTracking(Entity e, Object msg) {
        CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> e), msg);
    }

    public static void toNear(ServerLevel level, double x, double y, double z, double radius, Object msg) {
        double r2 = radius * radius;
        for (ServerPlayer p : level.players()) {
            if (p.distanceToSqr(x, y, z) <= r2) toPlayer(p, msg);
        }
    }

    private static void client(Supplier<NetworkEvent.Context> ctx, Supplier<Runnable> work) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, work));
        c.setPacketHandled(true);
    }

    private static void writeStr(FriendlyByteBuf b, String s) {
        b.writeBoolean(s != null);
        if (s != null) b.writeUtf(s, 512);
    }

    private static String readStr(FriendlyByteBuf b) {
        return b.readBoolean() ? b.readUtf(512) : null;
    }

    // ------------------------------------------------------------------ packets

    /** {@code /playanimation}: force an RP animation on an entity's client-side animator. */
    public static final class PlayAnim {
        public final int entityId;
        public final String animation, nextState, stopExpression, controller;
        public final float blendOut;

        public PlayAnim(int entityId, String animation, String nextState, float blendOut, String stopExpression, String controller) {
            this.entityId = entityId;
            this.animation = animation;
            this.nextState = nextState;
            this.blendOut = blendOut;
            this.stopExpression = stopExpression;
            this.controller = controller;
        }

        public static void encode(PlayAnim m, FriendlyByteBuf b) {
            b.writeVarInt(m.entityId);
            writeStr(b, m.animation);
            writeStr(b, m.nextState);
            b.writeFloat(m.blendOut);
            writeStr(b, m.stopExpression);
            writeStr(b, m.controller);
        }

        public static PlayAnim decode(FriendlyByteBuf b) {
            return new PlayAnim(b.readVarInt(), readStr(b), readStr(b), b.readFloat(), readStr(b), readStr(b));
        }

        public static void handle(PlayAnim m, Supplier<NetworkEvent.Context> ctx) {
            client(ctx, () -> () -> com.sirenhead.mod.client.ClientPackets.playAnimation(m));
        }
    }

    /** {@code /particle}: spawn an add-on particle emitter at a world position. */
    public static final class SpawnParticle {
        public final String effect;
        public final double x, y, z;
        public final float yaw;

        public SpawnParticle(String effect, double x, double y, double z, float yaw) {
            this.effect = effect;
            this.x = x;
            this.y = y;
            this.z = z;
            this.yaw = yaw;
        }

        public static void encode(SpawnParticle m, FriendlyByteBuf b) {
            b.writeUtf(m.effect, 256);
            b.writeDouble(m.x);
            b.writeDouble(m.y);
            b.writeDouble(m.z);
            b.writeFloat(m.yaw);
        }

        public static SpawnParticle decode(FriendlyByteBuf b) {
            return new SpawnParticle(b.readUtf(256), b.readDouble(), b.readDouble(), b.readDouble(), b.readFloat());
        }

        public static void handle(SpawnParticle m, Supplier<NetworkEvent.Context> ctx) {
            client(ctx, () -> () -> com.sirenhead.mod.client.ClientPackets.particle(m));
        }
    }

    /** {@code /camerashake add}: intensity (Bedrock 0..4) and seconds; {@code seconds <= 0} stops the shake. */
    public static final class CameraShake {
        public final float intensity, seconds;
        public final boolean positional;

        public CameraShake(float intensity, float seconds, boolean positional) {
            this.intensity = intensity;
            this.seconds = seconds;
            this.positional = positional;
        }

        public static void encode(CameraShake m, FriendlyByteBuf b) {
            b.writeFloat(m.intensity);
            b.writeFloat(m.seconds);
            b.writeBoolean(m.positional);
        }

        public static CameraShake decode(FriendlyByteBuf b) {
            return new CameraShake(b.readFloat(), b.readFloat(), b.readBoolean());
        }

        public static void handle(CameraShake m, Supplier<NetworkEvent.Context> ctx) {
            client(ctx, () -> () -> com.sirenhead.mod.client.ClientPackets.cameraShake(m));
        }
    }

    /** {@code /camera ... set minecraft:free} / {@code clear}. */
    public static final class CameraSet {
        public final boolean active;
        public final double x, y, z;
        /** entity to look at, or -1 */
        public final int facingEntity;
        public final boolean hasFacingPos;
        public final double fx, fy, fz;

        public CameraSet(boolean active, double x, double y, double z, int facingEntity, boolean hasFacingPos, double fx, double fy, double fz) {
            this.active = active;
            this.x = x;
            this.y = y;
            this.z = z;
            this.facingEntity = facingEntity;
            this.hasFacingPos = hasFacingPos;
            this.fx = fx;
            this.fy = fy;
            this.fz = fz;
        }

        public static void encode(CameraSet m, FriendlyByteBuf b) {
            b.writeBoolean(m.active);
            b.writeDouble(m.x);
            b.writeDouble(m.y);
            b.writeDouble(m.z);
            b.writeVarInt(m.facingEntity + 1);
            b.writeBoolean(m.hasFacingPos);
            b.writeDouble(m.fx);
            b.writeDouble(m.fy);
            b.writeDouble(m.fz);
        }

        public static CameraSet decode(FriendlyByteBuf b) {
            return new CameraSet(b.readBoolean(), b.readDouble(), b.readDouble(), b.readDouble(), b.readVarInt() - 1, b.readBoolean(), b.readDouble(), b.readDouble(), b.readDouble());
        }

        public static void handle(CameraSet m, Supplier<NetworkEvent.Context> ctx) {
            client(ctx, () -> () -> com.sirenhead.mod.client.ClientPackets.cameraSet(m));
        }
    }

    /** {@code /inputpermission set}: which inputs the local player may use. */
    public static final class InputPermission {
        public final boolean movement, camera;

        public InputPermission(boolean movement, boolean camera) {
            this.movement = movement;
            this.camera = camera;
        }

        public static void encode(InputPermission m, FriendlyByteBuf b) {
            b.writeBoolean(m.movement);
            b.writeBoolean(m.camera);
        }

        public static InputPermission decode(FriendlyByteBuf b) {
            return new InputPermission(b.readBoolean(), b.readBoolean());
        }

        public static void handle(InputPermission m, Supplier<NetworkEvent.Context> ctx) {
            client(ctx, () -> () -> com.sirenhead.mod.client.ClientPackets.inputPermission(m));
        }
    }
}
