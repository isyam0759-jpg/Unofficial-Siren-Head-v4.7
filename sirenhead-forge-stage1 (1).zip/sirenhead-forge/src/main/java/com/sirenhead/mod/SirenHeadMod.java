package com.sirenhead.mod;

import com.mojang.logging.LogUtils;
import com.sirenhead.mod.client.ClientSetup;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;
import software.bernie.geckolib.GeckoLib;

/**
 * Siren Head - Forge 1.20.1 + GeckoLib port of the Bedrock add-on by BendytheDemon17.
 * The Bedrock JSON (animation controllers, animations, particles, entity behaviour) is shipped unchanged
 * and executed by {@code com.sirenhead.bedrock.*}; this class only wires it into Forge.
 */
@Mod(SirenHeadMod.MOD_ID)
public class SirenHeadMod {
    public static final String MOD_ID = "sirenhead";
    public static final Logger LOGGER = LogUtils.getLogger();

    public SirenHeadMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        GeckoLib.initialize();

        BedrockEntities.register(modBus);
        modBus.addListener(BedrockEntities::onAttributes);
        com.sirenhead.mod.item.SirenItems.register(modBus);
        com.sirenhead.mod.block.SirenBlocks.register(modBus);
        com.sirenhead.mod.SirenTabs.register(modBus);
        modBus.addListener(this::commonSetup);

        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientSetup.init(modBus));
    }

    private void commonSetup(net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent event) {
        event.enqueueWork(com.sirenhead.mod.network.BedrockNetwork::register);
    }
}
