package com.sirenhead.bedrock.particle;

import com.sirenhead.bedrock.particle.ParticleDef.Facing;

/**
 * Orientation of a particle quad for every Bedrock {@code facing_camera_mode}. Pure math so it can be tested without Minecraft.
 * <p>
 * The quad corners are {@code P + ax * (sx * hw) + ay * (sy * hh)} for (sx,sy) in {(-1,-1),(1,-1),(1,1),(-1,1)}
 * with uv (u0,v1) (u1,v1) (u1,v0) (u0,v0); {@code hw/hh} are {@code size} (or half of it, see {@link #SIZE_IS_HALF_EXTENT}).
 */
public final class BillboardMath {
    private BillboardMath() {
    }

    /**
     * Bedrock's {@code size} is treated as the half extent of the quad, like Java Edition's quadSize: a particle of
     * size 0.5 is one block wide. Set to false to treat it as the full width.
     */
    public static final boolean SIZE_IS_HALF_EXTENT = true;

    public static double halfExtent(double size) {
        return SIZE_IS_HALF_EXTENT ? size : size * 0.5;
    }

    /**
     * @param cam  camera position (same coordinate space as {@code p}); {@code camRight/camUp/camFwd}: camera basis, unit vectors
     * @param p    particle position; {@code d}: unit travel direction; {@code cosY/sinY}: emitter yaw
     * @param roll roll in degrees about the quad normal
     * @param ax   out: unit vector of the quad's X axis; {@code ay}: unit vector of its Y axis
     */
    public static void axes(Facing mode, double[] cam, double[] camRight, double[] camUp, double[] camFwd,
                            double px, double py, double pz, double[] d, double cosY, double sinY, double roll,
                            double[] ax, double[] ay) {
        double[] vd = {px - cam[0], py - cam[1], pz - cam[2]};
        double vl = len(vd);
        double[] n; // quad normal pointing towards the camera
        if (vl < 1e-9) n = new double[]{-camFwd[0], -camFwd[1], -camFwd[2]};
        else n = new double[]{-vd[0] / vl, -vd[1] / vl, -vd[2] / vl};

        switch (mode) {
            case ROTATE_XYZ:
                set(ax, camRight);
                set(ay, camUp);
                n = new double[]{-camFwd[0], -camFwd[1], -camFwd[2]};
                break;
            case ROTATE_Y: {
                double[] r = {camRight[0], 0, camRight[2]};
                if (len(r) < 1e-6) r = new double[]{1, 0, 0};
                norm(r);
                set(ax, r);
                set(ay, new double[]{0, 1, 0});
                n = cross(ax, ay);
                break;
            }
            case LOOKAT_Y: {
                double[] h = {n[0], 0, n[2]};
                if (len(h) < 1e-6) h = new double[]{-camFwd[0], 0, -camFwd[2]};
                if (len(h) < 1e-6) h = new double[]{0, 0, 1};
                norm(h);
                double[] r = cross(new double[]{0, 1, 0}, h);
                norm(r);
                set(ax, r);
                set(ay, new double[]{0, 1, 0});
                n = h;
                break;
            }
            case LOOKAT_XYZ: {
                double[] r = cross(camUp, n);
                if (len(r) < 1e-6) r = camRight.clone();
                norm(r);
                set(ax, r);
                set(ay, cross(n, ax));
                break;
            }
            case DIRECTION_Y: {
                set(ay, d);
                double[] perp = perpendicular(n, d, camUp);
                set(ax, cross(ay, perp));
                n = perp;
                break;
            }
            case DIRECTION_X: {
                set(ax, d);
                double[] perp = perpendicular(n, d, camUp);
                set(ay, cross(perp, ax));
                n = perp;
                break;
            }
            case DIRECTION_Z: {
                double[] up = Math.abs(d[1]) > 0.99 ? new double[]{1, 0, 0} : new double[]{0, 1, 0};
                double[] r = cross(up, d);
                norm(r);
                set(ax, r);
                set(ay, cross(d, ax));
                n = d.clone();
                break;
            }
            case LOOKAT_DIRECTION: {
                double dn = dot(d, n);
                double[] pr = {d[0] - n[0] * dn, d[1] - n[1] * dn, d[2] - n[2] * dn};
                if (len(pr) < 1e-6) pr = camUp.clone();
                norm(pr);
                set(ay, pr);
                set(ax, cross(ay, n));
                break;
            }
            case EMITTER_TRANSFORM_XZ: {
                // flat on the emitter's local XZ plane: Y axis of the sprite = emitter forward, X = emitter right
                set(ax, new double[]{-cosY, 0, -sinY});
                set(ay, new double[]{-sinY, 0, cosY});
                n = new double[]{0, 1, 0};
                break;
            }
            case EMITTER_TRANSFORM_XY: {
                // upright in the emitter's local XY plane
                set(ax, new double[]{cosY, 0, sinY});
                set(ay, new double[]{0, 1, 0});
                n = cross(ax, ay);
                break;
            }
            case EMITTER_TRANSFORM_YZ: {
                set(ax, new double[]{-sinY, 0, cosY});
                set(ay, new double[]{0, 1, 0});
                n = cross(ax, ay);
                break;
            }
            default:
                set(ax, camRight);
                set(ay, camUp);
                break;
        }
        if (roll != 0) {
            double r = Math.toRadians(roll), c = Math.cos(r), s = Math.sin(r);
            double[] x2 = {ax[0] * c + ay[0] * s, ax[1] * c + ay[1] * s, ax[2] * c + ay[2] * s};
            double[] y2 = {ay[0] * c - ax[0] * s, ay[1] * c - ax[1] * s, ay[2] * c - ax[2] * s};
            set(ax, x2);
            set(ay, y2);
        }
    }

    /** Component of {@code toCam} perpendicular to {@code d}, normalised (falls back to a vector perpendicular to d). */
    private static double[] perpendicular(double[] toCam, double[] d, double[] fallback) {
        double k = dot(toCam, d);
        double[] p = {toCam[0] - d[0] * k, toCam[1] - d[1] * k, toCam[2] - d[2] * k};
        if (len(p) < 1e-6) {
            double kf = dot(fallback, d);
            p = new double[]{fallback[0] - d[0] * kf, fallback[1] - d[1] * kf, fallback[2] - d[2] * kf};
            if (len(p) < 1e-6) p = cross(d, new double[]{1, 0, 0});
            if (len(p) < 1e-6) p = cross(d, new double[]{0, 0, 1});
        }
        norm(p);
        return p;
    }

    static double len(double[] v) {
        return Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
    }

    static void norm(double[] v) {
        double l = len(v);
        if (l > 1e-12) {
            v[0] /= l;
            v[1] /= l;
            v[2] /= l;
        }
    }

    static double dot(double[] a, double[] b) {
        return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
    }

    static double[] cross(double[] a, double[] b) {
        return new double[]{a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]};
    }

    private static void set(double[] dst, double[] src) {
        dst[0] = src[0];
        dst[1] = src[1];
        dst[2] = src[2];
    }
}
