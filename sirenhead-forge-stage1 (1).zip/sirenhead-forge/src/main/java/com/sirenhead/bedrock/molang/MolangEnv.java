package com.sirenhead.bedrock.molang;

/**
 * Evaluation environment for Molang expressions.
 * <p>
 * Pure Java (no Minecraft dependency) so the whole Bedrock runtime can be unit tested outside the game.
 * Values are {@link Double}, {@link String}, or an opaque entity reference object. {@code null} means "unset".
 */
public interface MolangEnv {

    /** {@code query.<name>(args...)}; {@code name} is lower-case, without the {@code query.}/{@code q.} prefix. */
    Object query(String name, Object[] args);

    /** {@code variable.<path>}; path is lower-case (e.g. {@code tick_delay} or {@code a.b}). {@code null} if unset. */
    Object getVar(String path);

    void setVar(String path, Object value);

    Object getTemp(String path);

    void setTemp(String path, Object value);

    Object getContext(String path);

    /** Value of the {@code this} keyword (current channel value in animation expressions). */
    double thisValue();

    /** Resolve the left side of the {@code ->} operator to the environment of that entity (or null). */
    MolangEnv resolveEntity(Object entityRef);

    /** {@code texture.x}, {@code geometry.x}, {@code material.x}, {@code array.x} lookups. */
    Object resource(String kind, String name);

    /** Uniform random in [0,1). */
    double random();
}
