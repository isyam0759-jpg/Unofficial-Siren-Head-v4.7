package com.sirenhead.bedrock.anim;

/** One element of {@code scripts.animate}: an animation/controller short name with an optional Molang weight/condition. */
public record AnimateEntry(String shortName, String condition) {
}
