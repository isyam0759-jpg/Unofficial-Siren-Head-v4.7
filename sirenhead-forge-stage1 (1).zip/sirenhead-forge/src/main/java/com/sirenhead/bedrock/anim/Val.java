package com.sirenhead.bedrock.anim;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.sirenhead.bedrock.molang.Molang;
import com.sirenhead.bedrock.molang.MolangEnv;

/** A number-or-Molang value (constants are folded so hot paths avoid the interpreter). */
final class Val {
    final double c;
    final Molang.Expr e; // null when constant

    private Val(double c, Molang.Expr e) {
        this.c = c;
        this.e = e;
    }

    static Val of(double d) {
        return new Val(d, null);
    }

    static Val parse(JsonElement el, double def) {
        if (el == null || !el.isJsonPrimitive()) return of(def);
        JsonPrimitive p = el.getAsJsonPrimitive();
        if (p.isNumber()) return of(p.getAsDouble());
        if (p.isBoolean()) return of(p.getAsBoolean() ? 1 : 0);
        return parse(p.getAsString(), def);
    }

    static Val parse(String s, double def) {
        if (s == null) return of(def);
        String t = s.trim();
        if (t.isEmpty()) return of(def);
        try {
            return of(Double.parseDouble(t));
        } catch (NumberFormatException ignored) {
        }
        Molang.Expr ex = Molang.compileLenient(t);
        return ex.isConstant() ? of(ex.evalD(null)) : new Val(def, ex);
    }

    double get(MolangEnv env) {
        return e == null ? c : e.evalD(env);
    }

    boolean isConst() {
        return e == null;
    }
}
