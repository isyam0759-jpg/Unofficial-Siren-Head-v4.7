package com.sirenhead.bedrock.res;

import java.util.List;

/**
 * Logical resource access for the pure-Java Bedrock runtime.
 * Paths are '/'-separated, relative, without leading slash (e.g. {@code assets/sirenhead/bedrock/rp/animations/x.json}).
 */
public interface ResourceSource {

    /** UTF-8 text of the resource, or {@code null} if it does not exist. */
    String readText(String path);

    /** All resource paths under {@code dir} (recursive) whose name ends with {@code suffix}; sorted ascending. */
    List<String> list(String dir, String suffix);

    default boolean exists(String path) {
        return readText(path) != null;
    }
}
