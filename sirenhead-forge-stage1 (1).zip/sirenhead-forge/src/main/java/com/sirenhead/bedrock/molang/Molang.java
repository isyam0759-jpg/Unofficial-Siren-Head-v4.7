package com.sirenhead.bedrock.molang;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Compiler + evaluator for the subset of Molang used by Bedrock add-ons
 * (arithmetic, comparisons, ternary, {@code ??}, {@code ->}, assignments, {@code return}, strings, arrays, math.*).
 * <p>
 * Usage: {@code Molang.compile("math.sin(query.anim_time*90)").evalD(env)}.
 */
public final class Molang {
    private Molang() {
    }

    private static final ConcurrentHashMap<String, Expr> CACHE = new ConcurrentHashMap<>();

    /** Thrown for syntax errors. */
    public static final class MolangException extends RuntimeException {
        public MolangException(String msg) {
            super(msg);
        }
    }

    /** Compiled expression. */
    public abstract static class Expr {
        public abstract Object eval(MolangEnv env);

        public double evalD(MolangEnv env) {
            return toNum(eval(env));
        }

        public boolean evalB(MolangEnv env) {
            return evalD(env) != 0.0;
        }

        public boolean isConstant() {
            return false;
        }
    }

    // ------------------------------------------------------------------ public helpers

    /** Compile (cached). Blank / null input compiles to constant 0. */
    public static Expr compile(String src) {
        if (src == null) return ZERO;
        String key = src;
        Expr e = CACHE.get(key);
        if (e != null) return e;
        e = new Parser(src).parseProgram();
        CACHE.put(key, e);
        return e;
    }

    /** Compile, returning constant 0 on syntax errors instead of throwing. */
    public static Expr compileLenient(String src) {
        try {
            return compile(src);
        } catch (RuntimeException ex) {
            return ZERO;
        }
    }

    public static double eval(String src, MolangEnv env) {
        return compile(src).evalD(env);
    }

    public static double toNum(Object o) {
        if (o instanceof Double d) return d;
        if (o instanceof Number n) return n.doubleValue();
        if (o instanceof Boolean b) return b ? 1.0 : 0.0;
        return 0.0;
    }

    public static Double box(double d) {
        return d;
    }

    static boolean valuesEqual(Object a, Object b) {
        if (a instanceof String sa) return b instanceof String sb && sa.equalsIgnoreCase(sb);
        if (b instanceof String) return false;
        if (a == null && b == null) return true;
        if (a != null && b != null && !(a instanceof Number) && !(a instanceof Boolean)) {
            // entity references etc.
            return a == b || a.equals(b);
        }
        return toNum(a) == toNum(b);
    }

    private static final Expr ZERO = new Const(0.0);

    // ------------------------------------------------------------------ AST

    private static final class Const extends Expr {
        final Object value;
        final double num;

        Const(double d) {
            this.value = d;
            this.num = d;
        }

        Const(String s) {
            this.value = s;
            this.num = 0;
        }

        @Override
        public Object eval(MolangEnv env) {
            return value;
        }

        @Override
        public double evalD(MolangEnv env) {
            return num;
        }

        @Override
        public boolean isConstant() {
            return true;
        }
    }

    private static final class This extends Expr {
        @Override
        public Object eval(MolangEnv env) {
            return env.thisValue();
        }

        @Override
        public double evalD(MolangEnv env) {
            return env.thisValue();
        }
    }

    private static final class Query extends Expr {
        final String name;
        final Expr[] args;

        Query(String name, Expr[] args) {
            this.name = name;
            this.args = args;
        }

        @Override
        public Object eval(MolangEnv env) {
            Object[] a = new Object[args.length];
            for (int i = 0; i < a.length; i++) a[i] = args[i].eval(env);
            return env.query(name, a);
        }
    }

    private static final class Var extends Expr {
        final char kind; // 'v','t','c'
        final String path;

        Var(char kind, String path) {
            this.kind = kind;
            this.path = path;
        }

        Object raw(MolangEnv env) {
            return switch (kind) {
                case 'v' -> env.getVar(path);
                case 't' -> env.getTemp(path);
                default -> env.getContext(path);
            };
        }

        @Override
        public Object eval(MolangEnv env) {
            Object o = raw(env);
            return o == null ? (Object) 0.0 : o;
        }

        void assign(MolangEnv env, Object value) {
            switch (kind) {
                case 'v' -> env.setVar(path, value);
                case 't' -> env.setTemp(path, value);
                default -> {
                }
            }
        }
    }

    private static final class Resource extends Expr {
        final String kind;
        final String name;

        Resource(String kind, String name) {
            this.kind = kind;
            this.name = name;
        }

        @Override
        public Object eval(MolangEnv env) {
            Object o = env.resource(kind, name);
            return o == null ? (Object) 0.0 : o;
        }
    }

    private static final class ArrayIndex extends Expr {
        final String name;
        final Expr index;

        ArrayIndex(String name, Expr index) {
            this.name = name;
            this.index = index;
        }

        @Override
        public Object eval(MolangEnv env) {
            Object arr = env.resource("array", name);
            if (arr == null) return 0.0;
            int i = (int) Math.floor(index.evalD(env));
            if (arr instanceof List<?> l) {
                if (l.isEmpty()) return 0.0;
                i = Math.max(0, Math.min(l.size() - 1, i));
                return l.get(i);
            }
            if (arr instanceof Object[] oa) {
                if (oa.length == 0) return 0.0;
                i = Math.max(0, Math.min(oa.length - 1, i));
                return oa[i];
            }
            return 0.0;
        }
    }

    private static final class Neg extends Expr {
        final Expr e;

        Neg(Expr e) {
            this.e = e;
        }

        @Override
        public Object eval(MolangEnv env) {
            return -e.evalD(env);
        }

        @Override
        public double evalD(MolangEnv env) {
            return -e.evalD(env);
        }
    }

    private static final class Not extends Expr {
        final Expr e;

        Not(Expr e) {
            this.e = e;
        }

        @Override
        public Object eval(MolangEnv env) {
            return e.evalD(env) == 0.0 ? 1.0 : 0.0;
        }

        @Override
        public double evalD(MolangEnv env) {
            return e.evalD(env) == 0.0 ? 1.0 : 0.0;
        }
    }

    private static final class Bin extends Expr {
        final String op;
        final Expr l, r;
        final int code;

        Bin(String op, Expr l, Expr r) {
            this.op = op;
            this.l = l;
            this.r = r;
            this.code = switch (op) {
                case "+" -> 0;
                case "-" -> 1;
                case "*" -> 2;
                case "/" -> 3;
                case "<" -> 4;
                case "<=" -> 5;
                case ">" -> 6;
                case ">=" -> 7;
                case "&&" -> 8;
                case "||" -> 9;
                case "==" -> 10;
                case "!=" -> 11;
                default -> throw new MolangException("bad op " + op);
            };
        }

        @Override
        public Object eval(MolangEnv env) {
            if (code == 10) return valuesEqual(l.eval(env), r.eval(env)) ? 1.0 : 0.0;
            if (code == 11) return valuesEqual(l.eval(env), r.eval(env)) ? 0.0 : 1.0;
            return evalD(env);
        }

        @Override
        public double evalD(MolangEnv env) {
            switch (code) {
                case 0:
                    return l.evalD(env) + r.evalD(env);
                case 1:
                    return l.evalD(env) - r.evalD(env);
                case 2:
                    return l.evalD(env) * r.evalD(env);
                case 3: {
                    double b = r.evalD(env);
                    double a = l.evalD(env);
                    return b == 0.0 ? 0.0 : a / b;
                }
                case 4:
                    return l.evalD(env) < r.evalD(env) ? 1.0 : 0.0;
                case 5:
                    return l.evalD(env) <= r.evalD(env) ? 1.0 : 0.0;
                case 6:
                    return l.evalD(env) > r.evalD(env) ? 1.0 : 0.0;
                case 7:
                    return l.evalD(env) >= r.evalD(env) ? 1.0 : 0.0;
                case 8:
                    return (l.evalD(env) != 0.0 && r.evalD(env) != 0.0) ? 1.0 : 0.0;
                case 9:
                    return (l.evalD(env) != 0.0 || r.evalD(env) != 0.0) ? 1.0 : 0.0;
                case 10:
                    return valuesEqual(l.eval(env), r.eval(env)) ? 1.0 : 0.0;
                default:
                    return valuesEqual(l.eval(env), r.eval(env)) ? 0.0 : 1.0;
            }
        }
    }

    private static final class Ternary extends Expr {
        final Expr c, a, b;

        Ternary(Expr c, Expr a, Expr b) {
            this.c = c;
            this.a = a;
            this.b = b;
        }

        @Override
        public Object eval(MolangEnv env) {
            if (c.evalD(env) != 0.0) return a.eval(env);
            return b == null ? (Object) 0.0 : b.eval(env);
        }

        @Override
        public double evalD(MolangEnv env) {
            if (c.evalD(env) != 0.0) return a.evalD(env);
            return b == null ? 0.0 : b.evalD(env);
        }
    }

    private static final class Coalesce extends Expr {
        final Expr l, r;

        Coalesce(Expr l, Expr r) {
            this.l = l;
            this.r = r;
        }

        @Override
        public Object eval(MolangEnv env) {
            if (l instanceof Var v) {
                Object o = v.raw(env);
                return o != null ? o : r.eval(env);
            }
            Object o = l.eval(env);
            return o != null ? o : r.eval(env);
        }
    }

    private static final class Arrow extends Expr {
        final Expr l, r;

        Arrow(Expr l, Expr r) {
            this.l = l;
            this.r = r;
        }

        @Override
        public Object eval(MolangEnv env) {
            Object ref = l.eval(env);
            if (ref == null || ref instanceof Double d && d == 0.0) return 0.0;
            MolangEnv other = env.resolveEntity(ref);
            if (other == null) return 0.0;
            return r.eval(other);
        }
    }

    private static final class Assign extends Expr {
        final Var target;
        final Expr value;

        Assign(Var target, Expr value) {
            this.target = target;
            this.value = value;
        }

        @Override
        public Object eval(MolangEnv env) {
            Object v = value.eval(env);
            target.assign(env, v);
            return 0.0;
        }
    }

    private static final class Return extends Expr {
        final Expr value;

        Return(Expr v) {
            this.value = v;
        }

        @Override
        public Object eval(MolangEnv env) {
            return value.eval(env);
        }
    }

    private static final class Program extends Expr {
        final Expr[] stmts;

        Program(Expr[] s) {
            this.stmts = s;
        }

        @Override
        public Object eval(MolangEnv env) {
            for (Expr s : stmts) {
                if (s instanceof Return r) return r.value.eval(env);
                s.eval(env);
            }
            return 0.0;
        }
    }

    private static final class MathCall extends Expr {
        final String fn;
        final Expr[] a;

        MathCall(String fn, Expr[] a) {
            this.fn = fn;
            this.a = a;
        }

        private double arg(MolangEnv env, int i) {
            return i < a.length ? a[i].evalD(env) : 0.0;
        }

        @Override
        public Object eval(MolangEnv env) {
            return evalD(env);
        }

        @Override
        public double evalD(MolangEnv env) {
            switch (fn) {
                case "abs":
                    return Math.abs(arg(env, 0));
                case "acos":
                    return Math.toDegrees(Math.acos(arg(env, 0)));
                case "asin":
                    return Math.toDegrees(Math.asin(arg(env, 0)));
                case "atan":
                    return Math.toDegrees(Math.atan(arg(env, 0)));
                case "atan2":
                    return Math.toDegrees(Math.atan2(arg(env, 0), arg(env, 1)));
                case "ceil":
                    return Math.ceil(arg(env, 0));
                case "clamp":
                    return Math.max(arg(env, 1), Math.min(arg(env, 2), arg(env, 0)));
                case "cos":
                    return Math.cos(Math.toRadians(arg(env, 0)));
                case "sin":
                    return Math.sin(Math.toRadians(arg(env, 0)));
                case "die_roll": {
                    int n = (int) arg(env, 0);
                    double lo = arg(env, 1), hi = arg(env, 2), sum = 0;
                    for (int i = 0; i < n; i++) sum += lo + env.random() * (hi - lo);
                    return sum;
                }
                case "die_roll_integer": {
                    int n = (int) arg(env, 0);
                    int lo = (int) arg(env, 1), hi = (int) arg(env, 2);
                    double sum = 0;
                    for (int i = 0; i < n; i++) sum += lo + (int) Math.floor(env.random() * (hi - lo + 1));
                    return sum;
                }
                case "exp":
                    return Math.exp(arg(env, 0));
                case "floor":
                    return Math.floor(arg(env, 0));
                case "hermite_blend": {
                    double x = arg(env, 0);
                    return 3 * x * x - 2 * x * x * x;
                }
                case "lerp": {
                    double s = arg(env, 0), e = arg(env, 1), t = arg(env, 2);
                    return s + (e - s) * t;
                }
                case "lerprotate": {
                    double s = arg(env, 0), e = arg(env, 1), t = arg(env, 2);
                    double d = ((e - s) % 360.0 + 540.0) % 360.0 - 180.0;
                    return s + d * t;
                }
                case "ln":
                    return Math.log(arg(env, 0));
                case "max":
                    return Math.max(arg(env, 0), arg(env, 1));
                case "min":
                    return Math.min(arg(env, 0), arg(env, 1));
                case "min_angle": {
                    double x = arg(env, 0) % 360.0;
                    if (x >= 180.0) x -= 360.0;
                    if (x < -180.0) x += 360.0;
                    return x;
                }
                case "mod": {
                    double b = arg(env, 1);
                    return b == 0.0 ? 0.0 : arg(env, 0) % b;
                }
                case "pi":
                    return Math.PI;
                case "pow":
                    return Math.pow(arg(env, 0), arg(env, 1));
                case "random": {
                    double lo = arg(env, 0), hi = arg(env, 1);
                    return lo + env.random() * (hi - lo);
                }
                case "random_integer": {
                    int lo = (int) Math.floor(arg(env, 0)), hi = (int) Math.floor(arg(env, 1));
                    if (hi < lo) {
                        int t = lo;
                        lo = hi;
                        hi = t;
                    }
                    return lo + (int) Math.floor(env.random() * (hi - lo + 1));
                }
                case "round":
                {
                    double x = arg(env, 0);
                    return x < 0 ? -Math.floor(-x + 0.5) : Math.floor(x + 0.5);
                }
                case "sqrt":
                    return Math.sqrt(arg(env, 0));
                case "trunc": {
                    double x = arg(env, 0);
                    return x < 0 ? Math.ceil(x) : Math.floor(x);
                }
                case "sign": {
                    double x = arg(env, 0);
                    return x > 0 ? 1 : x < 0 ? -1 : 0;
                }
                default:
                    return 0.0;
            }
        }
    }

    // ------------------------------------------------------------------ Parser

    private static final class Parser {
        final String s;
        int p;

        Parser(String s) {
            this.s = s;
        }

        MolangException err(String m) {
            return new MolangException(m + " at " + p + " in '" + s + "'");
        }

        void ws() {
            while (p < s.length() && Character.isWhitespace(s.charAt(p))) p++;
        }

        boolean peek(String t) {
            ws();
            return s.startsWith(t, p);
        }

        boolean accept(String t) {
            if (peek(t)) {
                p += t.length();
                return true;
            }
            return false;
        }

        Expr parseProgram() {
            ws();
            if (p >= s.length()) return ZERO;
            List<Expr> stmts = new ArrayList<>();
            boolean multi = false;
            while (true) {
                ws();
                if (p >= s.length()) break;
                if (accept(";")) {
                    multi = true;
                    continue;
                }
                stmts.add(parseStatement());
                ws();
                if (p < s.length()) {
                    if (accept(";")) {
                        multi = true;
                    } else {
                        throw err("unexpected '" + s.charAt(p) + "'");
                    }
                }
            }
            if (stmts.isEmpty()) return ZERO;
            if (!multi && stmts.size() == 1 && !(stmts.get(0) instanceof Return) && !(stmts.get(0) instanceof Assign)) {
                return stmts.get(0);
            }
            return new Program(stmts.toArray(new Expr[0]));
        }

        Expr parseStatement() {
            ws();
            if (startsWithWord("return")) {
                p += 6;
                return new Return(parseTernary());
            }
            Expr lhs = parseTernary();
            ws();
            if (p < s.length() && s.charAt(p) == '=' && !s.startsWith("==", p)) {
                if (lhs instanceof Var v) {
                    p++;
                    return new Assign(v, parseTernary());
                }
                throw err("invalid assignment target");
            }
            return lhs;
        }

        boolean startsWithWord(String w) {
            ws();
            if (!s.regionMatches(true, p, w, 0, w.length())) return false;
            int e = p + w.length();
            return e >= s.length() || !(Character.isLetterOrDigit(s.charAt(e)) || s.charAt(e) == '_' || s.charAt(e) == '.');
        }

        Expr parseTernary() {
            Expr c = parseCoalesce();
            ws();
            if (p < s.length() && s.charAt(p) == '?' && !s.startsWith("??", p)) {
                p++;
                Expr a = parseTernary();
                ws();
                Expr b = null;
                if (accept(":")) b = parseTernary();
                return new Ternary(c, a, b);
            }
            return c;
        }

        Expr parseCoalesce() {
            Expr l = parseOr();
            while (peek("??")) {
                p += 2;
                l = new Coalesce(l, parseOr());
            }
            return l;
        }

        Expr parseOr() {
            Expr l = parseAnd();
            while (peek("||")) {
                p += 2;
                l = new Bin("||", l, parseAnd());
            }
            return l;
        }

        Expr parseAnd() {
            Expr l = parseEq();
            while (peek("&&")) {
                p += 2;
                l = new Bin("&&", l, parseEq());
            }
            return l;
        }

        Expr parseEq() {
            Expr l = parseRel();
            while (true) {
                if (peek("==")) {
                    p += 2;
                    l = new Bin("==", l, parseRel());
                } else if (peek("!=")) {
                    p += 2;
                    l = new Bin("!=", l, parseRel());
                } else break;
            }
            return l;
        }

        Expr parseRel() {
            Expr l = parseAdd();
            while (true) {
                if (peek("<=")) {
                    p += 2;
                    l = new Bin("<=", l, parseAdd());
                } else if (peek(">=")) {
                    p += 2;
                    l = new Bin(">=", l, parseAdd());
                } else if (peek("<")) {
                    p += 1;
                    l = new Bin("<", l, parseAdd());
                } else if (peek(">")) {
                    p += 1;
                    l = new Bin(">", l, parseAdd());
                } else break;
            }
            return l;
        }

        Expr parseAdd() {
            Expr l = parseMul();
            while (true) {
                ws();
                if (p < s.length() && s.charAt(p) == '+') {
                    p++;
                    l = new Bin("+", l, parseMul());
                } else if (p < s.length() && s.charAt(p) == '-' && !s.startsWith("->", p)) {
                    p++;
                    l = new Bin("-", l, parseMul());
                } else break;
            }
            return l;
        }

        Expr parseMul() {
            Expr l = parseUnary();
            while (true) {
                ws();
                if (p < s.length() && s.charAt(p) == '*') {
                    p++;
                    l = new Bin("*", l, parseUnary());
                } else if (p < s.length() && s.charAt(p) == '/') {
                    p++;
                    l = new Bin("/", l, parseUnary());
                } else break;
            }
            return l;
        }

        Expr parseUnary() {
            ws();
            if (p < s.length()) {
                char c = s.charAt(p);
                if (c == '-' && !s.startsWith("->", p)) {
                    p++;
                    Expr e = parseUnary();
                    if (e instanceof Const k && k.value instanceof Double) return new Const(-k.num);
                    return new Neg(e);
                }
                if (c == '+') {
                    p++;
                    return parseUnary();
                }
                if (c == '!' && !s.startsWith("!=", p)) {
                    p++;
                    return new Not(parseUnary());
                }
            }
            return parsePostfix();
        }

        Expr parsePostfix() {
            Expr e = parsePrimary();
            while (peek("->")) {
                p += 2;
                Expr r = parsePrimary();
                e = new Arrow(e, r);
            }
            return e;
        }

        Expr parsePrimary() {
            ws();
            if (p >= s.length()) throw err("unexpected end");
            char c = s.charAt(p);
            if (c == '(') {
                p++;
                Expr e = parseTernary();
                ws();
                if (!accept(")")) throw err("expected ')'");
                return e;
            }
            if (c == '\'') {
                int q = s.indexOf('\'', p + 1);
                if (q < 0) throw err("unterminated string");
                String str = s.substring(p + 1, q);
                p = q + 1;
                return new Const(str);
            }
            if (Character.isDigit(c) || (c == '.' && p + 1 < s.length() && Character.isDigit(s.charAt(p + 1)))) {
                return parseNumber();
            }
            if (Character.isLetter(c) || c == '_') {
                return parseIdent();
            }
            throw err("unexpected '" + c + "'");
        }

        Expr parseNumber() {
            int st = p;
            while (p < s.length() && (Character.isDigit(s.charAt(p)) || s.charAt(p) == '.')) p++;
            if (p < s.length() && (s.charAt(p) == 'e' || s.charAt(p) == 'E')) {
                int save = p;
                p++;
                if (p < s.length() && (s.charAt(p) == '+' || s.charAt(p) == '-')) p++;
                if (p < s.length() && Character.isDigit(s.charAt(p))) {
                    while (p < s.length() && Character.isDigit(s.charAt(p))) p++;
                } else p = save;
            }
            if (p < s.length() && (s.charAt(p) == 'f' || s.charAt(p) == 'F')) {
                String t = s.substring(st, p);
                p++;
                return new Const(Double.parseDouble(t));
            }
            return new Const(Double.parseDouble(s.substring(st, p)));
        }

        Expr parseIdent() {
            int st = p;
            while (p < s.length()) {
                char ch = s.charAt(p);
                if (Character.isLetterOrDigit(ch) || ch == '_') p++;
                else if (ch == '.' && p + 1 < s.length() && (Character.isLetter(s.charAt(p + 1)) || s.charAt(p + 1) == '_')) p++;
                else break;
            }
            String id = s.substring(st, p).toLowerCase(Locale.ROOT);
            switch (id) {
                case "true":
                    return new Const(1.0);
                case "false":
                    return new Const(0.0);
                case "this":
                    return new This();
                case "null":
                    return ZERO;
                default:
            }
            int dot = id.indexOf('.');
            String prefix = dot < 0 ? id : id.substring(0, dot);
            String rest = dot < 0 ? "" : id.substring(dot + 1);
            switch (prefix) {
                case "query":
                case "q": {
                    Expr[] args = parseArgsIfAny();
                    return new Query(rest, args == null ? new Expr[0] : args);
                }
                case "variable":
                case "v":
                    return new Var('v', rest);
                case "temp":
                case "t":
                    return new Var('t', rest);
                case "context":
                case "c":
                    return new Var('c', rest);
                case "math": {
                    Expr[] args = parseArgsIfAny();
                    return new MathCall(rest, args == null ? new Expr[0] : args);
                }
                case "array": {
                    ws();
                    if (p < s.length() && s.charAt(p) == '[') {
                        p++;
                        Expr idx = parseTernary();
                        ws();
                        if (!accept("]")) throw err("expected ']'");
                        return new ArrayIndex(rest, idx);
                    }
                    return new Resource("array", rest);
                }
                case "texture":
                case "geometry":
                case "material":
                    return new Resource(prefix, rest);
                default:
                    return new Resource("ident", id);
            }
        }

        Expr[] parseArgsIfAny() {
            ws();
            if (p < s.length() && s.charAt(p) == '(') {
                p++;
                List<Expr> args = new ArrayList<>();
                ws();
                if (accept(")")) return new Expr[0];
                while (true) {
                    args.add(parseTernary());
                    ws();
                    if (accept(",")) continue;
                    if (accept(")")) break;
                    throw err("expected ',' or ')'");
                }
                return args.toArray(new Expr[0]);
            }
            return null;
        }
    }
}
