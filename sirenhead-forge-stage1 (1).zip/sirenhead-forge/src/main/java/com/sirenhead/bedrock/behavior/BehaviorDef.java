package com.sirenhead.bedrock.behavior;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sirenhead.bedrock.anim.AnimateEntry;
import com.sirenhead.bedrock.anim.EntityAnimator;
import com.sirenhead.bedrock.json.Jsons;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Parsed BP {@code minecraft:entity}. */
public final class BehaviorDef {
    private final String identifier;
    private final boolean spawnable;
    private final boolean summonable;
    private final Map<String, PropertyDef> properties = new LinkedHashMap<>();
    private final Map<String, String> animationMap = new LinkedHashMap<>();
    private List<AnimateEntry> animate = new ArrayList<>();
    private List<String> preAnimation = new ArrayList<>();
    private final JsonObject components;
    private final Map<String, JsonObject> groups = new LinkedHashMap<>();
    private final Map<String, JsonElement> events = new LinkedHashMap<>();
    private final JsonObject raw;

    private BehaviorDef(String id, boolean spawnable, boolean summonable, JsonObject components, JsonObject raw) {
        this.identifier = id;
        this.spawnable = spawnable;
        this.summonable = summonable;
        this.components = components;
        this.raw = raw;
    }

    public static BehaviorDef parse(JsonObject root) {
        JsonObject e = Jsons.obj(root, "minecraft:entity");
        if (e == null) throw new IllegalArgumentException("no minecraft:entity");
        JsonObject desc = Jsons.obj(e, "description");
        JsonObject comps = Jsons.obj(e, "components");
        BehaviorDef d = new BehaviorDef(Jsons.str(desc, "identifier", "unknown:unknown"), Jsons.bool(desc, "is_spawnable", false),
                Jsons.bool(desc, "is_summonable", false), comps == null ? new JsonObject() : comps, e);

        JsonObject props = Jsons.obj(desc, "properties");
        if (props != null) {
            for (Map.Entry<String, JsonElement> en : props.entrySet()) {
                if (!en.getValue().isJsonObject()) continue;
                JsonObject p = en.getValue().getAsJsonObject();
                String type = Jsons.str(p, "type", "int");
                List<String> enums = new ArrayList<>();
                if (p.has("values") && p.get("values").isJsonArray()) for (JsonElement x : p.getAsJsonArray("values")) enums.add(x.getAsString());
                double min = 0, max = type.equals("bool") ? 1 : Integer.MAX_VALUE;
                if (p.has("range") && p.get("range").isJsonArray() && p.getAsJsonArray("range").size() >= 2) {
                    min = p.getAsJsonArray("range").get(0).getAsDouble();
                    max = p.getAsJsonArray("range").get(1).getAsDouble();
                }
                double def = 0;
                JsonElement de = p.get("default");
                if (de != null && de.isJsonPrimitive()) {
                    if (type.equals("enum") && de.getAsJsonPrimitive().isString()) def = Math.max(0, enums.indexOf(de.getAsString()));
                    else if (de.getAsJsonPrimitive().isBoolean()) def = de.getAsBoolean() ? 1 : 0;
                    else if (de.getAsJsonPrimitive().isNumber()) def = de.getAsDouble();
                }
                d.properties.put(en.getKey(), new PropertyDef(en.getKey(), type, def, enums, min, max, Jsons.bool(p, "client_sync", false)));
            }
        }
        JsonObject anims = Jsons.obj(desc, "animations");
        if (anims != null) for (Map.Entry<String, JsonElement> en : anims.entrySet()) d.animationMap.put(en.getKey(), en.getValue().getAsString());
        JsonObject scripts = Jsons.obj(desc, "scripts");
        if (scripts != null) {
            d.animate = EntityAnimator.parseAnimate(scripts.get("animate"));
            d.preAnimation = EntityAnimator.parseScriptList(scripts.get("pre_animation"));
        }
        JsonObject g = Jsons.obj(e, "component_groups");
        if (g != null) for (Map.Entry<String, JsonElement> en : g.entrySet()) if (en.getValue().isJsonObject()) d.groups.put(en.getKey(), en.getValue().getAsJsonObject());
        JsonObject ev = Jsons.obj(e, "events");
        if (ev != null) for (Map.Entry<String, JsonElement> en : ev.entrySet()) d.events.put(en.getKey(), en.getValue());
        return d;
    }

    public String identifier() {
        return identifier;
    }

    public boolean spawnable() {
        return spawnable;
    }

    public boolean summonable() {
        return summonable;
    }

    public Map<String, PropertyDef> properties() {
        return properties;
    }

    public JsonObject components() {
        return components;
    }

    public Map<String, JsonObject> componentGroups() {
        return groups;
    }

    public Map<String, JsonElement> events() {
        return events;
    }

    public Map<String, String> animationMap() {
        return animationMap;
    }

    public List<AnimateEntry> animate() {
        return animate;
    }

    public List<String> preAnimation() {
        return preAnimation;
    }

    public JsonObject raw() {
        return raw;
    }
}
