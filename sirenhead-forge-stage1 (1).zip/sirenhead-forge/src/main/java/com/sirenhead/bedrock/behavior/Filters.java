package com.sirenhead.bedrock.behavior;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.Locale;
import java.util.Set;
import java.util.function.Function;

/** Evaluator for Bedrock filter trees ({@code all_of} / {@code any_of} / {@code none_of} / leaf tests). */
public final class Filters {
    private Filters() {
    }

    /** Tests whose {@code value} is an argument (a family, a damage cause...) and whose fact is a boolean compared with {@code true}. */
    private static final Set<String> ARG_TESTS = Set.of("is_family", "has_damage", "has_tag", "has_equipment", "has_component",
            "has_mob_effect", "is_biome", "is_block", "on_block", "in_block", "is_variant", "has_container_open",
            "is_game_rule", "is_difficulty", "is_visible", "has_ability", "is_color", "is_skin_id", "is_mark_variant", "has_property");

    public static boolean test(JsonElement filters, Function<String, FilterContext> subjects) {
        if (filters == null || filters.isJsonNull()) return true;
        if (filters.isJsonArray()) {
            for (JsonElement e : filters.getAsJsonArray()) if (!test(e, subjects)) return false;
            return true;
        }
        if (!filters.isJsonObject()) return true;
        JsonObject o = filters.getAsJsonObject();
        if (o.has("test")) return leaf(o, subjects);
        boolean any = false;
        boolean ok = true;
        if (o.has("all_of")) {
            any = true;
            for (JsonElement e : arr(o.get("all_of"))) if (!test(e, subjects)) ok = false;
        }
        if (ok && o.has("any_of")) {
            any = true;
            boolean one = false;
            JsonArray a = arr(o.get("any_of"));
            if (a.size() == 0) one = true;
            for (JsonElement e : a) if (test(e, subjects)) one = true;
            ok = one;
        }
        if (ok && o.has("none_of")) {
            any = true;
            for (JsonElement e : arr(o.get("none_of"))) if (test(e, subjects)) ok = false;
        }
        return any ? ok : true;
    }

    private static JsonArray arr(JsonElement e) {
        if (e != null && e.isJsonArray()) return e.getAsJsonArray();
        JsonArray a = new JsonArray();
        if (e != null && !e.isJsonNull()) a.add(e);
        return a;
    }

    private static boolean leaf(JsonObject o, Function<String, FilterContext> subjects) {
        String test = o.get("test").getAsString();
        String subject = o.has("subject") ? o.get("subject").getAsString() : "self";
        String op = o.has("operator") ? o.get("operator").getAsString().toLowerCase(Locale.ROOT) : "==";
        String domain = o.has("domain") && o.get("domain").isJsonPrimitive() ? o.get("domain").getAsString() : null;
        String value = o.has("value") && o.get("value").isJsonPrimitive() ? o.get("value").getAsString() : null;
        FilterContext ctx = subjects.apply(subject);
        if (ctx == null) return false;
        boolean argTest = ARG_TESTS.contains(test);
        Object fact = ctx.fact(test, domain, argTest ? value : null);
        if (fact == null) return false;
        Object expected;
        if (argTest) expected = Boolean.TRUE;
        else expected = value == null ? Boolean.TRUE : parse(value);
        return compare(fact, expected, op);
    }

    private static Object parse(String v) {
        String t = v.trim();
        if (t.equalsIgnoreCase("true")) return Boolean.TRUE;
        if (t.equalsIgnoreCase("false")) return Boolean.FALSE;
        try {
            return Double.parseDouble(t);
        } catch (NumberFormatException e) {
            return t;
        }
    }

    private static boolean compare(Object fact, Object exp, String op) {
        if (fact instanceof Boolean || exp instanceof Boolean) {
            boolean f = toBool(fact), x = toBool(exp);
            switch (op) {
                case "!=":
                case "not":
                    return f != x;
                default:
                    return f == x;
            }
        }
        if (fact instanceof Number && exp instanceof Number) {
            double f = ((Number) fact).doubleValue(), x = ((Number) exp).doubleValue();
            switch (op) {
                case "!=":
                case "not":
                    return f != x;
                case "<":
                    return f < x;
                case ">":
                    return f > x;
                case "<=":
                    return f <= x;
                case ">=":
                    return f >= x;
                default:
                    return f == x;
            }
        }
        boolean eq = String.valueOf(fact).equals(String.valueOf(exp));
        return (op.equals("!=") || op.equals("not")) != eq;
    }

    private static boolean toBool(Object o) {
        if (o instanceof Boolean) return (Boolean) o;
        if (o instanceof Number) return ((Number) o).doubleValue() != 0;
        return o != null && Boolean.parseBoolean(String.valueOf(o));
    }
}
