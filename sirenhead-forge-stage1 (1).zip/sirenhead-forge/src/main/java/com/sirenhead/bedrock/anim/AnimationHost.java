package com.sirenhead.bedrock.anim;

import com.sirenhead.bedrock.molang.MolangEnv;

/** Bridge from the animation runtime to the game (implemented by the Forge glue). */
public interface AnimationHost {
    /** Entity queries plus persistent {@code v.*} storage. */
    MolangEnv env();

    /** BP side: a command string from {@code timeline}/{@code on_entry}/{@code on_exit} ("/execute ...", "@s evt"). */
    void command(String cmd);

    /** RP side: particle keyframe / state particle. {@code effect} is an entity short name (or full id). */
    void particle(String effect, String locator, String preEffectScript);

    /** RP side: sound keyframe. {@code effect} is an entity short name (or full event id). */
    void sound(String effect);
}
