package com.sirenhead.bedrock.command;

import java.util.ArrayList;
import java.util.List;

/** A command position: three coordinates, each absolute, relative ({@code ~}) or local ({@code ^}). */
public final class Pos {
    public static final class Coord {
        public final char kind; // 'a' absolute, '~' relative, '^' local
        public final double v;

        Coord(char kind, double v) {
            this.kind = kind;
            this.v = v;
        }
    }

    public final Coord[] c;

    private Pos(Coord[] c) {
        this.c = c;
    }

    public boolean isLocal() {
        return c[0].kind == '^';
    }

    /** Parses one token ({@code ~}, {@code ~1.5}, {@code ^^1^}, {@code ~~0.2~}, {@code -3}) into one or more coordinates. */
    public static List<Coord> parseToken(String s) {
        List<Coord> out = new ArrayList<>();
        int i = 0, n = s.length();
        while (i < n) {
            char k = 'a';
            char ch = s.charAt(i);
            if (ch == '~' || ch == '^') {
                k = ch;
                i++;
            }
            int j = i;
            if (j < n && (s.charAt(j) == '-' || s.charAt(j) == '+')) j++;
            while (j < n && (Character.isDigit(s.charAt(j)) || s.charAt(j) == '.')) j++;
            if (j < n && (s.charAt(j) == 'e' || s.charAt(j) == 'E') && j + 1 < n && (Character.isDigit(s.charAt(j + 1)) || s.charAt(j + 1) == '-')) {
                j += 2;
                while (j < n && Character.isDigit(s.charAt(j))) j++;
            }
            String num = s.substring(i, j);
            double v;
            if (num.isEmpty() || num.equals("-") || num.equals("+")) {
                if (k == 'a') throw new IllegalArgumentException("bad coordinate: " + s);
                v = 0;
            } else v = Double.parseDouble(num);
            out.add(new Coord(k, v));
            i = j;
            if (k == 'a' && i < n) throw new IllegalArgumentException("bad coordinate: " + s);
        }
        return out;
    }

    /** Result of {@link #parse}: the position and how many tokens it used. */
    public static final class Parsed {
        public final Pos pos;
        public final int used;

        Parsed(Pos pos, int used) {
            this.pos = pos;
            this.used = used;
        }
    }

    public static Parsed parse(List<String> toks, int from) {
        List<Coord> got = new ArrayList<>();
        int i = from;
        while (got.size() < 3) {
            if (i >= toks.size()) throw new IllegalArgumentException("position needs 3 coordinates");
            got.addAll(parseToken(toks.get(i)));
            i++;
        }
        if (got.size() != 3) throw new IllegalArgumentException("position needs exactly 3 coordinates");
        boolean loc = got.get(0).kind == '^';
        for (Coord k : got) if ((k.kind == '^') != loc) throw new IllegalArgumentException("cannot mix local and world coordinates");
        return new Parsed(new Pos(got.toArray(new Coord[0])), i - from);
    }

    public static Pos parseOne(String joined) {
        return parse(Lex.tokens(joined), 0).pos;
    }

    /** Resolves against an origin and rotation (Java degrees). Same maths as vanilla {@code LocalCoordinates}. */
    public double[] resolve(double ox, double oy, double oz, double yaw, double pitch) {
        if (isLocal()) {
            double left = c[0].v, up = c[1].v, fwd = c[2].v;
            double f = Math.cos(Math.toRadians(yaw + 90.0)), f1 = Math.sin(Math.toRadians(yaw + 90.0));
            double f2 = Math.cos(Math.toRadians(-pitch)), f3 = Math.sin(Math.toRadians(-pitch));
            double f4 = Math.cos(Math.toRadians(-pitch + 90.0)), f5 = Math.sin(Math.toRadians(-pitch + 90.0));
            double[] a = {f * f2, f3, f1 * f2};
            double[] b = {f * f4, f5, f1 * f4};
            double[] cr = {-(a[1] * b[2] - a[2] * b[1]), -(a[2] * b[0] - a[0] * b[2]), -(a[0] * b[1] - a[1] * b[0])};
            return new double[]{
                    ox + a[0] * fwd + b[0] * up + cr[0] * left,
                    oy + a[1] * fwd + b[1] * up + cr[1] * left,
                    oz + a[2] * fwd + b[2] * up + cr[2] * left};
        }
        double[] o = {ox, oy, oz};
        double[] r = new double[3];
        for (int i = 0; i < 3; i++) r[i] = c[i].kind == '~' ? o[i] + c[i].v : c[i].v;
        return r;
    }

    /** Resolves a rotation component ({@code ~}, {@code ~10} or absolute). */
    public static double rot(Coord k, double current) {
        return k.kind == '~' || k.kind == '^' ? current + k.v : k.v;
    }
}
