package com.sirenhead.bedrock.particle;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.sirenhead.bedrock.molang.Molang;
import com.sirenhead.bedrock.molang.MolangEnv;

/** A number-or-Molang value (constants are folded so hot paths avoid the interpreter). */
final class PVal {
    final double c;
    final Molang.Expr e; // null when constant

    private PVal(double c, Molang.Expr e) {
        this.c = c;
        this.e = e;
    }

    static PVal of(double d) {
        return new PVal(d, null);
    }

    static PVal parse(JsonElement el, double def) {
        if (el == null || !el.isJsonPrimitive()) return of(def);
        JsonPrimitive p = el.getAsJsonPrimitive();
        if (p.isNumber()) return of(p.getAsDouble());
        if (p.isBoolean()) return of(p.getAsBoolean() ? 1 : 0);
        return parse(p.getAsString(), def);
    }

    static PVal parse(String s, double def) {
        if (s == null) return of(def);
        String t = s.trim();
        if (t.isEmpty()) return of(def);
        try {
            return of(Double.parseDouble(t));
        } catch (NumberFormatException ignored) {
        }
        Molang.Expr ex = Molang.compileLenient(t);
        return ex.isConstant() ? of(ex.evalD(null)) : new PVal(def, ex);
    }

    /** Array of n values (a single value fills every slot; missing entries use def). */
    static PVal[] vec(JsonElement el, int n, double def) {
        PVal[] r = new PVal[n];
        if (el != null && el.isJsonArray()) {
            com.google.gson.JsonArray a = el.getAsJsonArray();
            for (int i = 0; i < n; i++) r[i] = i < a.size() ? parse(a.get(i), def) : of(def);
        } else if (el != null && el.isJsonPrimitive()) {
            PVal v = parse(el, def);
            for (int i = 0; i < n; i++) r[i] = v;
        } else {
            for (int i = 0; i < n; i++) r[i] = of(def);
        }
        return r;
    }

    double get(MolangEnv env) {
        return e == null ? c : e.evalD(env);
    }

    boolean bool(MolangEnv env) {
        return get(env) > 0.5;
    }

    boolean isConst() {
        return e == null;
    }
}
