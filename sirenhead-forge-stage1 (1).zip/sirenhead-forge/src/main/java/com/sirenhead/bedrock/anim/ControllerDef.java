package com.sirenhead.bedrock.anim;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sirenhead.bedrock.json.Jsons;
import com.sirenhead.bedrock.molang.Molang;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Parsed Bedrock animation controller ({@code animation_controllers.<name>}). Immutable. */
public final class ControllerDef {
    public final String name;
    public final String initialState;
    final Map<String, State> states = new LinkedHashMap<>();

    static final class StateAnim {
        String name;
        Molang.Expr blend; // null = 1
    }

    static final class Transition {
        String target;
        Molang.Expr cond;
    }

    /** on_entry / on_exit entry: a command ("/..." or "@...") or a Molang script. */
    static final class Action {
        String text;
        boolean command;
        Molang.Expr expr;
    }

    static final class VarDef {
        String name;
        Molang.Expr input;
        double[] curveX;
        double[] curveY;

        double eval(AnimEnv env) {
            double x = input == null ? 0 : input.evalD(env);
            if (curveX == null || curveX.length == 0) return x;
            int n = curveX.length;
            if (x <= curveX[0]) return curveY[0];
            if (x >= curveX[n - 1]) return curveY[n - 1];
            for (int i = 0; i < n - 1; i++) {
                if (x <= curveX[i + 1]) {
                    double f = (x - curveX[i]) / (curveX[i + 1] - curveX[i]);
                    return curveY[i] + (curveY[i + 1] - curveY[i]) * f;
                }
            }
            return curveY[n - 1];
        }
    }

    static final class ParticleSpec {
        String effect, locator, pre;
    }

    static final class State {
        String name;
        final List<StateAnim> animations = new ArrayList<>();
        final List<Transition> transitions = new ArrayList<>();
        final List<Action> onEntry = new ArrayList<>();
        final List<Action> onExit = new ArrayList<>();
        final List<VarDef> variables = new ArrayList<>();
        final List<ParticleSpec> particles = new ArrayList<>();
        final List<String> sounds = new ArrayList<>();
        double blendSeconds;          // constant blend_transition
        double[] blendCurveX, blendCurveY; // curve form (time -> new-state weight)
        boolean blendShortestPath;
    }

    private ControllerDef(String name, JsonObject o) {
        this.name = name;
        JsonObject st = Jsons.obj(o, "states");
        String init = Jsons.str(o, "initial_state", "default");
        if (st != null) {
            for (Map.Entry<String, JsonElement> e : st.entrySet()) {
                if (e.getValue().isJsonObject()) states.put(e.getKey(), parseState(e.getKey(), e.getValue().getAsJsonObject()));
            }
        }
        if (!states.containsKey(init) && !states.isEmpty()) init = states.keySet().iterator().next();
        this.initialState = init;
    }

    public static Map<String, ControllerDef> parseFile(JsonObject root) {
        Map<String, ControllerDef> out = new LinkedHashMap<>();
        JsonObject cs = Jsons.obj(root, "animation_controllers");
        if (cs == null) return out;
        for (Map.Entry<String, JsonElement> e : cs.entrySet()) {
            if (e.getValue().isJsonObject()) out.put(e.getKey(), new ControllerDef(e.getKey(), e.getValue().getAsJsonObject()));
        }
        return out;
    }

    private static State parseState(String name, JsonObject o) {
        State s = new State();
        s.name = name;
        JsonArray anims = Jsons.arr(o, "animations");
        if (anims != null) {
            for (JsonElement a : anims) {
                if (a.isJsonPrimitive()) {
                    StateAnim sa = new StateAnim();
                    sa.name = a.getAsString();
                    s.animations.add(sa);
                } else if (a.isJsonObject()) {
                    for (Map.Entry<String, JsonElement> e : a.getAsJsonObject().entrySet()) {
                        StateAnim sa = new StateAnim();
                        sa.name = e.getKey();
                        sa.blend = Molang.compileLenient(e.getValue().isJsonPrimitive() ? e.getValue().getAsString() : "1");
                        s.animations.add(sa);
                    }
                }
            }
        }
        JsonArray trs = Jsons.arr(o, "transitions");
        if (trs != null) {
            for (JsonElement t : trs) {
                if (!t.isJsonObject()) continue;
                for (Map.Entry<String, JsonElement> e : t.getAsJsonObject().entrySet()) {
                    Transition tr = new Transition();
                    tr.target = e.getKey();
                    tr.cond = Molang.compileLenient(e.getValue().isJsonPrimitive() ? e.getValue().getAsString() : "0");
                    s.transitions.add(tr);
                }
            }
        }
        actions(o.get("on_entry"), s.onEntry);
        actions(o.get("on_exit"), s.onExit);
        JsonObject vars = Jsons.obj(o, "variables");
        if (vars != null) {
            for (Map.Entry<String, JsonElement> e : vars.entrySet()) {
                if (!e.getValue().isJsonObject()) continue;
                JsonObject vo = e.getValue().getAsJsonObject();
                VarDef v = new VarDef();
                v.name = e.getKey().toLowerCase();
                v.input = Molang.compileLenient(Jsons.str(vo, "input", "0"));
                JsonObject rc = Jsons.obj(vo, "remap_curve");
                if (rc != null) {
                    List<double[]> pts = new ArrayList<>();
                    for (Map.Entry<String, JsonElement> p : rc.entrySet()) {
                        try {
                            pts.add(new double[]{Double.parseDouble(p.getKey()), p.getValue().getAsDouble()});
                        } catch (RuntimeException ignored) {
                        }
                    }
                    pts.sort((a, b) -> Double.compare(a[0], b[0]));
                    v.curveX = new double[pts.size()];
                    v.curveY = new double[pts.size()];
                    for (int i = 0; i < pts.size(); i++) {
                        v.curveX[i] = pts.get(i)[0];
                        v.curveY[i] = pts.get(i)[1];
                    }
                }
                s.variables.add(v);
            }
        }
        JsonElement pe = o.get("particle_effects");
        if (pe != null && pe.isJsonArray()) {
            for (JsonElement p : pe.getAsJsonArray()) {
                if (!p.isJsonObject()) continue;
                ParticleSpec ps = new ParticleSpec();
                ps.effect = Jsons.str(p.getAsJsonObject(), "effect", null);
                ps.locator = Jsons.str(p.getAsJsonObject(), "locator", null);
                ps.pre = Jsons.str(p.getAsJsonObject(), "pre_effect_script", null);
                if (ps.effect != null) s.particles.add(ps);
            }
        }
        JsonElement se = o.get("sound_effects");
        if (se != null && se.isJsonArray()) {
            for (JsonElement p : se.getAsJsonArray()) {
                if (p.isJsonObject()) {
                    String ef = Jsons.str(p.getAsJsonObject(), "effect", null);
                    if (ef != null) s.sounds.add(ef);
                }
            }
        }
        JsonElement bt = o.get("blend_transition");
        if (bt != null) {
            if (bt.isJsonPrimitive()) {
                try {
                    s.blendSeconds = bt.getAsDouble();
                } catch (RuntimeException ignored) {
                }
            } else if (bt.isJsonObject()) {
                List<double[]> pts = new ArrayList<>();
                for (Map.Entry<String, JsonElement> p : bt.getAsJsonObject().entrySet()) {
                    try {
                        pts.add(new double[]{Double.parseDouble(p.getKey()), p.getValue().getAsDouble()});
                    } catch (RuntimeException ignored) {
                    }
                }
                pts.sort((a, b) -> Double.compare(a[0], b[0]));
                if (!pts.isEmpty()) {
                    s.blendCurveX = new double[pts.size()];
                    s.blendCurveY = new double[pts.size()];
                    for (int i = 0; i < pts.size(); i++) {
                        s.blendCurveX[i] = pts.get(i)[0];
                        s.blendCurveY[i] = pts.get(i)[1];
                    }
                    s.blendSeconds = s.blendCurveX[pts.size() - 1];
                }
            }
        }
        s.blendShortestPath = Jsons.bool(o, "blend_via_shortest_path", false);
        return s;
    }

    static void actions(JsonElement el, List<Action> out) {
        if (el == null) return;
        List<JsonElement> parts = new ArrayList<>();
        if (el.isJsonArray()) el.getAsJsonArray().forEach(parts::add);
        else parts.add(el);
        for (JsonElement p : parts) {
            if (!p.isJsonPrimitive()) continue;
            Action a = new Action();
            a.text = p.getAsString();
            String t = a.text.trim();
            a.command = t.startsWith("/") || t.startsWith("@");
            if (!a.command) a.expr = Molang.compileLenient(t);
            out.add(a);
        }
    }
}
