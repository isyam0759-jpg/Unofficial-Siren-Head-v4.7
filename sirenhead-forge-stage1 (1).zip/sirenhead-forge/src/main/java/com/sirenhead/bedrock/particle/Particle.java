package com.sirenhead.bedrock.particle;

/** One live particle. Public fields are read by the renderer; do not modify them from outside. */
public final class Particle {
    // ---- render state (world space) ----
    public double wx, wy, wz;        // current world position
    public double pwx, pwy, pwz;     // world position one tick ago (for partial-tick interpolation)
    public double dirX = 0, dirY = 1, dirZ = 0;   // unit travel direction in world space (for direction_* facing modes)
    public float sizeX, sizeY;       // Bedrock size value (see BillboardMath.SIZE_IS_HALF_EXTENT)
    public float rotDeg;             // billboard roll in degrees
    public float u0, v0, u1, v1;     // normalised UV rectangle (v0 = top)
    public float r = 1, g = 1, b = 1, a = 1;
    public double age, lifetime;
    public boolean dead;

    // ---- simulation state (local space if the emitter uses emitter_local_space.position) ----
    double x, y, z;
    double vx, vy, vz;
    double rotRate;
    final double[] random = new double[4];
}
