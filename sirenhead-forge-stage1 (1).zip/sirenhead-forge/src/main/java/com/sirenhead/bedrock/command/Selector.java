package com.sirenhead.bedrock.command;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/** A Bedrock target selector ({@code @e[type=!ho:x,family=y,r=5,c=1,scores={a=1..2}]}) or a plain player name. */
public final class Selector {
    /** What a selector can look at. Implemented by the Forge glue (entities) and by tests (mocks). */
    public interface Target {
        boolean isPlayer();

        boolean isType(String type);

        boolean inFamily(String family);

        boolean hasTag(String tag);

        String name();

        /** 0 survival, 1 creative, 2 adventure, 3 spectator, -1 not a player. */
        int gameMode();

        /** null if the entity has no score for the objective. */
        Integer score(String objective);

        double x();

        double y();

        double z();

        double width();

        double height();

        double yaw();

        double pitch();

        int xpLevel();
    }

    public static final class Range {
        public final boolean neg;
        public final double min, max;

        Range(boolean neg, double min, double max) {
            this.neg = neg;
            this.min = min;
            this.max = max;
        }

        public boolean test(double v) {
            return (v >= min && v <= max) != neg;
        }

        /** {@code 5}, {@code 1..3}, {@code ..3}, {@code 2..}, optionally prefixed with {@code !}. */
        public static Range parse(String s) {
            boolean neg = s.startsWith("!");
            if (neg) s = s.substring(1);
            int d = s.indexOf("..");
            if (d < 0) {
                double v = Double.parseDouble(s);
                return new Range(neg, v, v);
            }
            String a = s.substring(0, d), b = s.substring(d + 2);
            return new Range(neg, a.isEmpty() ? Double.NEGATIVE_INFINITY : Double.parseDouble(a), b.isEmpty() ? Double.POSITIVE_INFINITY : Double.parseDouble(b));
        }
    }

    public final char kind; // 'e','a','p','r','s', 'n' (named player)
    public final String name; // for kind 'n'
    private final List<String[]> types = new ArrayList<>(); // {value, "!"?}
    private final List<String[]> families = new ArrayList<>();
    private final List<String[]> tags = new ArrayList<>();
    private final List<String[]> names = new ArrayList<>();
    private final Map<String, Range> scores = new LinkedHashMap<>();
    private final List<String[]> gameModes = new ArrayList<>();
    private String x, y, z, dx, dy, dz; // x/y/z may be "~", "~1"
    private double r = Double.NaN, rm = Double.NaN;
    private double rx = Double.NaN, rxm = Double.NaN, ry = Double.NaN, rym = Double.NaN;
    private double l = Double.NaN, lm = Double.NaN;
    private int count = Integer.MIN_VALUE;
    private boolean hasVolume;

    private Selector(char kind, String name) {
        this.kind = kind;
        this.name = name;
    }

    public int count() {
        return count == Integer.MIN_VALUE ? -1 : count;
    }

    /** true if the selector constrains position/distance (so it should be evaluated in the executor's dimension). */
    public boolean spatial() {
        return !Double.isNaN(r) || !Double.isNaN(rm) || hasVolume || x != null || y != null || z != null;
    }

    public boolean isSelf() {
        return kind == 's';
    }

    /** Radius limit ({@code r=}) or NaN. */
    public double maxRadius() {
        return r;
    }

    /** true if x/y/z override the origin used for r/rm/volume tests. */
    public boolean hasOriginOverride() {
        return x != null || y != null || z != null;
    }

    public boolean hasVolume() {
        return hasVolume;
    }

    // ------------------------------------------------------------------ parsing

    public static Selector parse(String s) {
        s = s.trim();
        if (s.length() < 2 || s.charAt(0) != '@') return new Selector('n', s.replace("\"", ""));
        char k = s.charAt(1);
        if (k == 'a' || k == 'e' || k == 'p' || k == 'r' || k == 's' || k == 'c' || k == 'v') {
            // @c / @v (agent) are not supported
        } else throw new IllegalArgumentException("unknown selector " + s);
        Selector sel = new Selector(k, null);
        if (k == 'p') sel.count = 1;
        if (k == 'r') sel.count = 1;
        int b = s.indexOf('[');
        if (b < 0) return sel;
        if (!s.endsWith("]")) throw new IllegalArgumentException("unterminated selector " + s);
        for (String arg : splitTop(s.substring(b + 1, s.length() - 1))) {
            int eq = arg.indexOf('=');
            if (eq < 0) continue;
            String key = arg.substring(0, eq).trim(), val = arg.substring(eq + 1).trim();
            sel.arg(key, val);
        }
        return sel;
    }

    private static List<String> splitTop(String s) {
        List<String> out = new ArrayList<>();
        int depth = 0;
        boolean q = false;
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (c == '"') q = !q;
            if (!q) {
                if (c == '{' || c == '[') depth++;
                if (c == '}' || c == ']') depth--;
                if (c == ',' && depth == 0) {
                    out.add(sb.toString());
                    sb.setLength(0);
                    continue;
                }
            }
            sb.append(c);
        }
        if (sb.length() > 0) out.add(sb.toString());
        return out;
    }

    private static String[] neg(String v) {
        v = v.replace("\"", "");
        return v.startsWith("!") ? new String[]{v.substring(1), "!"} : new String[]{v, ""};
    }

    private void arg(String key, String val) {
        switch (key) {
            case "type": types.add(neg(val)); break;
            case "family": families.add(neg(val)); break;
            case "tag": tags.add(neg(val)); break;
            case "name": names.add(neg(val)); break;
            case "m":
            case "gamemode": gameModes.add(neg(val)); break;
            case "x": x = val; break;
            case "y": y = val; break;
            case "z": z = val; break;
            case "dx": dx = val; hasVolume = true; break;
            case "dy": dy = val; hasVolume = true; break;
            case "dz": dz = val; hasVolume = true; break;
            case "r": r = Double.parseDouble(val); break;
            case "rm": rm = Double.parseDouble(val); break;
            case "rx": rx = Double.parseDouble(val); break;
            case "rxm": rxm = Double.parseDouble(val); break;
            case "ry": ry = Double.parseDouble(val); break;
            case "rym": rym = Double.parseDouble(val); break;
            case "l": l = Double.parseDouble(val); break;
            case "lm": lm = Double.parseDouble(val); break;
            case "c": count = Integer.parseInt(val); break;
            case "scores": {
                String inner = val.trim();
                if (inner.startsWith("{")) inner = inner.substring(1);
                if (inner.endsWith("}")) inner = inner.substring(0, inner.length() - 1);
                for (String part : splitTop(inner)) {
                    int e = part.indexOf('=');
                    if (e > 0) scores.put(part.substring(0, e).trim(), Range.parse(part.substring(e + 1).trim()));
                }
                break;
            }
            default:
                break; // hasitem, haspermission, ... ignored
        }
    }

    // ------------------------------------------------------------------ matching

    private static double coord(String spec, double origin) {
        if (spec.startsWith("~")) return origin + (spec.length() > 1 ? Double.parseDouble(spec.substring(1)) : 0);
        return Double.parseDouble(spec);
    }

    private static boolean sameCase(String a, String b) {
        return a.equalsIgnoreCase(b);
    }

    private static String normType(String t) {
        return t.startsWith("minecraft:") ? t.substring("minecraft:".length()) : t;
    }

    /** All filters except count/sort/@s/@p. */
    public boolean test(Target t, double ox, double oy, double oz) {
        if (kind == 'n') return t.isPlayer() && sameCase(t.name(), name);
        if (kind == 'a' && !t.isPlayer()) return false;
        if (kind == 'p' && !t.isPlayer()) return false;
        // type: positives are alternatives, negatives all apply
        boolean anyPos = false, posOk = false;
        for (String[] ty : types) {
            boolean m = t.isType(normType(ty[0]));
            if (ty[1].isEmpty()) {
                anyPos = true;
                posOk |= m;
            } else if (m) return false;
        }
        if (anyPos && !posOk) return false;
        for (String[] f : families) if (t.inFamily(f[0]) == !f[1].isEmpty()) return false;
        for (String[] g : tags) if (t.hasTag(g[0]) == !g[1].isEmpty()) return false;
        for (String[] n : names) if (sameCase(t.name() == null ? "" : t.name(), n[0]) == !n[1].isEmpty()) return false;
        for (String[] g : gameModes) {
            if (!t.isPlayer()) return false;
            int gm = gm(g[0]);
            if ((t.gameMode() == gm) == !g[1].isEmpty()) return false;
        }
        for (Map.Entry<String, Range> e : scores.entrySet()) {
            Integer v = t.score(e.getKey());
            if (v == null || !e.getValue().test(v)) return false;
        }
        if (!Double.isNaN(l) && t.xpLevel() > l) return false;
        if (!Double.isNaN(lm) && t.xpLevel() < lm) return false;
        // origin for r/rm: x/y/z overrides when given
        double bx = x != null ? coord(x, ox) : ox, by = y != null ? coord(y, oy) : oy, bz = z != null ? coord(z, oz) : oz;
        if (!Double.isNaN(r) || !Double.isNaN(rm)) {
            double d = Math.sqrt((t.x() - bx) * (t.x() - bx) + (t.y() - by) * (t.y() - by) + (t.z() - bz) * (t.z() - bz));
            if (!Double.isNaN(r) && d > r) return false;
            if (!Double.isNaN(rm) && d < rm) return false;
        }
        if (hasVolume) {
            double ddx = dx == null ? 0 : Double.parseDouble(dx), ddy = dy == null ? 0 : Double.parseDouble(dy), ddz = dz == null ? 0 : Double.parseDouble(dz);
            double minX = bx + Math.min(0, ddx), maxX = bx + Math.max(0, ddx) + 1;
            double minY = by + Math.min(0, ddy), maxY = by + Math.max(0, ddy) + 1;
            double minZ = bz + Math.min(0, ddz), maxZ = bz + Math.max(0, ddz) + 1;
            double hw = t.width() / 2;
            if (t.x() + hw < minX || t.x() - hw > maxX || t.y() + t.height() < minY || t.y() > maxY || t.z() + hw < minZ || t.z() - hw > maxZ) return false;
        }
        if (!Double.isNaN(rx) && t.pitch() > rx) return false;
        if (!Double.isNaN(rxm) && t.pitch() < rxm) return false;
        double yw = ((t.yaw() % 360) + 360) % 360;
        if (!Double.isNaN(ry) && yw > ry) return false;
        if (!Double.isNaN(rym) && yw < rym) return false;
        return true;
    }

    private static int gm(String s) {
        switch (s) {
            case "0": case "s": case "survival": return 0;
            case "1": case "c": case "creative": return 1;
            case "2": case "a": case "adventure": return 2;
            default: return 3;
        }
    }

    /** Applies filters, ordering ({@code @p}/{@code c=N} nearest first, negative c farthest first, {@code @r} random) and count. */
    public <T extends Target> List<T> select(List<T> candidates, double ox, double oy, double oz, T self, Random rng) {
        if (kind == 's') {
            List<T> l1 = new ArrayList<>();
            if (self != null && test(self, ox, oy, oz)) l1.add(self);
            return l1;
        }
        List<T> out = new ArrayList<>();
        for (T t : candidates) if (test(t, ox, oy, oz)) out.add(t);
        if (kind == 'r') {
            java.util.Collections.shuffle(out, rng);
        } else if (kind == 'p' || count != Integer.MIN_VALUE) {
            final boolean far = count < 0 && kind != 'p';
            Comparator<T> cmp = Comparator.comparingDouble(t -> sq(t, ox, oy, oz));
            out.sort(far ? cmp.reversed() : cmp);
        }
        if (count != Integer.MIN_VALUE) {
            int n = Math.abs(count);
            if (out.size() > n) out = new ArrayList<>(out.subList(0, n));
        }
        return out;
    }

    private static double sq(Target t, double ox, double oy, double oz) {
        double a = t.x() - ox, b = t.y() - oy, c = t.z() - oz;
        return a * a + b * b + c * c;
    }
}
