package com.sirenhead.bedrock.behavior;

import com.sirenhead.bedrock.molang.MolangEnv;

import java.util.Random;

/** What {@link BehaviorState} needs from the game. */
public interface BehaviorHost {
    /** Component groups / properties changed: the host rebuilds goals, attributes, timers. */
    void onComponentsChanged();

    /** A {@code queue_command} entry. {@code target} is "self" or "target". */
    void runCommand(String command, String target);

    Random random();

    /** Subject = self / other / target / player / parent / baby / damager; null if not available. */
    FilterContext filterContext(String subject);

    /** Environment for {@code set_property} expressions. */
    MolangEnv env();

    /** A property value changed (the host syncs {@code client_sync} properties to clients). */
    default void onPropertyChanged(String name, double value) {
    }

    /** {@code reset_target} / {@code trigger} on other entities etc. are not needed by the add-on; hook for logging. */
    default void warn(String message) {
    }
}
