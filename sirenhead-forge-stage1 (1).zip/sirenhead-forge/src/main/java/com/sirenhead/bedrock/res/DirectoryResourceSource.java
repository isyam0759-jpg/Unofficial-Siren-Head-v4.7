package com.sirenhead.bedrock.res;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

/** {@link ResourceSource} over a directory on disk (used by tests and dev tools). */
public final class DirectoryResourceSource implements ResourceSource {
    private final Path root;

    public DirectoryResourceSource(Path root) {
        this.root = root;
    }

    @Override
    public String readText(String path) {
        Path p = root.resolve(path);
        if (!Files.isRegularFile(p)) return null;
        try {
            return new String(Files.readAllBytes(p), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    @Override
    public List<String> list(String dir, String suffix) {
        Path base = root.resolve(dir);
        if (!Files.isDirectory(base)) return List.of();
        try (Stream<Path> s = Files.walk(base)) {
            List<String> out = new ArrayList<>();
            s.filter(Files::isRegularFile).forEach(p -> {
                String rel = root.relativize(p).toString().replace('\\', '/');
                if (rel.endsWith(suffix)) out.add(rel);
            });
            Collections.sort(out);
            return out;
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }
}
