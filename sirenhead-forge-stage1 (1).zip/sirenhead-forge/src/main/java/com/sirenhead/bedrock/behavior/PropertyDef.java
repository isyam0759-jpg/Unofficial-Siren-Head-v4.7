package com.sirenhead.bedrock.behavior;

import java.util.List;

/** An entity property from {@code description.properties} (int / float / bool / enum). Enums are stored as their index. */
public record PropertyDef(String name, String type, double def, List<String> enumValues, double min, double max, boolean clientSync) {

    public double clamp(double v) {
        if (type.equals("bool")) return v != 0 ? 1 : 0;
        if (type.equals("enum")) return Math.max(0, Math.min(enumValues.size() - 1, Math.round(v)));
        double c = Math.max(min, Math.min(max, v));
        return type.equals("int") ? Math.round(c) : c;
    }
}
