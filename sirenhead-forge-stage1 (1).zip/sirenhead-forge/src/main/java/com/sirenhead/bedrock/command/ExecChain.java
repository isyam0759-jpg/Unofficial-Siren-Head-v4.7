package com.sirenhead.bedrock.command;

import java.util.ArrayList;
import java.util.List;

/**
 * Parsed {@code execute} command: a list of context-changing stages followed by the command to run.
 * Handles the modern syntax ({@code execute as @s at @s positioned ^^^10 rotated ~ 0 run ...}) and the legacy one
 * ({@code execute <selector> <x y z> [detect x y z block data] <command>}).
 */
public final class ExecChain {
    public enum Kind { AS, AT, POSITIONED, POSITIONED_AS, ROTATED, ROTATED_AS, ANCHORED, FACING_POS, FACING_ENTITY, IF_ENTITY, IF_BLOCK, IF_SCORE_MATCHES, IF_SCORE_COMPARE, ALIGN, IN }

    public static final class Stage {
        public final Kind kind;
        public final boolean negate; // for IF_*: true == "unless"
        public final String sel;     // selector / dimension / anchor / block id
        public final Pos pos;
        public final Pos.Coord yaw, pitch;
        public final String objective, objective2, op;
        public final Selector.Range range;
        public String source; // IF_SCORE_COMPARE: second selector

        Stage(Kind kind, boolean negate, String sel, Pos pos, Pos.Coord yaw, Pos.Coord pitch, String objective, String objective2, String op, Selector.Range range) {
            this.kind = kind;
            this.negate = negate;
            this.sel = sel;
            this.pos = pos;
            this.yaw = yaw;
            this.pitch = pitch;
            this.objective = objective;
            this.objective2 = objective2;
            this.op = op;
            this.range = range;
        }

        Stage withSource(String s) {
            this.source = s;
            return this;
        }
    }

    public final List<Stage> stages = new ArrayList<>();
    public String run; // command to run at the end (null when there is none)

    private static Stage of(Kind k) {
        return new Stage(k, false, null, null, null, null, null, null, null, null);
    }

    private static Stage sel(Kind k, String s) {
        return new Stage(k, false, s, null, null, null, null, null, null, null);
    }

    private static Stage pos(Kind k, Pos p) {
        return new Stage(k, false, null, p, null, null, null, null, null, null);
    }

    public static boolean isModern(String first) {
        switch (first) {
            case "as": case "at": case "positioned": case "rotated": case "anchored": case "if": case "unless": case "run": case "facing": case "align": case "in": case "store":
                return true;
            default:
                return false;
        }
    }

    /** {@code toks} is the tokenized command, {@code toks[0] == "execute"}. */
    public static ExecChain parse(List<String> toks) {
        ExecChain ch = new ExecChain();
        int i = 1;
        if (i >= toks.size()) throw new IllegalArgumentException("execute: missing arguments");
        if (!isModern(toks.get(i))) {
            // legacy: execute <selector> <x y z> [detect x y z block data] <cmd...>
            ch.stages.add(sel(Kind.AS, toks.get(i)));
            ch.stages.add(sel(Kind.AT, "@s"));
            Pos.Parsed p = Pos.parse(toks, i + 1);
            ch.stages.add(pos(Kind.POSITIONED, p.pos));
            i = i + 1 + p.used;
            if (i < toks.size() && toks.get(i).equals("detect")) {
                Pos.Parsed d = Pos.parse(toks, i + 1);
                int j = i + 1 + d.used;
                String block = toks.get(j);
                ch.stages.add(new Stage(Kind.IF_BLOCK, false, block, d.pos, null, null, null, null, null, null));
                i = j + 2; // block + data value
            }
            ch.run = Lex.rest(toks, i);
            return ch;
        }
        while (i < toks.size()) {
            String t = toks.get(i++);
            switch (t) {
                case "as":
                    ch.stages.add(sel(Kind.AS, toks.get(i++)));
                    break;
                case "at":
                    ch.stages.add(sel(Kind.AT, toks.get(i++)));
                    break;
                case "in":
                    ch.stages.add(sel(Kind.IN, toks.get(i++)));
                    break;
                case "anchored":
                    ch.stages.add(sel(Kind.ANCHORED, toks.get(i++)));
                    break;
                case "align":
                    ch.stages.add(sel(Kind.ALIGN, toks.get(i++)));
                    break;
                case "positioned":
                    if (toks.get(i).equals("as")) {
                        ch.stages.add(sel(Kind.POSITIONED_AS, toks.get(i + 1)));
                        i += 2;
                    } else {
                        Pos.Parsed p = Pos.parse(toks, i);
                        ch.stages.add(pos(Kind.POSITIONED, p.pos));
                        i += p.used;
                    }
                    break;
                case "rotated":
                    if (toks.get(i).equals("as")) {
                        ch.stages.add(sel(Kind.ROTATED_AS, toks.get(i + 1)));
                        i += 2;
                    } else {
                        List<Pos.Coord> rc = new ArrayList<>();
                        while (rc.size() < 2) rc.addAll(Pos.parseToken(toks.get(i++)));
                        ch.stages.add(new Stage(Kind.ROTATED, false, null, null, rc.get(0), rc.get(1), null, null, null, null));
                    }
                    break;
                case "facing":
                    if (toks.get(i).equals("entity")) {
                        ch.stages.add(sel(Kind.FACING_ENTITY, toks.get(i + 1)));
                        i += 2;
                        if (i < toks.size() && (toks.get(i).equals("eyes") || toks.get(i).equals("feet"))) i++;
                    } else {
                        Pos.Parsed p = Pos.parse(toks, i);
                        ch.stages.add(pos(Kind.FACING_POS, p.pos));
                        i += p.used;
                    }
                    break;
                case "if":
                case "unless": {
                    boolean neg = t.equals("unless");
                    String what = toks.get(i++);
                    if (what.equals("entity")) {
                        ch.stages.add(new Stage(Kind.IF_ENTITY, neg, toks.get(i++), null, null, null, null, null, null, null));
                    } else if (what.equals("block")) {
                        Pos.Parsed p = Pos.parse(toks, i);
                        i += p.used;
                        String block = toks.get(i++);
                        ch.stages.add(new Stage(Kind.IF_BLOCK, neg, block, p.pos, null, null, null, null, null, null));
                    } else if (what.equals("score")) {
                        String target = toks.get(i++), obj = toks.get(i++), op = toks.get(i++);
                        if (op.equals("matches")) {
                            ch.stages.add(new Stage(Kind.IF_SCORE_MATCHES, neg, target, null, null, null, obj, null, op, Selector.Range.parse(toks.get(i++))));
                        } else {
                            String src = toks.get(i++), obj2 = toks.get(i++);
                            ch.stages.add(new Stage(Kind.IF_SCORE_COMPARE, neg, target, null, null, null, obj, obj2, op, null).withSource(src));
                        }
                    } else throw new IllegalArgumentException("execute " + t + " " + what + " is not supported");
                    break;
                }
                case "run":
                    ch.run = Lex.rest(toks, i);
                    return ch;
                default:
                    throw new IllegalArgumentException("execute: unsupported subcommand '" + t + "'");
            }
        }
        return ch;
    }
}
