package com.sirenhead.bedrock.anim;

import com.google.gson.JsonObject;
import com.sirenhead.bedrock.json.Jsons;
import com.sirenhead.bedrock.res.ResourceSource;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/** All animations, controllers, client entity definitions and render controllers of one pack root. */
public final class BedrockAnimLibrary {
    private static final Logger LOG = Logger.getLogger("sirenhead.bedrock");

    private final Map<String, AnimationDef> animations = new LinkedHashMap<>();
    private final Map<String, ControllerDef> controllers = new LinkedHashMap<>();
    private final Map<String, ClientEntityDef> clientEntities = new LinkedHashMap<>();
    private final Map<String, RenderControllerDef> renderControllers = new LinkedHashMap<>();
    private final List<String> warnings = new ArrayList<>();
    /** Names defined in more than one file; the file loaded last (path order) wins, as in Bedrock. */
    private final Map<String, List<String>> duplicates = new LinkedHashMap<>();

    private BedrockAnimLibrary() {
    }

    private static String join(String root, String sub) {
        return root == null || root.isEmpty() ? sub : root + "/" + sub;
    }

    /** {@code rootDir} is {@code BedrockPaths.RP} or {@code BedrockPaths.BP} ("" in raw-addon tests). */
    public static BedrockAnimLibrary load(ResourceSource src, String rootDir) {
        BedrockAnimLibrary lib = new BedrockAnimLibrary();
        for (String p : src.list(join(rootDir, "animations"), ".json")) {
            try {
                for (Map.Entry<String, AnimationDef> e : AnimationDef.parseFile(Jsons.parseObject(src.readText(p))).entrySet()) {
                    if (lib.animations.put(e.getKey(), e.getValue()) != null) lib.duplicates.computeIfAbsent(e.getKey(), k -> new ArrayList<>()).add(p);
                }
            } catch (RuntimeException ex) {
                lib.warnings.add("cannot parse " + p + ": " + ex);
            }
        }
        for (String p : src.list(join(rootDir, "animation_controllers"), ".json")) {
            try {
                for (Map.Entry<String, ControllerDef> e : ControllerDef.parseFile(Jsons.parseObject(src.readText(p))).entrySet()) {
                    if (lib.controllers.put(e.getKey(), e.getValue()) != null) lib.duplicates.computeIfAbsent(e.getKey(), k -> new ArrayList<>()).add(p);
                }
            } catch (RuntimeException ex) {
                lib.warnings.add("cannot parse " + p + ": " + ex);
            }
        }
        for (String p : src.list(join(rootDir, "entity"), ".json")) {
            try {
                ClientEntityDef d = ClientEntityDef.parse(Jsons.parseObject(src.readText(p)));
                if (d != null && d.identifier() != null) lib.clientEntities.put(d.identifier(), d);
            } catch (RuntimeException ex) {
                lib.warnings.add("cannot parse " + p + ": " + ex);
            }
        }
        for (String p : src.list(join(rootDir, "render_controllers"), ".json")) {
            try {
                lib.renderControllers.putAll(RenderControllerDef.parseAll(Jsons.parseObject(src.readText(p))));
            } catch (RuntimeException ex) {
                lib.warnings.add("cannot parse " + p + ": " + ex);
            }
        }
        lib.animations.put("animation.common.look_at_target", builtinLookAt());
        for (String w : lib.warnings) LOG.log(Level.WARNING, w);
        if (!lib.duplicates.isEmpty()) {
            LOG.log(Level.INFO, "{0} animation/controller names are defined in several files (last file wins)", lib.duplicates.size());
        }
        return lib;
    }

    private static AnimationDef builtinLookAt() {
        String json = "{\"animations\":{\"animation.common.look_at_target\":{\"loop\":true,\"bones\":{\"head\":{\"rotation\":[\"query.target_x_rotation\",\"query.target_y_rotation\",0]}}}}}";
        return AnimationDef.parseFile(Jsons.parseObject(json)).get("animation.common.look_at_target");
    }

    public AnimationDef animation(String fullName) {
        return animations.get(fullName);
    }

    public ControllerDef controller(String fullName) {
        return controllers.get(fullName);
    }

    public ClientEntityDef clientEntity(String identifier) {
        return clientEntities.get(identifier);
    }

    public RenderControllerDef renderController(String fullName) {
        return renderControllers.get(fullName);
    }

    public Map<String, AnimationDef> animations() {
        return Collections.unmodifiableMap(animations);
    }

    public Map<String, ControllerDef> controllers() {
        return Collections.unmodifiableMap(controllers);
    }

    public Map<String, ClientEntityDef> clientEntities() {
        return Collections.unmodifiableMap(clientEntities);
    }

    public Map<String, RenderControllerDef> renderControllers() {
        return Collections.unmodifiableMap(renderControllers);
    }

    /** Names defined in several files, mapped to the files that redefined them. */
    public Map<String, List<String>> duplicates() {
        return Collections.unmodifiableMap(duplicates);
    }

    /** Load-time problems (unparseable definitions). */
    public List<String> warnings() {
        return warnings;
    }

    private static final java.util.Set<String> GLOBAL_WARNED = java.util.concurrent.ConcurrentHashMap.newKeySet();

    /** Logs {@code msg} once per JVM (the per-animator set is kept for API symmetry). */
    static void warnOnce(java.util.Set<String> seen, String msg) {
        seen.add(msg);
        if (GLOBAL_WARNED.size() < 2000 && GLOBAL_WARNED.add(msg)) LOG.log(Level.WARNING, msg);
    }
}
