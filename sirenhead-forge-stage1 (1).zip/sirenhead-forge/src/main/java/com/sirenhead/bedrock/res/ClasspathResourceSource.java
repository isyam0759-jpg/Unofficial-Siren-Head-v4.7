package com.sirenhead.bedrock.res;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.sirenhead.bedrock.json.Jsons;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * {@link ResourceSource} reading from the mod jar / classpath. Directory listing is answered from
 * {@code <indexPath>} (a JSON array of every logical path), generated at build time by {@code tools/port_assets.py},
 * because class loaders cannot list directories portably.
 */
public final class ClasspathResourceSource implements ResourceSource {
    private final ClassLoader loader;
    private final List<String> index = new ArrayList<>();

    public ClasspathResourceSource(ClassLoader loader, String... indexPaths) {
        this.loader = loader;
        for (String ip : indexPaths) {
            String text = readFrom(loader, ip);
            if (text == null) continue;
            JsonElement e = Jsons.parse(text);
            if (e.isJsonArray()) {
                JsonArray a = e.getAsJsonArray();
                for (JsonElement x : a) index.add(x.getAsString());
            }
        }
        Collections.sort(index);
    }

    private static String readFrom(ClassLoader loader, String path) {
        try (InputStream in = loader.getResourceAsStream(path)) {
            if (in == null) return null;
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return null;
        }
    }

    @Override
    public String readText(String path) {
        return readFrom(loader, path);
    }

    @Override
    public List<String> list(String dir, String suffix) {
        String prefix = dir.endsWith("/") ? dir : dir + "/";
        List<String> out = new ArrayList<>();
        for (String p : index) {
            if (p.startsWith(prefix) && p.endsWith(suffix)) out.add(p);
        }
        return out;
    }
}
