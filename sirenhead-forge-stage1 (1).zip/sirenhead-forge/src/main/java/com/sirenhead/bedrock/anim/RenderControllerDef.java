package com.sirenhead.bedrock.anim;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sirenhead.bedrock.json.Jsons;
import com.sirenhead.bedrock.molang.Molang;
import com.sirenhead.bedrock.molang.MolangEnv;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Parsed RP render controller: picks geometry / texture / material for an entity each frame. */
public final class RenderControllerDef {
    public record Choice(String geometryId, String texturePath, String material) {
    }

    public final String name;
    private final String geometryExpr;
    private final List<String> textureExprs = new ArrayList<>();
    private final String materialExpr;
    /** lower-case array name (e.g. "skins") -> element expressions. */
    private final Map<String, List<String>> arrays = new LinkedHashMap<>();

    private RenderControllerDef(String name, JsonObject o) {
        this.name = name;
        this.geometryExpr = Jsons.str(o, "geometry", "Geometry.default");
        JsonArray tx = Jsons.arr(o, "textures");
        if (tx != null) for (JsonElement t : tx) if (t.isJsonPrimitive()) textureExprs.add(t.getAsString());
        String mat = "Material.default";
        JsonArray ms = Jsons.arr(o, "materials");
        if (ms != null && ms.size() > 0 && ms.get(0).isJsonObject()) {
            for (Map.Entry<String, JsonElement> e : ms.get(0).getAsJsonObject().entrySet()) {
                if (e.getValue().isJsonPrimitive()) {
                    mat = e.getValue().getAsString();
                    break;
                }
            }
        }
        this.materialExpr = mat;
        JsonObject ar = Jsons.obj(o, "arrays");
        if (ar != null) {
            for (Map.Entry<String, JsonElement> kind : ar.entrySet()) { // textures / geometries / materials
                if (!kind.getValue().isJsonObject()) continue;
                for (Map.Entry<String, JsonElement> arr : kind.getValue().getAsJsonObject().entrySet()) {
                    String key = arr.getKey().toLowerCase(Locale.ROOT);
                    if (key.startsWith("array.")) key = key.substring(6);
                    List<String> els = new ArrayList<>();
                    if (arr.getValue().isJsonArray()) {
                        for (JsonElement el : arr.getValue().getAsJsonArray()) if (el.isJsonPrimitive()) els.add(el.getAsString());
                    }
                    arrays.put(key, els);
                }
            }
        }
    }

    public static Map<String, RenderControllerDef> parseAll(JsonObject root) {
        Map<String, RenderControllerDef> out = new LinkedHashMap<>();
        JsonObject rcs = Jsons.obj(root, "render_controllers");
        if (rcs == null) return out;
        for (Map.Entry<String, JsonElement> e : rcs.entrySet()) {
            if (e.getValue().isJsonObject()) out.put(e.getKey(), new RenderControllerDef(e.getKey(), e.getValue().getAsJsonObject()));
        }
        return out;
    }

    /** Resolves {@code Geometry.x}, {@code Texture.x}, {@code Material.x} and {@code Array.x[i]} against the entity definition. */
    public Choice resolve(MolangEnv env, ClientEntityDef def) {
        MolangEnv r = new ResolveEnv(env, def, this);
        String geo = asString(Molang.compileLenient(geometryExpr).eval(r));
        String tex = textureExprs.isEmpty() ? null : asString(Molang.compileLenient(textureExprs.get(0)).eval(r));
        String mat = asString(Molang.compileLenient(materialExpr).eval(r));
        return new Choice(geo, tex, mat);
    }

    private static String asString(Object o) {
        return o instanceof String s ? s : null;
    }

    private static final class ResolveEnv implements MolangEnv {
        final MolangEnv base;
        final ClientEntityDef def;
        final RenderControllerDef rc;

        ResolveEnv(MolangEnv base, ClientEntityDef def, RenderControllerDef rc) {
            this.base = base;
            this.def = def;
            this.rc = rc;
        }

        @Override
        public Object query(String name, Object[] args) {
            return base.query(name, args);
        }

        @Override
        public Object getVar(String path) {
            return base.getVar(path);
        }

        @Override
        public void setVar(String path, Object value) {
            base.setVar(path, value);
        }

        @Override
        public Object getTemp(String path) {
            return base.getTemp(path);
        }

        @Override
        public void setTemp(String path, Object value) {
            base.setTemp(path, value);
        }

        @Override
        public Object getContext(String path) {
            return base.getContext(path);
        }

        @Override
        public double thisValue() {
            return 0;
        }

        @Override
        public MolangEnv resolveEntity(Object ref) {
            return base.resolveEntity(ref);
        }

        @Override
        public double random() {
            return base.random();
        }

        @Override
        public Object resource(String kind, String name) {
            switch (kind) {
                case "texture":
                    return lookup(def.textures(), name);
                case "geometry":
                    return lookup(def.geometry(), name);
                case "material":
                    return lookup(def.materials(), name);
                case "array": {
                    List<String> els = rc.arrays.get(name);
                    if (els == null) return null;
                    List<Object> out = new ArrayList<>();
                    for (String s : els) out.add(Molang.compileLenient(s).eval(this));
                    return out;
                }
                default:
                    return base.resource(kind, name);
            }
        }

        private static String lookup(Map<String, String> m, String key) {
            String v = m.get(key);
            if (v != null) return v;
            for (Map.Entry<String, String> e : m.entrySet()) if (e.getKey().equalsIgnoreCase(key)) return e.getValue();
            return null;
        }
    }
}
