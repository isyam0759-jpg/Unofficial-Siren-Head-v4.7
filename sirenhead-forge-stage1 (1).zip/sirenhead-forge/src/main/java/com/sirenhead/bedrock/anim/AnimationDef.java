package com.sirenhead.bedrock.anim;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sirenhead.bedrock.json.Jsons;
import com.sirenhead.bedrock.molang.Molang;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Parsed Bedrock animation ({@code animations.<name>}). Immutable. */
public final class AnimationDef {
    public enum Loop {ONCE, LOOP, HOLD}

    public final String name;
    public final double length;
    public final Loop loop;
    final Molang.Expr animTimeUpdate;
    final Val blendWeight;
    public final boolean overridePrevious;
    final Map<String, BoneAnim> bones = new LinkedHashMap<>();
    final Events<String> timeline;
    final Events<String> sounds;
    final Events<ParticleEv> particles;

    record ParticleEv(String effect, String locator, String preScript) {
    }

    /** Time-sorted event list. */
    static final class Events<T> {
        final double[] times;
        final List<List<T>> items;

        Events(double[] times, List<List<T>> items) {
            this.times = times;
            this.items = items;
        }

        static <T> Events<T> empty() {
            return new Events<>(new double[0], List.of());
        }

        boolean isEmpty() {
            return times.length == 0;
        }
    }

    static final class Key {
        double time;
        Val[] pre;
        Val[] post;
        int mode; // 0 linear, 1 catmullrom, 2 step
    }

    static final class Channel {
        Val[] constant; // non-null for constant/expression channels
        Key[] keys;     // non-null for keyframed channels
    }

    static final class BoneAnim {
        Channel rot, pos, scale;
    }

    private AnimationDef(String name, JsonObject o) {
        this.name = name;
        JsonElement lp = o.get("loop");
        Loop l = Loop.ONCE;
        if (lp != null && lp.isJsonPrimitive()) {
            if (lp.getAsJsonPrimitive().isBoolean()) l = lp.getAsBoolean() ? Loop.LOOP : Loop.ONCE;
            else if ("hold_on_last_frame".equals(lp.getAsString())) l = Loop.HOLD;
        }
        this.loop = l;
        this.overridePrevious = Jsons.bool(o, "override_previous_animation", false);
        String atu = Jsons.str(o, "anim_time_update", null);
        this.animTimeUpdate = atu == null ? null : Molang.compileLenient(atu);
        JsonElement bw = o.get("blend_weight");
        this.blendWeight = bw == null ? null : Val.parse(bw, 1);

        JsonObject bo = Jsons.obj(o, "bones");
        double maxT = 0;
        if (bo != null) {
            for (Map.Entry<String, JsonElement> be : bo.entrySet()) {
                if (!be.getValue().isJsonObject()) continue;
                JsonObject b = be.getValue().getAsJsonObject();
                BoneAnim ba = new BoneAnim();
                ba.rot = channel(b.get("rotation"), 0);
                ba.pos = channel(b.get("position"), 0);
                ba.scale = channel(b.get("scale"), 1);
                for (Channel c : new Channel[]{ba.rot, ba.pos, ba.scale}) {
                    if (c != null && c.keys != null) maxT = Math.max(maxT, c.keys[c.keys.length - 1].time);
                }
                if (ba.rot != null || ba.pos != null || ba.scale != null) bones.put(be.getKey(), ba);
            }
        }
        this.timeline = parseEvents(o.get("timeline"), 0);
        this.sounds = parseEvents(o.get("sound_effects"), 1);
        this.particles = parseEvents(o.get("particle_effects"), 2);
        double evMax = 0;
        for (double t : timeline.times) evMax = Math.max(evMax, t);
        for (double t : sounds.times) evMax = Math.max(evMax, t);
        for (double t : particles.times) evMax = Math.max(evMax, t);
        double len = Jsons.num(o, "animation_length", Double.NaN);
        if (Double.isNaN(len)) {
            len = Math.max(maxT, evMax);
        }
        this.length = len;
    }

    public static Map<String, AnimationDef> parseFile(JsonObject root) {
        Map<String, AnimationDef> out = new LinkedHashMap<>();
        JsonObject anims = Jsons.obj(root, "animations");
        if (anims == null) return out;
        for (Map.Entry<String, JsonElement> e : anims.entrySet()) {
            if (e.getValue().isJsonObject()) out.put(e.getKey(), new AnimationDef(e.getKey(), e.getValue().getAsJsonObject()));
        }
        return out;
    }

    // ------------------------------------------------------------------ parsing helpers

    private static Val[] vec(JsonElement el, double def) {
        Val[] v = new Val[3];
        if (el != null && el.isJsonArray()) {
            JsonArray a = el.getAsJsonArray();
            for (int i = 0; i < 3; i++) v[i] = i < a.size() ? Val.parse(a.get(i), def) : Val.of(def);
        } else if (el != null && el.isJsonPrimitive()) {
            Val s = Val.parse(el, def);
            v[0] = v[1] = v[2] = s; // scalar broadcast (scale: 2 == [2,2,2])
        } else {
            for (int i = 0; i < 3; i++) v[i] = Val.of(def);
        }
        return v;
    }

    private static Channel channel(JsonElement el, double def) {
        if (el == null) return null;
        Channel c = new Channel();
        if (el.isJsonObject()) {
            JsonObject o = el.getAsJsonObject();
            List<Key> keys = new ArrayList<>();
            for (Map.Entry<String, JsonElement> e : o.entrySet()) {
                double t;
                try {
                    t = Double.parseDouble(e.getKey());
                } catch (NumberFormatException ex) {
                    continue;
                }
                Key k = new Key();
                k.time = t;
                JsonElement v = e.getValue();
                if (v.isJsonObject()) {
                    JsonObject ko = v.getAsJsonObject();
                    JsonElement pre = ko.get("pre"), post = ko.get("post");
                    if (post == null) post = pre;
                    if (pre == null) pre = post;
                    k.post = vec(post, def);
                    k.pre = vec(pre, def);
                    String lm = Jsons.str(ko, "lerp_mode", "linear");
                    k.mode = lm.equals("catmullrom") ? 1 : lm.equals("step") ? 2 : 0;
                } else {
                    k.post = vec(v, def);
                    k.pre = k.post;
                }
                keys.add(k);
            }
            if (keys.isEmpty()) return null;
            keys.sort((a, b) -> Double.compare(a.time, b.time));
            c.keys = keys.toArray(new Key[0]);
        } else {
            c.constant = vec(el, def);
        }
        return c;
    }

    /** kind 0: timeline (string list per time), 1: sound_effects, 2: particle_effects. */
    @SuppressWarnings("unchecked")
    private static <T> Events<T> parseEvents(JsonElement el, int kind) {
        if (el == null || !el.isJsonObject()) return Events.empty();
        List<Object[]> rows = new ArrayList<>();
        for (Map.Entry<String, JsonElement> e : el.getAsJsonObject().entrySet()) {
            double t;
            try {
                t = Double.parseDouble(e.getKey());
            } catch (NumberFormatException ex) {
                continue;
            }
            List<Object> list = new ArrayList<>();
            JsonElement v = e.getValue();
            List<JsonElement> parts = new ArrayList<>();
            if (v.isJsonArray()) v.getAsJsonArray().forEach(parts::add);
            else parts.add(v);
            for (JsonElement p : parts) {
                if (kind == 0) {
                    if (p.isJsonPrimitive()) list.add(p.getAsString());
                } else if (kind == 1) {
                    if (p.isJsonObject()) {
                        String ef = Jsons.str(p.getAsJsonObject(), "effect", null);
                        if (ef != null) list.add(ef);
                    } else if (p.isJsonPrimitive()) list.add(p.getAsString());
                } else {
                    if (p.isJsonObject()) {
                        JsonObject po = p.getAsJsonObject();
                        String ef = Jsons.str(po, "effect", null);
                        if (ef != null) list.add(new ParticleEv(ef, Jsons.str(po, "locator", null), Jsons.str(po, "pre_effect_script", null)));
                    }
                }
            }
            if (!list.isEmpty()) rows.add(new Object[]{t, list});
        }
        rows.sort((a, b) -> Double.compare((Double) a[0], (Double) b[0]));
        double[] times = new double[rows.size()];
        List<List<T>> items = new ArrayList<>();
        for (int i = 0; i < times.length; i++) {
            times[i] = (Double) rows.get(i)[0];
            items.add((List<T>) rows.get(i)[1]);
        }
        return new Events<>(times, items);
    }

    // ------------------------------------------------------------------ sampling

    /** Effective animation length used for looping / finishing (0 if unknown). */
    public double effectiveLength() {
        return length;
    }

    /** Adds this animation (at {@code t} seconds, scaled by {@code weight}) to {@code pose}. */
    void apply(double t, double weight, AnimEnv env, Pose pose) {
        if (blendWeight != null) weight *= blendWeight.get(env);
        if (weight == 0) return;
        for (Map.Entry<String, BoneAnim> e : bones.entrySet()) {
            Pose.Bone pb = pose.get(e.getKey());
            BoneAnim ba = e.getValue();
            if (overridePrevious) pb.reset();
            pb.touched = true;
            if (ba.rot != null) accumulate(ba.rot, t, weight, env, pb.rot, false);
            if (ba.pos != null) accumulate(ba.pos, t, weight, env, pb.pos, false);
            if (ba.scale != null) accumulate(ba.scale, t, weight, env, pb.scale, true);
        }
    }

    private static void accumulate(Channel c, double t, double w, AnimEnv env, double[] acc, boolean multiplicative) {
        for (int i = 0; i < 3; i++) {
            env.thisValue = acc[i];
            double v = sample(c, i, t, env);
            if (multiplicative) acc[i] *= 1.0 + (v - 1.0) * w;
            else acc[i] += v * w;
        }
    }

    private static double sample(Channel c, int axis, double t, AnimEnv env) {
        if (c.constant != null) return c.constant[axis].get(env);
        Key[] ks = c.keys;
        int n = ks.length;
        if (t <= ks[0].time) return ks[0].pre[axis].get(env);
        if (t >= ks[n - 1].time) return ks[n - 1].post[axis].get(env);
        int lo = 0, hi = n - 1;
        while (hi - lo > 1) {
            int mid = (lo + hi) >>> 1;
            if (ks[mid].time <= t) lo = mid;
            else hi = mid;
        }
        Key k0 = ks[lo], k1 = ks[lo + 1];
        double a = k0.post[axis].get(env);
        double b = k1.pre[axis].get(env);
        double span = k1.time - k0.time;
        double f = span <= 0 ? 1 : (t - k0.time) / span;
        if (k0.mode == 2) return a;
        if (k0.mode == 1 || k1.mode == 1) {
            double p0 = lo > 0 ? ks[lo - 1].post[axis].get(env) : a;
            double p3 = lo + 2 < n ? ks[lo + 2].pre[axis].get(env) : b;
            double f2 = f * f, f3 = f2 * f;
            return 0.5 * ((2 * a) + (-p0 + b) * f + (2 * p0 - 5 * a + 4 * b - p3) * f2 + (-p0 + 3 * a - 3 * b + p3) * f3);
        }
        return a + (b - a) * f;
    }

    @Override
    public String toString() {
        return "AnimationDef{" + name + ", len=" + length + ", loop=" + loop + ", bones=" + Arrays.toString(bones.keySet().toArray()) + "}";
    }
}
