package com.sirenhead.bedrock.molang;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * Convenient base class: stores variables / temps / context in maps and exposes a settable {@code this} value.
 * Subclasses only need to implement {@link #query(String, Object[])}.
 */
public abstract class MolangEnvBase implements MolangEnv {
    protected final Map<String, Object> variables = new HashMap<>();
    protected final Map<String, Object> temps = new HashMap<>();
    protected final Map<String, Object> context = new HashMap<>();
    protected double thisValue;
    protected Random rng = new Random();

    @Override
    public Object getVar(String path) {
        return variables.get(path);
    }

    @Override
    public void setVar(String path, Object value) {
        variables.put(path, value);
    }

    @Override
    public Object getTemp(String path) {
        return temps.get(path);
    }

    @Override
    public void setTemp(String path, Object value) {
        temps.put(path, value);
    }

    @Override
    public Object getContext(String path) {
        return context.get(path);
    }

    public void setContext(String path, Object value) {
        context.put(path, value);
    }

    @Override
    public double thisValue() {
        return thisValue;
    }

    public void setThisValue(double v) {
        this.thisValue = v;
    }

    public Map<String, Object> variables() {
        return variables;
    }

    public void clearTemps() {
        temps.clear();
    }

    @Override
    public MolangEnv resolveEntity(Object entityRef) {
        return entityRef instanceof MolangEnv e ? e : null;
    }

    @Override
    public Object resource(String kind, String name) {
        return null;
    }

    @Override
    public double random() {
        return rng.nextDouble();
    }
}
