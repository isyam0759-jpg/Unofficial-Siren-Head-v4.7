package com.sirenhead.bedrock.particle;

import com.sirenhead.bedrock.molang.MolangEnv;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Simulation of one Bedrock particle emitter. Pure Java: the Forge client feeds it a transform every tick
 * ({@link #setTransform}), calls {@link #tick} with the elapsed seconds and renders {@link #particles()}.
 */
public final class ParticleEmitter {
    /** Hard cap per emitter (Bedrock has its own limits; this protects the client from runaway emitters). */
    public static final int MAX_PARTICLES = 2500;
    /** Looping emitters that are never stopped by their host end after this many seconds. */
    public static final double LOOP_SAFETY_SECONDS = 30.0;

    private final ParticleDef def;
    private final ParticleWorld world;
    private final Random rng;
    private final Map<String, Object> custom = new HashMap<>();
    private final Env env = new Env();
    private final List<Particle> particles = new ArrayList<>();
    private final double[] emitterRandom = new double[4];

    private double ex, ey, ez;
    private double cosY = 1, sinY = 0;
    private double evx, evy, evz;
    private boolean placed;

    private double age;
    private double activeTime;
    private boolean started;
    private boolean stopped;
    private boolean finished;
    private int lastLoop = -1;
    private double spawnAccum;
    private double lastEmitterLifetime;

    public ParticleEmitter(ParticleDef def, Map<String, Double> variables, long seed, ParticleWorld world) {
        this.def = def;
        this.world = world == null ? ParticleWorld.EMPTY : world;
        this.rng = new Random(seed);
        for (int i = 0; i < 4; i++) emitterRandom[i] = rng.nextDouble();
        if (variables != null) {
            for (Map.Entry<String, Double> en : variables.entrySet()) {
                custom.put(ParticleDef.varKey(en.getKey()), en.getValue());
            }
        }
    }

    public ParticleDef def() {
        return def;
    }

    public List<Particle> particles() {
        return particles;
    }

    public double x() {
        return ex;
    }

    public double y() {
        return ey;
    }

    public double z() {
        return ez;
    }

    /** cos/sin of the emitter yaw, for emitter_transform_* billboards. */
    public double cosYaw() {
        return cosY;
    }

    public double sinYaw() {
        return sinY;
    }

    public boolean isDone() {
        return finished;
    }

    /** Stop spawning; live particles finish their life. */
    public void stop() {
        stopped = true;
    }

    /** Immediately remove every particle. */
    public void kill() {
        stopped = true;
        particles.clear();
        finished = true;
    }

    /** Emitter position (world) and yaw in degrees (Minecraft convention, 0 = +Z). */
    public void setTransform(double x, double y, double z, double yawDeg) {
        if (!placed) {
            placed = true;
            evx = evy = evz = 0;
        }
        ex = x;
        ey = y;
        ez = z;
        double r = Math.toRadians(yawDeg);
        cosY = Math.cos(r);
        sinY = Math.sin(r);
    }

    private double pex, pey, pez;
    private boolean havePrev;

    // =================================================================== tick

    public void tick(double dt) {
        if (finished || dt <= 0) return;
        if (!havePrev) {
            pex = ex;
            pey = ey;
            pez = ez;
            havePrev = true;
        }
        evx = (ex - pex) / dt;
        evy = (ey - pey) / dt;
        evz = (ez - pez) / dt;
        pex = ex;
        pey = ey;
        pez = ez;

        env.cur = null;
        if (!started) {
            started = true;
            if (def.creationExpr != null) def.creationExpr.eval(env);
        }
        activeTime = def.activeTime.get(env);
        lastEmitterLifetime = activeTime;
        if (def.perUpdateExpr != null) def.perUpdateExpr.eval(env);

        // 1. advance live particles
        for (int i = 0; i < particles.size(); i++) step(particles.get(i), dt);
        particles.removeIf(p -> p.dead);

        // 2. spawn
        boolean active = !stopped && isActive();
        if (active) {
            if (def.steady) {
                spawnAccum += def.spawnRate.get(env) * dt;
                int max = (int) Math.min(MAX_PARTICLES, Math.max(0, def.maxParticles.get(env)));
                while (spawnAccum >= 1) {
                    spawnAccum -= 1;
                    if (particles.size() < max) spawn();
                }
                if (spawnAccum > 1) spawnAccum = 1;
            } else {
                int loop = loopIndex();
                if (loop > lastLoop) {
                    lastLoop = loop;
                    int n = (int) Math.max(0, Math.round(def.numParticles.get(env)));
                    for (int i = 0; i < n && particles.size() < MAX_PARTICLES; i++) spawn();
                }
            }
        }

        age += dt;

        // 3. finish
        boolean spawningOver = stopped || (!def.looping && age >= activeTime + 1e-9) || (def.looping && age > LOOP_SAFETY_SECONDS);
        if (spawningOver && particles.isEmpty()) finished = true;
    }

    private double cycle() {
        double c = activeTime + def.sleepTime.get(env);
        return c <= 1e-6 ? 1e-6 : c;
    }

    private int loopIndex() {
        return def.looping ? (int) Math.floor(age / cycle() + 1e-6) : 0;
    }

    private boolean isActive() {
        if (!def.looping) return age < activeTime + 1e-9 || age == 0;
        double c = cycle();
        double phase = age - Math.floor(age / c + 1e-6) * c;
        return phase < activeTime - 1e-9 || phase < 1e-6;
    }

    // =================================================================== spawning

    private void spawn() {
        Particle p = new Particle();
        for (int i = 0; i < 4; i++) p.random[i] = rng.nextDouble();
        env.cur = p;
        p.lifetime = Math.max(1e-4, def.maxLifetime.get(env));

        double[] pos = new double[3];
        double[] d = new double[3];
        shape(pos, d);

        double vx, vy, vz;
        if (def.speedVec != null) {
            vx = def.speedVec[0].get(env);
            vy = def.speedVec[1].get(env);
            vz = def.speedVec[2].get(env);
        } else {
            double s = def.speed.get(env);
            vx = d[0] * s;
            vy = d[1] * s;
            vz = d[2] * s;
        }

        if (def.localPos) {
            p.x = pos[0];
            p.y = pos[1];
            p.z = pos[2];
            p.vx = vx;
            p.vy = vy;
            p.vz = vz;
        } else {
            double[] o = def.localRot ? rotY(pos[0], pos[1], pos[2]) : pos;
            double[] v = def.localRot ? rotY(vx, vy, vz) : new double[]{vx, vy, vz};
            p.x = ex + o[0];
            p.y = ey + o[1];
            p.z = ez + o[2];
            p.vx = v[0];
            p.vy = v[1];
            p.vz = v[2];
            if (def.localVel) {
                p.vx += evx;
                p.vy += evy;
                p.vz += evz;
            }
        }
        p.rotDeg = (float) def.spinRot.get(env);
        p.rotRate = def.spinRate.get(env);
        toWorld(p);
        p.pwx = p.wx;
        p.pwy = p.wy;
        p.pwz = p.wz;
        updateDirection(p);
        appearance(p);
        particles.add(p);
        env.cur = null;
    }

    private void shape(double[] pos, double[] dir) {
        double ox = def.offset[0].get(env), oy = def.offset[1].get(env), oz = def.offset[2].get(env);
        double px = 0, py = 0, pz = 0;
        switch (def.shape) {
            case POINT:
                break;
            case DISC: {
                double r = def.radius.get(env);
                double nx = def.planeNormal[0].get(env), ny = def.planeNormal[1].get(env), nz = def.planeNormal[2].get(env);
                double nl = Math.sqrt(nx * nx + ny * ny + nz * nz);
                if (nl < 1e-9) {
                    nx = 0;
                    ny = 1;
                    nz = 0;
                } else {
                    nx /= nl;
                    ny /= nl;
                    nz /= nl;
                }
                // two vectors spanning the plane
                double ux, uy, uz;
                if (Math.abs(ny) < 0.9) { // u = n x Y
                    ux = nz;
                    uy = 0;
                    uz = -nx;
                } else {                   // u = n x X
                    ux = 0;
                    uy = nz;
                    uz = -ny;
                }
                double ul = Math.sqrt(ux * ux + uy * uy + uz * uz);
                ux /= ul;
                uy /= ul;
                uz /= ul;
                double wx = ny * uz - nz * uy, wy = nz * ux - nx * uz, wz = nx * uy - ny * ux;
                double ang = rng.nextDouble() * Math.PI * 2;
                double rad = def.surfaceOnly.bool(env) ? r : r * Math.sqrt(rng.nextDouble());
                double a = Math.cos(ang) * rad, b = Math.sin(ang) * rad;
                px = ux * a + wx * b;
                py = uy * a + wy * b;
                pz = uz * a + wz * b;
                break;
            }
            case BOX: {
                double hx = def.halfDim[0].get(env), hy = def.halfDim[1].get(env), hz = def.halfDim[2].get(env);
                px = (rng.nextDouble() * 2 - 1) * hx;
                py = (rng.nextDouble() * 2 - 1) * hy;
                pz = (rng.nextDouble() * 2 - 1) * hz;
                if (def.surfaceOnly.bool(env)) {
                    double ax = hy * hz, ay = hx * hz, az = hx * hy; // face areas (per side)
                    double t = rng.nextDouble() * (ax + ay + az);
                    double sgn = rng.nextBoolean() ? 1 : -1;
                    if (t < ax) px = sgn * hx;
                    else if (t < ax + ay) py = sgn * hy;
                    else pz = sgn * hz;
                }
                break;
            }
            case SPHERE: {
                double r = def.radius.get(env);
                double x, y, z, l;
                do {
                    x = rng.nextGaussian();
                    y = rng.nextGaussian();
                    z = rng.nextGaussian();
                    l = Math.sqrt(x * x + y * y + z * z);
                } while (l < 1e-9);
                double rad = def.surfaceOnly.bool(env) ? r : r * Math.cbrt(rng.nextDouble());
                px = x / l * rad;
                py = y / l * rad;
                pz = z / l * rad;
                break;
            }
            default:
                break;
        }
        // direction (relative to the shape centre = the offset)
        double dx, dy, dz;
        switch (def.dirMode) {
            case OUTWARDS:
                dx = px;
                dy = py;
                dz = pz;
                if (dx * dx + dy * dy + dz * dz < 1e-12) {
                    double[] r = randomUnit();
                    dx = r[0];
                    dy = r[1];
                    dz = r[2];
                }
                break;
            case INWARDS:
                dx = -px;
                dy = -py;
                dz = -pz;
                if (dx * dx + dy * dy + dz * dz < 1e-12) {
                    double[] r = randomUnit();
                    dx = r[0];
                    dy = r[1];
                    dz = r[2];
                }
                break;
            default:
                dx = def.dir[0].get(env);
                dy = def.dir[1].get(env);
                dz = def.dir[2].get(env);
                break;
        }
        double l = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (l > 1e-12) {
            dx /= l;
            dy /= l;
            dz /= l;
        } else {
            dx = dy = dz = 0;
        }
        pos[0] = ox + px;
        pos[1] = oy + py;
        pos[2] = oz + pz;
        dir[0] = dx;
        dir[1] = dy;
        dir[2] = dz;
    }

    private double[] randomUnit() {
        double x, y, z, l;
        do {
            x = rng.nextGaussian();
            y = rng.nextGaussian();
            z = rng.nextGaussian();
            l = Math.sqrt(x * x + y * y + z * z);
        } while (l < 1e-9);
        return new double[]{x / l, y / l, z / l};
    }

    private double[] rotY(double x, double y, double z) {
        return new double[]{x * cosY - z * sinY, y, x * sinY + z * cosY};
    }

    // =================================================================== per-particle update

    private void toWorld(Particle p) {
        if (def.localPos) {
            if (def.localRot) {
                p.wx = ex + p.x * cosY - p.z * sinY;
                p.wz = ez + p.x * sinY + p.z * cosY;
            } else {
                p.wx = ex + p.x;
                p.wz = ez + p.z;
            }
            p.wy = ey + p.y;
        } else {
            p.wx = p.x;
            p.wy = p.y;
            p.wz = p.z;
        }
    }

    private void updateDirection(Particle p) {
        double vx = p.vx, vy = p.vy, vz = p.vz;
        if (!def.dirDerive && def.dirCustom != null) {
            vx = def.dirCustom[0].get(env);
            vy = def.dirCustom[1].get(env);
            vz = def.dirCustom[2].get(env);
        } else if (def.localPos && def.localRot) {
            double nx = vx * cosY - vz * sinY, nz = vx * sinY + vz * cosY;
            vx = nx;
            vz = nz;
        }
        double l = Math.sqrt(vx * vx + vy * vy + vz * vz);
        if (l > Math.max(def.dirMinSpeed, 1e-9)) {
            p.dirX = vx / l;
            p.dirY = vy / l;
            p.dirZ = vz / l;
        }
    }

    private void step(Particle p, double dt) {
        env.cur = p;
        p.age += dt;
        if (p.age >= p.lifetime) {
            p.dead = true;
            return;
        }
        p.pwx = p.wx;
        p.pwy = p.wy;
        p.pwz = p.wz;
        if (def.dynamic) {
            double ax = def.accel[0].get(env), ay = def.accel[1].get(env), az = def.accel[2].get(env);
            double drag = def.drag.get(env);
            p.vx += (ax - drag * p.vx) * dt;
            p.vy += (ay - drag * p.vy) * dt;
            p.vz += (az - drag * p.vz) * dt;
            p.rotRate += (def.rotAccel.get(env) - def.rotDrag.get(env) * p.rotRate) * dt;
        }
        p.rotDeg += (float) (p.rotRate * dt);

        if (def.collision && def.colEnabled.bool(env)) {
            collide(p, dt);
            if (p.dead) return;
        } else {
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.z += p.vz * dt;
        }
        toWorld(p);
        updateDirection(p);

        if (def.expireIfNotIn != null || def.expireIfIn != null) {
            String id = world.blockId((int) Math.floor(p.wx), (int) Math.floor(p.wy), (int) Math.floor(p.wz));
            if ((def.expireIfNotIn != null && !def.expireIfNotIn.contains(id)) || (def.expireIfIn != null && def.expireIfIn.contains(id))) {
                p.dead = true;
                return;
            }
        }
        appearance(p);
    }

    private void collide(Particle p, double dt) {
        double r = def.colRadius.get(env);
        double rest = def.colRestitution.get(env);
        double drag = def.colDrag.get(env);
        boolean contact = false;
        double ny = p.y + p.vy * dt;
        if (hits(p.x, ny, p.z, r)) {
            p.vy = -p.vy * rest;
            contact = true;
        } else {
            p.y = ny;
        }
        double nx = p.x + p.vx * dt;
        if (hits(nx, p.y, p.z, r)) {
            p.vx = -p.vx * rest;
            contact = true;
        } else {
            p.x = nx;
        }
        double nz = p.z + p.vz * dt;
        if (hits(p.x, p.y, nz, r)) {
            p.vz = -p.vz * rest;
            contact = true;
        } else {
            p.z = nz;
        }
        if (contact) {
            if (def.colExpire) {
                p.dead = true;
                return;
            }
            double f = Math.max(0, 1 - drag * dt);
            p.vx *= f;
            p.vy *= f;
            p.vz *= f;
        }
    }

    private boolean hits(double lx, double ly, double lz, double r) {
        double wx, wz;
        double wy = def.localPos ? ey + ly : ly;
        if (def.localPos) {
            if (def.localRot) {
                wx = ex + lx * cosY - lz * sinY;
                wz = ez + lx * sinY + lz * cosY;
            } else {
                wx = ex + lx;
                wz = ez + lz;
            }
        } else {
            wx = lx;
            wz = lz;
        }
        int x0 = (int) Math.floor(wx - r), x1 = (int) Math.floor(wx + r);
        int y0 = (int) Math.floor(wy - r), y1 = (int) Math.floor(wy + r);
        int z0 = (int) Math.floor(wz - r), z1 = (int) Math.floor(wz + r);
        for (int x = x0; x <= x1; x++)
            for (int y = y0; y <= y1; y++)
                for (int z = z0; z <= z1; z++)
                    if (world.isSolid(x, y, z)) return true;
        return false;
    }

    private void appearance(Particle p) {
        p.sizeX = (float) def.size[0].get(env);
        p.sizeY = (float) def.size[1].get(env);

        // colour
        switch (def.tintKind) {
            case 1:
                p.r = (float) def.tint[0].get(env);
                p.g = (float) def.tint[1].get(env);
                p.b = (float) def.tint[2].get(env);
                p.a = (float) def.tint[3].get(env);
                break;
            case 2: {
                double t = def.interpolant.get(env);
                double[] gp = def.gradPos;
                float[][] gc = def.gradCol;
                int n = gp.length;
                float[] c;
                if (t <= gp[0]) c = gc[0];
                else if (t >= gp[n - 1]) c = gc[n - 1];
                else {
                    int i = 0;
                    while (i < n - 2 && t > gp[i + 1]) i++;
                    double span = gp[i + 1] - gp[i];
                    float f = span <= 1e-12 ? 0f : (float) ((t - gp[i]) / span);
                    float[] a = gc[i], b = gc[i + 1];
                    c = new float[]{a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f, a[3] + (b[3] - a[3]) * f};
                }
                p.r = c[0];
                p.g = c[1];
                p.b = c[2];
                p.a = c[3];
                break;
            }
            default:
                p.r = p.g = p.b = p.a = 1f;
                break;
        }

        // uv
        double tw = def.texW.get(env), th = def.texH.get(env);
        if (tw == 0) tw = 1;
        if (th == 0) th = 1;
        double u, v, w, h;
        if (def.flipbook) {
            double max = Math.max(1, Math.floor(def.fbMax.get(env)));
            double frame = def.fbStretch ? p.age / p.lifetime * max : p.age * def.fbFps.get(env);
            frame = Math.floor(frame);
            if (def.fbLoop) frame = ((frame % max) + max) % max;
            else frame = Math.min(frame, max - 1);
            if (frame < 0) frame = 0;
            u = def.fbBase[0].get(env) + def.fbStep[0].get(env) * frame;
            v = def.fbBase[1].get(env) + def.fbStep[1].get(env) * frame;
            w = def.fbSize[0].get(env);
            h = def.fbSize[1].get(env);
        } else {
            u = def.uv[0].get(env);
            v = def.uv[1].get(env);
            w = def.uvSize[0].get(env);
            h = def.uvSize[1].get(env);
        }
        p.u0 = (float) (u / tw);
        p.v0 = (float) (v / th);
        p.u1 = (float) ((u + w) / tw);
        p.v1 = (float) ((v + h) / th);
    }

    // =================================================================== Molang environment

    private final class Env implements MolangEnv {
        Particle cur;
        private final Map<String, Object> temps = new HashMap<>();
        private int curveDepth;
        /** Fractional tick progress, set by the host for {@code query.frame_alpha}. */
        double frameAlpha;

        @Override
        public Object query(String name, Object[] args) {
            if (name.equals("frame_alpha")) return frameAlpha;
            if (name.equals("anim_time") || name.equals("life_time")) return cur != null ? cur.age : age;
            return null;
        }

        @Override
        public Object getVar(String path) {
            switch (path) {
                case "particle_age":
                    return cur == null ? 0.0 : cur.age;
                case "particle_lifetime":
                    return cur == null ? 0.0 : cur.lifetime;
                case "particle_random_1":
                    return cur == null ? 0.0 : cur.random[0];
                case "particle_random_2":
                    return cur == null ? 0.0 : cur.random[1];
                case "particle_random_3":
                    return cur == null ? 0.0 : cur.random[2];
                case "particle_random_4":
                    return cur == null ? 0.0 : cur.random[3];
                case "emitter_age":
                    return age;
                case "emitter_lifetime":
                    return lastEmitterLifetime;
                case "emitter_random_1":
                    return emitterRandom[0];
                case "emitter_random_2":
                    return emitterRandom[1];
                case "emitter_random_3":
                    return emitterRandom[2];
                case "emitter_random_4":
                    return emitterRandom[3];
                default:
                    break;
            }
            Curve c = def.curves.get(path);
            if (c != null && curveDepth < 4) {
                curveDepth++;
                try {
                    return c.eval(this);
                } finally {
                    curveDepth--;
                }
            }
            return custom.get(path);
        }

        @Override
        public void setVar(String path, Object value) {
            custom.put(path, value);
        }

        @Override
        public Object getTemp(String path) {
            return temps.get(path);
        }

        @Override
        public void setTemp(String path, Object value) {
            temps.put(path, value);
        }

        @Override
        public Object getContext(String path) {
            return null;
        }

        @Override
        public double thisValue() {
            return 0;
        }

        @Override
        public MolangEnv resolveEntity(Object entityRef) {
            return null;
        }

        @Override
        public Object resource(String kind, String name) {
            return null;
        }

        @Override
        public double random() {
            return rng.nextDouble();
        }
    }

    /** Fractional tick progress for {@code query.frame_alpha}. */
    public void setFrameAlpha(double a) {
        env.frameAlpha = a;
    }
}
