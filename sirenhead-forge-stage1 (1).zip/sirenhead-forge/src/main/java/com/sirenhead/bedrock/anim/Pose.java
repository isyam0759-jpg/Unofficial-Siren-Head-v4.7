package com.sirenhead.bedrock.anim;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Blended bone transforms for one frame, in Bedrock units (rotation degrees, position pixels, scale factor).
 * Only bones with {@link Bone#touched} set were driven by an animation.
 */
public final class Pose {
    public static final class Bone {
        public final double[] rot = new double[3];
        public final double[] pos = new double[3];
        public final double[] scale = {1, 1, 1};
        public boolean touched;

        void reset() {
            rot[0] = rot[1] = rot[2] = 0;
            pos[0] = pos[1] = pos[2] = 0;
            scale[0] = scale[1] = scale[2] = 1;
            touched = false;
        }
    }

    private final Map<String, Bone> bones = new LinkedHashMap<>();

    public Map<String, Bone> bones() {
        return bones;
    }

    public Bone get(String name) {
        return bones.computeIfAbsent(name, k -> new Bone());
    }

    public Bone peek(String name) {
        return bones.get(name);
    }

    public void reset() {
        for (Bone b : bones.values()) b.reset();
    }
}
