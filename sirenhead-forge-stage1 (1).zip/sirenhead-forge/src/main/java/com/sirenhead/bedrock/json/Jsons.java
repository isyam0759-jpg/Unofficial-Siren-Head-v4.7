package com.sirenhead.bedrock.json;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;

import java.io.StringReader;

/** Tolerant JSON helpers (Bedrock files contain comments, BOMs and trailing commas). */
public final class Jsons {
    private Jsons() {
    }

    public static JsonElement parse(String text) {
        if (text != null && !text.isEmpty() && text.charAt(0) == '﻿') text = text.substring(1);
        JsonReader r = new JsonReader(new StringReader(text));
        r.setLenient(true);
        return JsonParser.parseReader(r);
    }

    public static JsonObject parseObject(String text) {
        JsonElement e = parse(text);
        return e.isJsonObject() ? e.getAsJsonObject() : new JsonObject();
    }

    public static JsonObject obj(JsonObject o, String key) {
        JsonElement e = o == null ? null : o.get(key);
        return e != null && e.isJsonObject() ? e.getAsJsonObject() : null;
    }

    public static JsonArray arr(JsonObject o, String key) {
        JsonElement e = o == null ? null : o.get(key);
        return e != null && e.isJsonArray() ? e.getAsJsonArray() : null;
    }

    public static String str(JsonObject o, String key, String def) {
        JsonElement e = o == null ? null : o.get(key);
        return e != null && e.isJsonPrimitive() ? e.getAsString() : def;
    }

    public static double num(JsonObject o, String key, double def) {
        JsonElement e = o == null ? null : o.get(key);
        if (e == null || !e.isJsonPrimitive()) return def;
        try {
            if (e.getAsJsonPrimitive().isBoolean()) return e.getAsBoolean() ? 1 : 0;
            return e.getAsDouble();
        } catch (RuntimeException ex) {
            return def;
        }
    }

    public static boolean bool(JsonObject o, String key, boolean def) {
        JsonElement e = o == null ? null : o.get(key);
        if (e == null || !e.isJsonPrimitive()) return def;
        try {
            return e.getAsJsonPrimitive().isBoolean() ? e.getAsBoolean() : e.getAsDouble() != 0;
        } catch (RuntimeException ex) {
            return def;
        }
    }

    /** Numeric array of fixed size (missing entries use {@code def}); accepts a single number as all-components. */
    public static double[] vec(JsonElement e, int n, double def) {
        double[] r = new double[n];
        java.util.Arrays.fill(r, def);
        if (e == null) return r;
        if (e.isJsonPrimitive()) {
            try {
                java.util.Arrays.fill(r, e.getAsDouble());
            } catch (RuntimeException ignored) {
            }
            return r;
        }
        if (e.isJsonArray()) {
            JsonArray a = e.getAsJsonArray();
            for (int i = 0; i < n && i < a.size(); i++) {
                try {
                    r[i] = a.get(i).getAsDouble();
                } catch (RuntimeException ignored) {
                }
            }
        }
        return r;
    }
}
