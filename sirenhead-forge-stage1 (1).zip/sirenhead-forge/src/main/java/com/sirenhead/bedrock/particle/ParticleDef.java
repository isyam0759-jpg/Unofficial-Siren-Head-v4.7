package com.sirenhead.bedrock.particle;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sirenhead.bedrock.json.Jsons;
import com.sirenhead.bedrock.molang.Molang;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/** Parsed Bedrock {@code particle_effect} (format 1.10.0 component model). */
public final class ParticleDef {

    public enum Facing {
        ROTATE_XYZ, ROTATE_Y, LOOKAT_XYZ, LOOKAT_Y, DIRECTION_X, DIRECTION_Y, DIRECTION_Z,
        EMITTER_TRANSFORM_XY, EMITTER_TRANSFORM_XZ, EMITTER_TRANSFORM_YZ, LOOKAT_DIRECTION
    }

    enum Shape { POINT, DISC, BOX, SPHERE }

    enum Dir { CUSTOM, OUTWARDS, INWARDS }

    // ---- description
    private final String identifier;
    private final String material;
    private final String texture;

    // ---- curves / emitter
    final Map<String, Curve> curves = new LinkedHashMap<>();
    Molang.Expr creationExpr;
    Molang.Expr perUpdateExpr;
    boolean looping;
    PVal activeTime = PVal.of(10);
    PVal sleepTime = PVal.of(0);
    boolean steady;
    PVal numParticles = PVal.of(10);
    PVal spawnRate = PVal.of(1);
    PVal maxParticles = PVal.of(50);
    Shape shape = Shape.POINT;
    PVal[] offset = PVal.vec(null, 3, 0);
    PVal radius = PVal.of(1);
    PVal[] halfDim = PVal.vec(null, 3, 1);
    PVal[] planeNormal = {PVal.of(0), PVal.of(1), PVal.of(0)};
    PVal surfaceOnly = PVal.of(0);
    Dir dirMode = Dir.CUSTOM;
    PVal[] dir = PVal.vec(null, 3, 0);
    boolean localPos, localRot, localVel;

    // ---- particle
    PVal maxLifetime = PVal.of(1);
    PVal speed = PVal.of(0);
    PVal[] speedVec;                  // non-null if initial_speed is an array
    PVal spinRot = PVal.of(0);
    PVal spinRate = PVal.of(0);
    boolean dynamic;
    PVal[] accel = PVal.vec(null, 3, 0);
    PVal drag = PVal.of(0);
    PVal rotAccel = PVal.of(0);
    PVal rotDrag = PVal.of(0);
    boolean collision;
    PVal colEnabled = PVal.of(1);
    PVal colDrag = PVal.of(0);
    PVal colRestitution = PVal.of(1);
    PVal colRadius = PVal.of(0.1);
    boolean colExpire;

    // ---- appearance
    PVal[] size = PVal.vec(null, 2, 0.1);
    Facing facing = Facing.ROTATE_XYZ;
    boolean dirDerive = true;
    PVal[] dirCustom;
    double dirMinSpeed = 0.01;
    PVal texW = PVal.of(1), texH = PVal.of(1);
    PVal[] uv = PVal.vec(null, 2, 0);
    PVal[] uvSize = {PVal.of(1), PVal.of(1)};
    boolean flipbook;
    PVal[] fbBase, fbSize, fbStep;
    PVal fbFps = PVal.of(1), fbMax = PVal.of(1);
    boolean fbStretch, fbLoop;
    int tintKind;                     // 0 white, 1 expression/constant, 2 gradient
    PVal[] tint;
    PVal interpolant = PVal.of(0);
    double[] gradPos = new double[0];
    float[][] gradCol = new float[0][];
    boolean lighting;
    Set<String> expireIfNotIn;
    Set<String> expireIfIn;

    private ParticleDef(String identifier, String material, String texture) {
        this.identifier = identifier;
        this.material = material;
        this.texture = texture;
    }

    public String identifier() {
        return identifier;
    }

    /** {@code particles_alpha} / {@code particles_blend} / {@code particles_add}. */
    public String material() {
        return material;
    }

    /** Bedrock texture path, e.g. {@code textures/particle/dust_cloud}. */
    public String texture() {
        return texture;
    }

    public Facing facing() {
        return facing;
    }

    public boolean lighting() {
        return lighting;
    }

    public boolean additive() {
        return material.contains("add");
    }

    public boolean hasCollision() {
        return collision;
    }

    // =================================================================== parsing

    public static ParticleDef parse(JsonObject root) {
        JsonObject pe = Jsons.obj(root, "particle_effect");
        if (pe == null) throw new IllegalArgumentException("no particle_effect");
        JsonObject desc = Jsons.obj(pe, "description");
        JsonObject brp = Jsons.obj(desc, "basic_render_parameters");
        ParticleDef d = new ParticleDef(Jsons.str(desc, "identifier", "unknown"),
                Jsons.str(brp, "material", "particles_alpha"), Jsons.str(brp, "texture", "textures/particle/particles"));

        JsonObject curves = Jsons.obj(pe, "curves");
        if (curves != null) {
            for (Map.Entry<String, JsonElement> en : curves.entrySet()) {
                if (en.getValue().isJsonObject()) d.curves.put(varKey(en.getKey()), Curve.parse(en.getValue().getAsJsonObject()));
            }
        }
        JsonObject c = Jsons.obj(pe, "components");
        if (c == null) c = new JsonObject();
        d.parseEmitter(c);
        d.parseParticle(c);
        d.parseAppearance(c);
        return d;
    }

    /** {@code variable.x} / {@code v.x} -> {@code x}. */
    static String varKey(String k) {
        String s = k.toLowerCase(Locale.ROOT);
        if (s.startsWith("variable.")) return s.substring(9);
        if (s.startsWith("v.")) return s.substring(2);
        return s;
    }

    private void parseEmitter(JsonObject c) {
        JsonObject o = Jsons.obj(c, "minecraft:emitter_initialization");
        if (o != null) {
            String ce = Jsons.str(o, "creation_expression", null);
            String pu = Jsons.str(o, "per_update_expression", null);
            if (ce != null && !ce.isBlank()) creationExpr = Molang.compileLenient(ce);
            if (pu != null && !pu.isBlank()) perUpdateExpr = Molang.compileLenient(pu);
        }
        o = Jsons.obj(c, "minecraft:emitter_lifetime_looping");
        if (o != null) {
            looping = true;
            activeTime = PVal.parse(o.get("active_time"), 10);
            sleepTime = PVal.parse(o.get("sleep_time"), 0);
        }
        o = Jsons.obj(c, "minecraft:emitter_lifetime_once");
        if (o != null) {
            looping = false;
            activeTime = PVal.parse(o.get("active_time"), 10);
        }
        o = Jsons.obj(c, "minecraft:emitter_rate_instant");
        if (o != null) {
            steady = false;
            numParticles = PVal.parse(o.get("num_particles"), 10);
        }
        o = Jsons.obj(c, "minecraft:emitter_rate_steady");
        if (o != null) {
            steady = true;
            spawnRate = PVal.parse(o.get("spawn_rate"), 1);
            maxParticles = PVal.parse(o.get("max_particles"), 50);
        }
        JsonObject s;
        if ((s = Jsons.obj(c, "minecraft:emitter_shape_point")) != null) {
            shape = Shape.POINT;
            offset = PVal.vec(s.get("offset"), 3, 0);
            parseDirection(s, Dir.CUSTOM);
        } else if ((s = Jsons.obj(c, "minecraft:emitter_shape_disc")) != null) {
            shape = Shape.DISC;
            offset = PVal.vec(s.get("offset"), 3, 0);
            radius = PVal.parse(s.get("radius"), 1);
            surfaceOnly = PVal.parse(s.get("surface_only"), 0);
            JsonElement pn = s.get("plane_normal");
            if (pn != null && pn.isJsonPrimitive() && pn.getAsJsonPrimitive().isString()
                    && pn.getAsString().trim().length() == 1 && "xyzXYZ".contains(pn.getAsString().trim())) {
                String ax = pn.getAsString().trim().toLowerCase(Locale.ROOT);
                planeNormal = new PVal[]{PVal.of(ax.equals("x") ? 1 : 0), PVal.of(ax.equals("y") ? 1 : 0), PVal.of(ax.equals("z") ? 1 : 0)};
            } else if (pn != null) {
                planeNormal = PVal.vec(pn, 3, 0);
            }
            parseDirection(s, Dir.OUTWARDS);
        } else if ((s = Jsons.obj(c, "minecraft:emitter_shape_box")) != null) {
            shape = Shape.BOX;
            offset = PVal.vec(s.get("offset"), 3, 0);
            halfDim = PVal.vec(s.get("half_dimensions"), 3, 1);
            surfaceOnly = PVal.parse(s.get("surface_only"), 0);
            parseDirection(s, Dir.OUTWARDS);
        } else if ((s = Jsons.obj(c, "minecraft:emitter_shape_sphere")) != null) {
            shape = Shape.SPHERE;
            offset = PVal.vec(s.get("offset"), 3, 0);
            radius = PVal.parse(s.get("radius"), 1);
            surfaceOnly = PVal.parse(s.get("surface_only"), 0);
            parseDirection(s, Dir.OUTWARDS);
        }
        o = Jsons.obj(c, "minecraft:emitter_local_space");
        if (o != null) {
            localPos = Jsons.bool(o, "position", false);
            localRot = Jsons.bool(o, "rotation", false);
            localVel = Jsons.bool(o, "velocity", false);
        }
    }

    private void parseDirection(JsonObject s, Dir def) {
        JsonElement e = s.get("direction");
        dirMode = def;
        if (e == null) return;
        if (e.isJsonPrimitive() && e.getAsJsonPrimitive().isString()) {
            String v = e.getAsString().trim().toLowerCase(Locale.ROOT);
            if (v.equals("inwards")) dirMode = Dir.INWARDS;
            else if (v.equals("outwards")) dirMode = Dir.OUTWARDS;
            return;
        }
        if (e.isJsonArray()) {
            dirMode = Dir.CUSTOM;
            dir = PVal.vec(e, 3, 0);
        }
    }

    private void parseParticle(JsonObject c) {
        JsonObject o = Jsons.obj(c, "minecraft:particle_lifetime_expression");
        if (o != null) maxLifetime = PVal.parse(o.get("max_lifetime"), 1);
        JsonElement sp = c.get("minecraft:particle_initial_speed");
        if (sp != null) {
            if (sp.isJsonArray()) speedVec = PVal.vec(sp, 3, 0);
            else speed = PVal.parse(sp, 0);
        }
        o = Jsons.obj(c, "minecraft:particle_initial_spin");
        if (o != null) {
            spinRot = PVal.parse(o.get("rotation"), 0);
            spinRate = PVal.parse(o.get("rotation_rate"), 0);
        }
        o = Jsons.obj(c, "minecraft:particle_motion_dynamic");
        if (o != null) {
            dynamic = true;
            accel = PVal.vec(o.get("linear_acceleration"), 3, 0);
            drag = PVal.parse(o.get("linear_drag_coefficient"), 0);
            rotAccel = PVal.parse(o.get("rotation_acceleration"), 0);
            rotDrag = PVal.parse(o.get("rotation_drag_coefficient"), 0);
        }
        o = Jsons.obj(c, "minecraft:particle_motion_collision");
        if (o != null) {
            collision = true;
            colEnabled = PVal.parse(o.get("enabled"), 1);
            colDrag = PVal.parse(o.get("collision_drag"), 0);
            colRestitution = PVal.parse(o.get("coefficient_of_restitution"), 1);
            colRadius = PVal.parse(o.get("collision_radius"), 0.1);
            colExpire = Jsons.bool(o, "expire_on_contact", false);
        }
        expireIfNotIn = blockSet(c.get("minecraft:particle_expire_if_not_in_blocks"));
        expireIfIn = blockSet(c.get("minecraft:particle_expire_if_in_blocks"));
    }

    private static Set<String> blockSet(JsonElement e) {
        if (e == null || !e.isJsonArray()) return null;
        Set<String> s = new HashSet<>();
        for (JsonElement x : e.getAsJsonArray()) {
            if (x.isJsonPrimitive()) {
                String id = x.getAsString();
                s.add(id.contains(":") ? id : "minecraft:" + id);
            }
        }
        return s;
    }

    private void parseAppearance(JsonObject c) {
        JsonObject b = Jsons.obj(c, "minecraft:particle_appearance_billboard");
        if (b != null) {
            size = PVal.vec(b.get("size"), 2, 0.1);
            String fm = Jsons.str(b, "facing_camera_mode", "rotate_xyz").toLowerCase(Locale.ROOT);
            try {
                facing = Facing.valueOf(fm.toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException ex) {
                facing = Facing.ROTATE_XYZ;
            }
            JsonObject dd = Jsons.obj(b, "direction");
            if (dd != null) {
                dirDerive = !"custom".equalsIgnoreCase(Jsons.str(dd, "mode", "derive_from_velocity"));
                if (!dirDerive) dirCustom = PVal.vec(dd.get("custom_direction"), 3, 0);
                dirMinSpeed = Jsons.num(dd, "min_speed_threshold", 0.01);
            }
            JsonObject u = Jsons.obj(b, "uv");
            if (u != null) {
                texW = PVal.parse(u.get("texture_width"), 1);
                texH = PVal.parse(u.get("texture_height"), 1);
                JsonObject fb = Jsons.obj(u, "flipbook");
                if (fb != null) {
                    flipbook = true;
                    fbBase = PVal.vec(fb.get("base_UV"), 2, 0);
                    fbSize = PVal.vec(fb.get("size_UV"), 2, 1);
                    fbStep = PVal.vec(fb.get("step_UV"), 2, 0);
                    fbFps = PVal.parse(fb.get("frames_per_second"), 1);
                    fbMax = PVal.parse(fb.get("max_frame"), 1);
                    fbStretch = Jsons.bool(fb, "stretch_to_lifetime", false);
                    fbLoop = Jsons.bool(fb, "loop", false);
                } else {
                    uv = PVal.vec(u.get("uv"), 2, 0);
                    uvSize = PVal.vec(u.get("uv_size"), 2, 1);
                }
            }
        }
        JsonObject t = Jsons.obj(c, "minecraft:particle_appearance_tinting");
        if (t != null && t.has("color")) parseTint(t.get("color"));
        lighting = c.has("minecraft:particle_appearance_lighting");
    }

    private void parseTint(JsonElement col) {
        if (col.isJsonArray()) {
            JsonArray a = col.getAsJsonArray();
            tintKind = 1;
            tint = new PVal[4];
            for (int i = 0; i < 4; i++) tint[i] = i < a.size() ? PVal.parse(a.get(i), 1) : PVal.of(1);
        } else if (col.isJsonObject()) {
            JsonObject o = col.getAsJsonObject();
            interpolant = PVal.parse(o.get("interpolant"), 0);
            JsonElement g = o.get("gradient");
            TreeMap<Double, float[]> stops = new TreeMap<>();
            if (g != null && g.isJsonObject()) {
                for (Map.Entry<String, JsonElement> en : g.getAsJsonObject().entrySet()) {
                    try {
                        stops.put(Double.parseDouble(en.getKey()), color(en.getValue()));
                    } catch (RuntimeException ignored) {
                    }
                }
            } else if (g != null && g.isJsonArray()) {
                JsonArray ga = g.getAsJsonArray();
                for (int i = 0; i < ga.size(); i++) stops.put(ga.size() == 1 ? 0.0 : i / (double) (ga.size() - 1), color(ga.get(i)));
            }
            if (!stops.isEmpty()) {
                tintKind = 2;
                gradPos = new double[stops.size()];
                gradCol = new float[stops.size()][];
                int i = 0;
                for (Map.Entry<Double, float[]> en : stops.entrySet()) {
                    gradPos[i] = en.getKey();
                    gradCol[i++] = en.getValue();
                }
            }
        } else if (col.isJsonPrimitive()) {
            float[] f = color(col);
            tintKind = 1;
            tint = new PVal[]{PVal.of(f[0]), PVal.of(f[1]), PVal.of(f[2]), PVal.of(f[3])};
        }
    }

    /** {@code #AARRGGBB} (Bedrock order) or {@code #RRGGBB}, or a 3/4 element numeric array. */
    static float[] color(JsonElement e) {
        if (e.isJsonArray()) {
            JsonArray a = e.getAsJsonArray();
            return new float[]{(float) a.get(0).getAsDouble(), (float) a.get(1).getAsDouble(), (float) a.get(2).getAsDouble(),
                    a.size() > 3 ? (float) a.get(3).getAsDouble() : 1f};
        }
        String s = e.getAsString().trim();
        if (s.startsWith("#")) s = s.substring(1);
        else if (s.startsWith("0x") || s.startsWith("0X")) s = s.substring(2);
        long v = Long.parseLong(s, 16);
        if (s.length() <= 6) return new float[]{((v >> 16) & 255) / 255f, ((v >> 8) & 255) / 255f, (v & 255) / 255f, 1f};
        return new float[]{((v >> 16) & 255) / 255f, ((v >> 8) & 255) / 255f, (v & 255) / 255f, ((v >> 24) & 255) / 255f};
    }

    /** All custom (non-builtin) variable names this effect reads or writes - informational. */
    public List<String> curveNames() {
        return new ArrayList<>(curves.keySet());
    }

    static Map<String, Object> newVarMap() {
        return new HashMap<>();
    }
}
