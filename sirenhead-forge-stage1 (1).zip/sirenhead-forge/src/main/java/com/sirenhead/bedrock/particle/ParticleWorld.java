package com.sirenhead.bedrock.particle;

/** World queries the particle simulation needs (implemented by the Forge client; a stub in tests). */
public interface ParticleWorld {
    /** Full block id at the cell, e.g. {@code minecraft:air}. */
    String blockId(int x, int y, int z);

    /** True if the cell blocks particles (collision shape non-empty). */
    boolean isSolid(int x, int y, int z);

    /** A world with nothing in it. */
    ParticleWorld EMPTY = new ParticleWorld() {
        @Override
        public String blockId(int x, int y, int z) {
            return "minecraft:air";
        }

        @Override
        public boolean isSolid(int x, int y, int z) {
            return false;
        }
    };
}
