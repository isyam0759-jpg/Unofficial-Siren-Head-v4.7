package com.sirenhead.bedrock.particle;

import com.sirenhead.bedrock.json.Jsons;
import com.sirenhead.bedrock.res.ResourceSource;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

/** All particle definitions of the resource pack, keyed by Bedrock identifier (e.g. {@code bd:siren_range}). */
public final class ParticleLibrary {
    private static final Logger LOG = Logger.getLogger("sirenhead.particles");

    private final Map<String, ParticleDef> defs = new LinkedHashMap<>();
    private final List<String> errors = new java.util.ArrayList<>();

    private ParticleLibrary() {
    }

    public static ParticleLibrary load(ResourceSource src, String rpRoot) {
        ParticleLibrary lib = new ParticleLibrary();
        String dir = rpRoot.isEmpty() ? "particles" : rpRoot + "/particles";
        for (String p : src.list(dir, ".json")) {
            String text = src.readText(p);
            if (text == null) continue;
            try {
                ParticleDef d = ParticleDef.parse(Jsons.parseObject(text));
                lib.defs.put(d.identifier(), d);
            } catch (RuntimeException ex) {
                lib.errors.add(p + ": " + ex);
                LOG.log(Level.WARNING, "Cannot parse particle " + p, ex);
            }
        }
        return lib;
    }

    public ParticleDef get(String bedrockId) {
        return defs.get(bedrockId);
    }

    public Set<String> ids() {
        return Collections.unmodifiableSet(defs.keySet());
    }

    public List<String> errors() {
        return errors;
    }
}
