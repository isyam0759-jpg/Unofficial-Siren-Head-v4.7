package com.sirenhead.bedrock.anim;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sirenhead.bedrock.json.Jsons;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Parsed RP {@code minecraft:client_entity} description. */
public final class ClientEntityDef {
    private String identifier;
    private final Map<String, String> textures = new LinkedHashMap<>();
    private final Map<String, String> geometry = new LinkedHashMap<>();
    private final Map<String, String> materials = new LinkedHashMap<>();
    private final Map<String, String> animations = new LinkedHashMap<>();
    private final Map<String, String> particleEffects = new LinkedHashMap<>();
    private final Map<String, String> soundEffects = new LinkedHashMap<>();
    private List<AnimateEntry> animate = new ArrayList<>();
    private List<String> preAnimation = new ArrayList<>();
    private List<String> initialize = new ArrayList<>();
    private final List<AnimateEntry> renderControllers = new ArrayList<>();
    private boolean hasScripts;
    private boolean updateOffscreen;
    private JsonObject spawnEgg;

    private ClientEntityDef() {
    }

    /** {@code root} is the whole file ({@code {"minecraft:client_entity": {"description": ...}}}); returns null if absent. */
    public static ClientEntityDef parse(JsonObject root) {
        JsonObject ce = Jsons.obj(root, "minecraft:client_entity");
        JsonObject d = Jsons.obj(ce, "description");
        if (d == null) return null;
        ClientEntityDef c = new ClientEntityDef();
        c.identifier = Jsons.str(d, "identifier", null);
        strMap(Jsons.obj(d, "textures"), c.textures);
        strMap(Jsons.obj(d, "geometry"), c.geometry);
        strMap(Jsons.obj(d, "materials"), c.materials);
        strMap(Jsons.obj(d, "animations"), c.animations);
        strMap(Jsons.obj(d, "particle_effects"), c.particleEffects);
        strMap(Jsons.obj(d, "sound_effects"), c.soundEffects);
        JsonObject sc = Jsons.obj(d, "scripts");
        if (sc != null) {
            c.hasScripts = true;
            c.animate = EntityAnimator.parseAnimate(sc.get("animate"));
            c.preAnimation = EntityAnimator.parseScriptList(sc.get("pre_animation"));
            c.initialize = EntityAnimator.parseScriptList(sc.get("initialize"));
            c.updateOffscreen = Jsons.bool(sc, "should_update_bones_and_effects_offscreen", false);
        }
        c.renderControllers.addAll(EntityAnimator.parseAnimate(d.get("render_controllers")));
        c.spawnEgg = Jsons.obj(d, "spawn_egg");
        return c;
    }

    private static void strMap(JsonObject o, Map<String, String> out) {
        if (o == null) return;
        for (Map.Entry<String, JsonElement> e : o.entrySet()) {
            if (e.getValue().isJsonPrimitive()) out.put(e.getKey(), e.getValue().getAsString());
        }
    }

    public String identifier() {
        return identifier;
    }

    public Map<String, String> textures() {
        return textures;
    }

    public Map<String, String> geometry() {
        return geometry;
    }

    public Map<String, String> materials() {
        return materials;
    }

    public Map<String, String> animations() {
        return animations;
    }

    public List<AnimateEntry> animate() {
        return animate;
    }

    public List<String> preAnimation() {
        return preAnimation;
    }

    public List<String> initialize() {
        return initialize;
    }

    public Map<String, String> particleEffects() {
        return particleEffects;
    }

    public Map<String, String> soundEffects() {
        return soundEffects;
    }

    /** Names of the render controllers in declaration order. */
    public List<String> renderControllers() {
        List<String> n = new ArrayList<>();
        for (AnimateEntry e : renderControllers) n.add(e.shortName());
        return n;
    }

    /** Render controllers with their optional condition expressions. */
    public List<AnimateEntry> renderControllerEntries() {
        return renderControllers;
    }

    public boolean hasScripts() {
        return hasScripts;
    }

    public boolean updateOffscreen() {
        return updateOffscreen;
    }

    public JsonObject spawnEgg() {
        return spawnEgg;
    }
}
