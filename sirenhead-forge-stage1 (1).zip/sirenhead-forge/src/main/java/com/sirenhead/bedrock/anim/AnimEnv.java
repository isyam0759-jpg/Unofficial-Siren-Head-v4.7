package com.sirenhead.bedrock.anim;

import com.sirenhead.bedrock.molang.MolangEnv;

/**
 * Decorator over the entity environment that supplies the animation-scoped queries
 * ({@code query.anim_time}, {@code all_animations_finished}, ...) and the {@code this} value.
 * Mutable and reused; only valid during a single evaluation pass.
 */
final class AnimEnv implements MolangEnv {
    MolangEnv host;
    double animTime;
    double delta;
    double clock;
    double thisValue;
    boolean allFinished;
    boolean anyFinished;

    AnimEnv(MolangEnv host) {
        this.host = host;
    }

    @Override
    public Object query(String name, Object[] args) {
        switch (name) {
            case "anim_time":
                return animTime;
            case "delta_time":
                return delta;
            case "all_animations_finished":
                return allFinished ? 1.0 : 0.0;
            case "any_animation_finished":
                return anyFinished ? 1.0 : 0.0;
            default:
                Object r = host.query(name, args);
                if (r == null && name.equals("life_time")) return clock;
                return r;
        }
    }

    @Override
    public Object getVar(String path) {
        return host.getVar(path);
    }

    @Override
    public void setVar(String path, Object value) {
        host.setVar(path, value);
    }

    @Override
    public Object getTemp(String path) {
        return host.getTemp(path);
    }

    @Override
    public void setTemp(String path, Object value) {
        host.setTemp(path, value);
    }

    @Override
    public Object getContext(String path) {
        return host.getContext(path);
    }

    @Override
    public double thisValue() {
        return thisValue;
    }

    @Override
    public MolangEnv resolveEntity(Object entityRef) {
        return host.resolveEntity(entityRef);
    }

    @Override
    public Object resource(String kind, String name) {
        return host.resource(kind, name);
    }

    @Override
    public double random() {
        return host.random();
    }
}
