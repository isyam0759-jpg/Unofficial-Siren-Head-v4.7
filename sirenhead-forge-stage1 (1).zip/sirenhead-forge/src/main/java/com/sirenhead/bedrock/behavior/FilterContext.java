package com.sirenhead.bedrock.behavior;

/** Per-subject facts for Bedrock filters (implemented by the Forge glue). */
public interface FilterContext {
    /**
     * Value of the filter test for this subject.
     *
     * @param test   e.g. {@code is_family}, {@code has_target}, {@code target_distance}, {@code hourly_clock_time}
     * @param domain optional domain (e.g. {@code hand} for {@code has_equipment}), may be null
     * @param arg    the filter's {@code value} for "argument tests" ({@code is_family: player}); null for the others
     * @return {@link Boolean} or {@link Double} (or {@link String}); {@code null} if the test is unknown here
     */
    Object fact(String test, String domain, String arg);
}
