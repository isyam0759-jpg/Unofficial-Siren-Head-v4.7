package com.sirenhead.bedrock.behavior;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sirenhead.bedrock.json.Jsons;
import com.sirenhead.bedrock.molang.Molang;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Runtime state of one entity's Bedrock behaviour: active component groups, properties, and the event interpreter. */
public final class BehaviorState {
    private static final int MAX_DEPTH = 24;

    private final BehaviorDef def;
    private final BehaviorHost host;
    private final Set<String> groups = new LinkedHashSet<>();
    private final Map<String, Double> props = new LinkedHashMap<>();
    private final Set<String> warned = new HashSet<>();
    private final Map<String, Integer> generations = new java.util.HashMap<>();

    private Map<String, JsonElement> effective;
    private Map<String, String> sources;
    private int depth;
    private boolean changed;

    public BehaviorState(BehaviorDef def, BehaviorHost host) {
        this.def = def;
        this.host = host;
        initDefaults();
    }

    public BehaviorDef def() {
        return def;
    }

    /** Resets properties to their defaults (groups are untouched). The caller then triggers {@code minecraft:entity_spawned}. */
    public final void initDefaults() {
        for (PropertyDef p : def.properties().values()) props.put(p.name(), p.def());
    }

    // =================================================================== groups

    public boolean hasGroup(String g) {
        return groups.contains(g);
    }

    public Set<String> activeGroups() {
        return java.util.Collections.unmodifiableSet(groups);
    }

    public boolean addGroup(String g) {
        if (!def.componentGroups().containsKey(g)) {
            warnOnce("unknown component group " + g);
            return false;
        }
        if (groups.add(g)) {
            generations.merge(g, 1, Integer::sum);
            invalidate();
            return true;
        }
        return false;
    }

    /** Incremented every time the group is (re-)added; lets the host restart timers/sensors of a re-added group. */
    public int generation(String g) {
        return generations.getOrDefault(g, 0);
    }

    public boolean removeGroup(String g) {
        if (groups.remove(g)) {
            invalidate();
            return true;
        }
        return false;
    }

    private void invalidate() {
        effective = null;
        sources = null;
        changed = true;
    }

    private void compute() {
        Map<String, JsonElement> m = new LinkedHashMap<>();
        Map<String, String> s = new LinkedHashMap<>();
        for (Map.Entry<String, JsonElement> en : def.components().entrySet()) {
            m.put(en.getKey(), en.getValue());
            s.put(en.getKey(), "");
        }
        for (String g : groups) {
            JsonObject go = def.componentGroups().get(g);
            if (go == null) continue;
            for (Map.Entry<String, JsonElement> en : go.entrySet()) {
                m.put(en.getKey(), en.getValue());
                s.put(en.getKey(), g);
            }
        }
        effective = m;
        sources = s;
    }

    /** Effective components: top-level overridden by active groups (later-activated groups win). */
    public Map<String, JsonElement> effectiveComponents() {
        if (effective == null) compute();
        return effective;
    }

    /** Group that provides the effective component ("" for the entity's top-level components, null if absent). */
    public String sourceOf(String component) {
        if (sources == null) compute();
        return sources.get(component);
    }

    public JsonElement raw(String component) {
        return effectiveComponents().get(component);
    }

    public boolean has(String component) {
        JsonElement e = raw(component);
        if (e == null || e.isJsonNull()) return false;
        return !(e.isJsonPrimitive() && e.getAsJsonPrimitive().isBoolean() && !e.getAsBoolean());
    }

    /** Component as an object ({@code true} / non-object values give an empty object); null if absent. */
    public JsonObject component(String name) {
        if (!has(name)) return null;
        JsonElement e = raw(name);
        return e.isJsonObject() ? e.getAsJsonObject() : new JsonObject();
    }

    // =================================================================== properties

    public double property(String name) {
        Double v = props.get(name);
        return v == null ? 0 : v;
    }

    public void setProperty(String name, double v) {
        PropertyDef p = def.properties().get(name);
        double c = p == null ? v : p.clamp(v);
        Double old = props.put(name, c);
        if (old == null || old != c) host.onPropertyChanged(name, c);
    }

    public Map<String, Double> properties() {
        return props;
    }

    // =================================================================== events

    /** Runs a Bedrock event with full semantics (add/remove groups, set_property, randomize, sequence, trigger, queue_command, filters). */
    public void trigger(String event) {
        JsonElement node = def.events().get(event);
        if (node == null) {
            if (!event.startsWith("minecraft:")) warnOnce("unknown event " + event + " on " + def.identifier());
            return;
        }
        if (depth >= MAX_DEPTH) {
            warnOnce("event recursion limit at " + event);
            return;
        }
        boolean outer = depth == 0;
        if (outer) changed = false;
        depth++;
        try {
            run(node);
        } finally {
            depth--;
        }
        if (outer && changed) {
            changed = false;
            host.onComponentsChanged();
        }
    }

    private boolean pass(JsonObject n) {
        return !n.has("filters") || Filters.test(n.get("filters"), host::filterContext);
    }

    private void run(JsonElement node) {
        if (node == null) return;
        if (node.isJsonArray()) {
            for (JsonElement e : node.getAsJsonArray()) run(e);
            return;
        }
        if (!node.isJsonObject()) return;
        JsonObject n = node.getAsJsonObject();
        if (!pass(n)) return;

        JsonObject rem = Jsons.obj(n, "remove");
        if (rem != null && rem.has("component_groups")) for (JsonElement g : rem.getAsJsonArray("component_groups")) removeGroup(g.getAsString());
        JsonObject add = Jsons.obj(n, "add");
        if (add != null && add.has("component_groups")) for (JsonElement g : add.getAsJsonArray("component_groups")) addGroup(g.getAsString());

        JsonObject sp = Jsons.obj(n, "set_property");
        if (sp != null) for (Map.Entry<String, JsonElement> en : sp.entrySet()) applySet(en.getKey(), en.getValue());

        JsonObject qc = Jsons.obj(n, "queue_command");
        if (qc != null) {
            String target = Jsons.str(qc, "target", "self");
            JsonElement c = qc.get("command");
            if (c != null) {
                if (c.isJsonArray()) for (JsonElement x : c.getAsJsonArray()) host.runCommand(x.getAsString(), target);
                else if (c.isJsonPrimitive()) host.runCommand(c.getAsString(), target);
            }
        }
        JsonElement rc = n.get("run_command");
        if (rc != null && rc.isJsonObject()) {
            JsonElement c = rc.getAsJsonObject().get("command");
            if (c != null && c.isJsonArray()) for (JsonElement x : c.getAsJsonArray()) host.runCommand(x.getAsString(), "self");
        }

        JsonElement tr = n.get("trigger");
        if (tr != null) {
            if (tr.isJsonPrimitive()) trigger(tr.getAsString());
            else if (tr.isJsonObject()) {
                String ev = Jsons.str(tr.getAsJsonObject(), "event", null);
                String tg = Jsons.str(tr.getAsJsonObject(), "target", "self");
                if (ev != null) {
                    if (tg.equals("self")) trigger(ev);
                    else host.warn("trigger target '" + tg + "' is not supported (event " + ev + ")");
                }
            }
        }

        JsonElement seq = n.get("sequence");
        if (seq != null && seq.isJsonArray()) for (JsonElement e : seq.getAsJsonArray()) run(e);

        JsonElement rnd = n.get("randomize");
        if (rnd != null && rnd.isJsonArray()) {
            JsonArray a = rnd.getAsJsonArray();
            List<JsonObject> cand = new ArrayList<>();
            List<Double> weights = new ArrayList<>();
            double total = 0;
            for (JsonElement e : a) {
                if (!e.isJsonObject()) continue;
                JsonObject o = e.getAsJsonObject();
                if (!pass(o)) continue;
                double w = Jsons.num(o, "weight", 1);
                if (w <= 0) continue;
                cand.add(o);
                weights.add(w);
                total += w;
            }
            if (!cand.isEmpty()) {
                double r = host.random().nextDouble() * total;
                JsonObject chosen = cand.get(cand.size() - 1);
                for (int i = 0; i < cand.size(); i++) {
                    r -= weights.get(i);
                    if (r < 0) {
                        chosen = cand.get(i);
                        break;
                    }
                }
                run(chosen);
            }
        }
    }

    private void applySet(String name, JsonElement value) {
        PropertyDef pd = def.properties().get(name);
        if (pd == null) {
            warnOnce("unknown property " + name);
            return;
        }
        double v;
        if (value.isJsonPrimitive() && value.getAsJsonPrimitive().isNumber()) v = value.getAsDouble();
        else if (value.isJsonPrimitive() && value.getAsJsonPrimitive().isBoolean()) v = value.getAsBoolean() ? 1 : 0;
        else {
            String s = value.getAsString().trim();
            try {
                v = Double.parseDouble(s);
            } catch (NumberFormatException nf) {
                if (pd.type().equals("enum")) {
                    String bare = s.replace("'", "");
                    int idx = pd.enumValues().indexOf(bare);
                    if (idx >= 0) {
                        setProperty(name, idx);
                        return;
                    }
                }
                Object r = Molang.compileLenient(s).eval(host.env());
                if (r instanceof String && pd.type().equals("enum")) v = Math.max(0, pd.enumValues().indexOf(r));
                else v = Molang.toNum(r);
            }
        }
        setProperty(name, v);
    }

    private void warnOnce(String msg) {
        if (warned.add(msg)) host.warn(msg);
    }

    // =================================================================== persistence

    public String saveState() {
        JsonObject o = new JsonObject();
        JsonArray g = new JsonArray();
        for (String s : groups) g.add(s);
        o.add("groups", g);
        JsonObject p = new JsonObject();
        for (Map.Entry<String, Double> en : props.entrySet()) p.addProperty(en.getKey(), en.getValue());
        o.add("props", p);
        return o.toString();
    }

    public void loadState(String s) {
        if (s == null || s.isEmpty()) return;
        JsonObject o = Jsons.parseObject(s);
        groups.clear();
        JsonArray g = Jsons.arr(o, "groups");
        if (g != null) for (JsonElement e : g) if (def.componentGroups().containsKey(e.getAsString())) groups.add(e.getAsString());
        JsonObject p = Jsons.obj(o, "props");
        if (p != null) for (Map.Entry<String, JsonElement> en : p.entrySet()) props.put(en.getKey(), en.getValue().getAsDouble());
        invalidate();
        changed = false;
    }
}
