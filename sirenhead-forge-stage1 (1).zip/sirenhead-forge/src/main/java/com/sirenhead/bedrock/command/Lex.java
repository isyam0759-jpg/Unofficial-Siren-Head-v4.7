package com.sirenhead.bedrock.command;

import java.util.ArrayList;
import java.util.List;

/** Tokenizer for Bedrock/Java command lines. Brackets/braces/quotes keep their content together. */
public final class Lex {
    private Lex() {
    }

    /** Splits on whitespace outside of [...], {...} and "..."; a lone "[" group directly after a selector token is glued to it ({@code @e [x=1]}). */
    public static List<String> tokens(String cmd) {
        List<String> out = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        int depth = 0;
        boolean quote = false;
        String s = cmd.trim();
        if (s.startsWith("/")) s = s.substring(1);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"') quote = !quote;
            if (!quote) {
                if (c == '[' || c == '{') depth++;
                else if (c == ']' || c == '}') depth = Math.max(0, depth - 1);
            }
            if (!quote && depth == 0 && Character.isWhitespace(c)) {
                if (sb.length() > 0) {
                    out.add(sb.toString());
                    sb.setLength(0);
                }
                continue;
            }
            sb.append(c);
        }
        if (sb.length() > 0) out.add(sb.toString());
        // glue "@e" + "[...]"
        List<String> glued = new ArrayList<>();
        for (String t : out) {
            if (!glued.isEmpty() && t.startsWith("[") && isBareSelector(glued.get(glued.size() - 1))) {
                glued.set(glued.size() - 1, glued.get(glued.size() - 1) + t);
            } else glued.add(t);
        }
        return glued;
    }

    public static boolean isBareSelector(String t) {
        return t.length() == 2 && t.charAt(0) == '@';
    }

    public static boolean isSelector(String t) {
        return t.length() >= 2 && t.charAt(0) == '@';
    }

    /** Joins {@code tokens[from..]} back into one string. */
    public static String rest(List<String> tokens, int from) {
        StringBuilder sb = new StringBuilder();
        for (int i = from; i < tokens.size(); i++) {
            if (i > from) sb.append(' ');
            sb.append(tokens.get(i));
        }
        return sb.toString();
    }
}
