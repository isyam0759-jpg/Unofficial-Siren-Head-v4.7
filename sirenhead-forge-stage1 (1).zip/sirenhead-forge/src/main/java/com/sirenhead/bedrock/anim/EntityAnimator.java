package com.sirenhead.bedrock.anim;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sirenhead.bedrock.molang.Molang;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Runs the {@code scripts.animate} list of one entity (animations and animation controllers, RP or BP flavour)
 * and produces a Bedrock-style additive {@link Pose} plus particle / sound / command events.
 * <p>
 * Not thread safe; one instance per entity per side.
 */
public final class EntityAnimator {
    private final BedrockAnimLibrary lib;
    private final Map<String, String> animationMap;
    private final boolean computePose;
    private final AnimationHost host;
    private final AnimEnv env;
    private final Pose pose = new Pose();
    private final Set<String> warned = new HashSet<>();
    private final List<Entry> entries = new ArrayList<>();
    private final List<Molang.Expr> preScripts = new ArrayList<>();
    private final List<Forced> forced = new ArrayList<>();
    private boolean started;
    private double startTime, lastTime;

    private static final class Entry {
        Molang.Expr cond;
        Node node;
    }

    public EntityAnimator(BedrockAnimLibrary lib, Map<String, String> animations, List<AnimateEntry> animate,
                          List<String> preAnimationScripts, boolean computePose, AnimationHost host) {
        this.lib = lib;
        this.animationMap = animations;
        this.computePose = computePose;
        this.host = host;
        this.env = new AnimEnv(host.env());
        for (String s : preAnimationScripts) preScripts.add(Molang.compileLenient(s));
        for (AnimateEntry a : animate) {
            String full = animations.getOrDefault(a.shortName(), a.shortName());
            Node n;
            if (full.startsWith("controller.")) {
                ControllerDef cd = lib.controller(full);
                if (cd == null) {
                    BedrockAnimLibrary.warnOnce(warned, "unknown controller " + full + " (animate '" + a.shortName() + "')");
                    continue;
                }
                n = new ControllerNode(cd);
            } else {
                AnimationDef ad = lib.animation(full);
                if (ad == null) {
                    BedrockAnimLibrary.warnOnce(warned, "unknown animation " + full + " (animate '" + a.shortName() + "')");
                    continue;
                }
                n = new AnimNode(ad);
            }
            Entry e = new Entry();
            e.cond = a.condition() == null || a.condition().isBlank() ? null : Molang.compileLenient(a.condition());
            e.node = n;
            entries.add(e);
        }
    }

    // ------------------------------------------------------------------ parsing helpers

    public static List<AnimateEntry> parseAnimate(JsonElement el) {
        List<AnimateEntry> out = new ArrayList<>();
        if (el == null) return out;
        if (el.isJsonPrimitive()) {
            out.add(new AnimateEntry(el.getAsString(), null));
        } else if (el.isJsonArray()) {
            for (JsonElement x : el.getAsJsonArray()) {
                if (x.isJsonPrimitive()) out.add(new AnimateEntry(x.getAsString(), null));
                else if (x.isJsonObject()) {
                    for (Map.Entry<String, JsonElement> e : x.getAsJsonObject().entrySet()) {
                        out.add(new AnimateEntry(e.getKey(), e.getValue().isJsonPrimitive() ? e.getValue().getAsString() : null));
                    }
                }
            }
        } else if (el.isJsonObject()) {
            JsonObject o = el.getAsJsonObject();
            for (Map.Entry<String, JsonElement> e : o.entrySet()) {
                out.add(new AnimateEntry(e.getKey(), e.getValue().isJsonPrimitive() ? e.getValue().getAsString() : null));
            }
        }
        return out;
    }

    public static List<String> parseScriptList(JsonElement el) {
        List<String> out = new ArrayList<>();
        if (el == null) return out;
        if (el.isJsonPrimitive()) out.add(el.getAsString());
        else if (el.isJsonArray()) {
            for (JsonElement x : el.getAsJsonArray()) if (x.isJsonPrimitive()) out.add(x.getAsString());
        }
        return out;
    }

    // ------------------------------------------------------------------ public API

    /** Advance to absolute time {@code timeSeconds} (monotonic) and recompute pose + fire events. */
    public void tick(double timeSeconds) {
        if (!started) {
            started = true;
            startTime = timeSeconds;
            lastTime = timeSeconds;
        }
        double dt = Math.max(0, timeSeconds - lastTime);
        lastTime = timeSeconds;
        env.host = host.env();
        env.clock = timeSeconds - startTime;
        prepEnv(0, dt);
        if (computePose) pose.reset();
        for (Molang.Expr s : preScripts) s.eval(env);
        for (Entry e : entries) {
            double w = 1;
            if (e.cond != null) {
                prepEnv(0, dt);
                w = e.cond.evalD(env);
            }
            if (w <= 0) {
                e.node.deactivate();
                continue;
            }
            e.node.update(timeSeconds, dt, w);
        }
        updateForced(timeSeconds, dt);
    }

    /** Pose of the last {@link #tick}. Only meaningful when constructed with {@code computePose}. */
    public Pose pose() {
        return pose;
    }

    /** Bedrock {@code /playanimation}: plays {@code fullAnimName} once on top of the running animations. */
    public void playForced(String fullAnimOrControllerName, String nextState, double blendOutSeconds, String stopExpression, String controllerName) {
        if (!computePose) return;
        AnimationDef def = lib.animation(fullAnimOrControllerName);
        if (def == null) {
            BedrockAnimLibrary.warnOnce(warned, "playanimation: unknown animation " + fullAnimOrControllerName);
            return;
        }
        Forced f = new Forced();
        f.inst = new AnimInstance(def);
        f.stop = stopExpression == null || stopExpression.isBlank() ? null : Molang.compileLenient(stopExpression);
        f.blendOut = Math.max(0, blendOutSeconds);
        forced.add(f);
    }

    /** Debug/testing: "controllerName=state" for every running controller. */
    public List<String> activeStates() {
        List<String> out = new ArrayList<>();
        for (Entry e : entries) {
            if (e.node instanceof ControllerNode c && c.entered && c.state != null) out.add(c.def.name + "=" + c.state.name);
        }
        return out;
    }

    public void reset() {
        started = false;
        forced.clear();
        for (Entry e : entries) e.node.deactivate();
    }

    // ------------------------------------------------------------------ internals

    private void prepEnv(double animTime, double dt) {
        env.animTime = animTime;
        env.delta = dt;
        env.thisValue = 0;
        env.allFinished = false;
        env.anyFinished = false;
    }

    private void runAction(ControllerDef.Action a) {
        if (a.command) host.command(a.text.trim());
        else if (a.expr != null) a.expr.eval(env);
    }

    private void runScriptString(String s) {
        String t = s.trim();
        if (t.isEmpty()) return;
        if (t.startsWith("/") || t.startsWith("@")) host.command(t);
        else Molang.compileLenient(t).eval(env);
    }

    private abstract static class Node {
        abstract void update(double time, double dt, double weight);

        abstract void deactivate();
    }

    // ---- single animation instance
    private final class AnimInstance {
        final AnimationDef def;
        boolean active;
        boolean first;
        double rawTime;
        double prevRaw;
        double animTime;
        boolean finished;
        boolean finishedOnce;

        AnimInstance(AnimationDef def) {
            this.def = def;
        }

        void reset() {
            active = false;
        }

        void update(double dt, double weight, boolean emit) {
            if (!active) {
                active = true;
                first = true;
                rawTime = 0;
                prevRaw = -1e-9;
                finished = false;
                finishedOnce = false;
            } else {
                prevRaw = rawTime;
                if (def.animTimeUpdate != null) {
                    env.animTime = rawTime;
                    env.delta = dt;
                    env.thisValue = 0;
                    rawTime = def.animTimeUpdate.evalD(env);
                } else {
                    rawTime += dt;
                }
            }
            double len = def.length;
            boolean looping = def.loop == AnimationDef.Loop.LOOP && len > 0;
            if (looping) {
                animTime = rawTime - Math.floor(rawTime / len) * len;
            } else if (len > 0) {
                animTime = Math.min(Math.max(rawTime, 0), len);
            } else {
                animTime = Math.max(rawTime, 0);
            }
            finished = def.loop != AnimationDef.Loop.LOOP && (len > 0 ? rawTime >= len : rawTime > 0);
            finishedOnce = len > 0 ? rawTime >= len : rawTime > 0;

            if (emit) {
                fireEvents(len, looping);
                if (computePose && !def.bones.isEmpty()) {
                    env.animTime = animTime;
                    env.delta = dt;
                    def.apply(animTime, weight, env, pose);
                }
            }
            first = false;
        }

        private void fireEvents(double len, boolean looping) {
            if (def.timeline.isEmpty() && def.sounds.isEmpty() && def.particles.isEmpty()) return;
            double lo = prevRaw;
            double hi = rawTime;
            if (looping) {
                double pc = Math.floor(Math.max(lo, 0) / len), cc = Math.floor(hi / len);
                double loMod = lo < 0 ? lo : lo - pc * len;
                double hiMod = hi - cc * len;
                if (cc <= pc) {
                    window(loMod, hiMod, false);
                } else {
                    window(loMod, len, false);
                    window(-1e-9, hiMod, false);
                }
            } else {
                window(lo, len > 0 ? Math.min(hi, len) : hi, false);
            }
        }

        private void window(double lo, double hi, boolean unused) {
            env.animTime = animTime;
            for (int i = 0; i < def.timeline.times.length; i++) {
                double t = def.timeline.times[i];
                if (t > lo && t <= hi) for (String s : def.timeline.items.get(i)) runScriptString(s);
            }
            for (int i = 0; i < def.sounds.times.length; i++) {
                double t = def.sounds.times[i];
                if (t > lo && t <= hi) for (String s : def.sounds.items.get(i)) host.sound(s);
            }
            for (int i = 0; i < def.particles.times.length; i++) {
                double t = def.particles.times[i];
                if (t > lo && t <= hi) {
                    for (AnimationDef.ParticleEv p : def.particles.items.get(i)) host.particle(p.effect(), p.locator(), p.preScript());
                }
            }
        }
    }

    private final class AnimNode extends Node {
        final AnimInstance inst;

        AnimNode(AnimationDef def) {
            this.inst = new AnimInstance(def);
        }

        @Override
        void update(double time, double dt, double weight) {
            inst.update(dt, weight, true);
        }

        @Override
        void deactivate() {
            inst.reset();
        }
    }

    // ---- controller
    private static final class Slot {
        ControllerDef.StateAnim sa;
        AnimInstance inst; // null when the animation is unknown
    }

    private final class ControllerNode extends Node {
        final ControllerDef def;
        boolean entered;
        ControllerDef.State state;
        double stateEnter;
        List<Slot> cur = new ArrayList<>();
        List<Slot> prev;
        ControllerDef.State prevState;
        double switchTime;

        ControllerNode(ControllerDef def) {
            this.def = def;
        }

        @Override
        void deactivate() {
            entered = false;
            state = null;
            prev = null;
            cur = new ArrayList<>();
        }

        @Override
        void update(double time, double dt, double weight) {
            if (!entered) {
                entered = true;
                enter(def.initialState, time);
            }
            evalVariables(time);
            // one transition per tick, first matching wins
            prepEnv(time - stateEnter, dt);
            env.allFinished = allFinished(cur);
            env.anyFinished = anyFinished(cur);
            for (ControllerDef.Transition tr : state.transitions) {
                if (tr.cond.evalB(env)) {
                    if (def.states.containsKey(tr.target) && !tr.target.equals(state.name)) {
                        switchTo(tr.target, time);
                        evalVariables(time);
                    }
                    break;
                }
            }
            double fadeNew = 1, fadeOld = 0;
            if (prev != null) {
                double p = blendProgress(time);
                if (p >= 1) prev = null;
                else {
                    fadeNew = p;
                    fadeOld = 1 - p;
                }
            }
            updateSlots(cur, time, dt, weight * fadeNew, true);
            if (prev != null) updateSlots(prev, time, dt, weight * fadeOld, false);
        }

        private void evalVariables(double time) {
            if (state.variables.isEmpty()) return;
            prepEnv(time - stateEnter, 0);
            for (ControllerDef.VarDef v : state.variables) env.setVar(v.name, v.eval(env));
        }

        private double blendProgress(double time) {
            double t = time - switchTime;
            ControllerDef.State ps = prevState;
            if (ps.blendCurveX != null) {
                double[] x = ps.blendCurveX, y = ps.blendCurveY;
                if (t <= x[0]) return y[0];
                if (t >= x[x.length - 1]) return Math.max(y[y.length - 1], t >= x[x.length - 1] ? 1 : 0);
                for (int i = 0; i < x.length - 1; i++) {
                    if (t <= x[i + 1]) {
                        double f = (t - x[i]) / (x[i + 1] - x[i]);
                        return y[i] + (y[i + 1] - y[i]) * f;
                    }
                }
                return 1;
            }
            return ps.blendSeconds <= 0 ? 1 : Math.min(1, t / ps.blendSeconds);
        }

        private boolean allFinished(List<Slot> slots) {
            for (Slot s : slots) if (s.inst != null && !s.inst.finished) return false;
            return true;
        }

        private boolean anyFinished(List<Slot> slots) {
            for (Slot s : slots) if (s.inst != null && s.inst.finished) return true;
            return false;
        }

        private void updateSlots(List<Slot> slots, double time, double dt, double weight, boolean emit) {
            for (Slot s : slots) {
                if (s.inst == null) continue;
                double bw = 1;
                if (s.sa.blend != null) {
                    prepEnv(s.inst.animTime, dt);
                    bw = s.sa.blend.evalD(env);
                }
                double w = weight * bw;
                s.inst.update(dt, w, emit && w != 0);
            }
        }

        private void switchTo(String target, double time) {
            prepEnv(time - stateEnter, 0);
            for (ControllerDef.Action a : state.onExit) runAction(a);
            if (state.blendSeconds > 0 || state.blendCurveX != null) {
                prev = cur;
                prevState = state;
                switchTime = time;
            } else {
                prev = null;
            }
            enter(target, time);
        }

        private void enter(String name, double time) {
            state = def.states.get(name);
            stateEnter = time;
            cur = new ArrayList<>();
            for (ControllerDef.StateAnim sa : state.animations) {
                Slot s = new Slot();
                s.sa = sa;
                String full = animationMap.getOrDefault(sa.name, sa.name);
                AnimationDef ad = lib.animation(full);
                if (ad == null) BedrockAnimLibrary.warnOnce(warned, "controller " + def.name + " state " + name + ": unknown animation " + full);
                else s.inst = new AnimInstance(ad);
                cur.add(s);
            }
            prepEnv(0, 0);
            for (ControllerDef.Action a : state.onEntry) runAction(a);
            for (ControllerDef.ParticleSpec p : state.particles) host.particle(p.effect, p.locator, p.pre);
            for (String snd : state.sounds) host.sound(snd);
        }
    }

    // ---- forced (/playanimation)
    private static final class Forced {
        AnimInstance inst;
        Molang.Expr stop;
        double blendOut;
        boolean ending;
        double endTime;
    }

    private void updateForced(double time, double dt) {
        Iterator<Forced> it = forced.iterator();
        while (it.hasNext()) {
            Forced f = it.next();
            double w = 1;
            if (!f.ending) {
                boolean stop = false;
                if (f.stop != null) {
                    prepEnv(f.inst.animTime, dt);
                    stop = f.stop.evalB(env);
                }
                if (stop || f.inst.finishedOnce) {
                    f.ending = true;
                    f.endTime = time;
                }
            }
            if (f.ending) {
                if (f.blendOut <= 0) {
                    it.remove();
                    continue;
                }
                w = 1 - (time - f.endTime) / f.blendOut;
                if (w <= 0) {
                    it.remove();
                    continue;
                }
            }
            f.inst.update(dt, w, true);
        }
    }
}
