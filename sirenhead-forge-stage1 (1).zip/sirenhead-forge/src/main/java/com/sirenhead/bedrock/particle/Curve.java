package com.sirenhead.bedrock.particle;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sirenhead.bedrock.json.Jsons;
import com.sirenhead.bedrock.molang.MolangEnv;

import java.util.Map;

/** Bedrock particle {@code curves}: linear / bezier / catmull_rom value curves exposed as {@code variable.<name>}. */
final class Curve {
    enum Type { LINEAR, BEZIER, CATMULL_ROM }

    final Type type;
    final double[] nodes;
    final PVal input;
    final PVal range;

    private Curve(Type type, double[] nodes, PVal input, PVal range) {
        this.type = type;
        this.nodes = nodes;
        this.input = input;
        this.range = range;
    }

    static Curve parse(JsonObject o) {
        String t = Jsons.str(o, "type", "linear").toLowerCase();
        Type type = switch (t) {
            case "bezier" -> Type.BEZIER;
            case "catmull_rom" -> Type.CATMULL_ROM;
            default -> Type.LINEAR;
        };
        double[] nodes;
        JsonElement ne = o.get("nodes");
        if (ne != null && ne.isJsonArray()) {
            nodes = new double[ne.getAsJsonArray().size()];
            for (int i = 0; i < nodes.length; i++) {
                try {
                    nodes[i] = ne.getAsJsonArray().get(i).getAsDouble();
                } catch (RuntimeException ex) {
                    nodes[i] = 0;
                }
            }
        } else if (ne != null && ne.isJsonObject()) {
            // {"0.0": 1, "0.5": 2}: sorted by key, resampled evenly (keys are assumed to be evenly spaced in practice)
            java.util.TreeMap<Double, Double> m = new java.util.TreeMap<>();
            for (Map.Entry<String, JsonElement> en : ne.getAsJsonObject().entrySet()) {
                try {
                    m.put(Double.parseDouble(en.getKey()), en.getValue().getAsDouble());
                } catch (RuntimeException ignored) {
                }
            }
            nodes = m.values().stream().mapToDouble(Double::doubleValue).toArray();
        } else {
            nodes = new double[]{0, 1};
        }
        return new Curve(type, nodes, PVal.parse(o.get("input"), 0), PVal.parse(o.get("horizontal_range"), 1));
    }

    double eval(MolangEnv env) {
        double r = range.get(env);
        double x = r == 0 ? 0 : input.get(env) / r;
        return at(x);
    }

    double at(double x) {
        double[] n = nodes;
        if (n.length == 0) return 0;
        if (n.length == 1) return n[0];
        double t = x < 0 ? 0 : Math.min(x, 1);
        switch (type) {
            case BEZIER: {
                if (n.length < 4) return linear(t);
                double u = 1 - t;
                return u * u * u * n[0] + 3 * u * u * t * n[1] + 3 * u * t * t * n[2] + t * t * t * n[3];
            }
            case CATMULL_ROM: {
                if (n.length < 4) return linear(t);
                int segs = n.length - 3;
                double f = t * segs;
                int i = Math.min((int) Math.floor(f), segs - 1);
                double lt = f - i;
                double p0 = n[i], p1 = n[i + 1], p2 = n[i + 2], p3 = n[i + 3];
                double t2 = lt * lt, t3 = t2 * lt;
                return 0.5 * ((2 * p1) + (-p0 + p2) * lt + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3);
            }
            default:
                return linear(t);
        }
    }

    private double linear(double t) {
        int segs = nodes.length - 1;
        double f = t * segs;
        int i = Math.min((int) Math.floor(f), segs - 1);
        double lt = f - i;
        return nodes[i] + (nodes[i + 1] - nodes[i]) * lt;
    }
}
