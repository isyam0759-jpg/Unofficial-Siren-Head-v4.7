package com.sirenhead.bedrock.anim;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sirenhead.bedrock.json.Jsons;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/** Bone hierarchy + locators of one geometry; resolves locator positions under a {@link Pose}. */
public final class Rig {
    private static final class BoneInfo {
        String name, parent;
        double[] pivot = new double[3];
        double[] rot = new double[3];
    }

    private static final class Locator {
        String bone;
        double[] offset;
    }

    private final Map<String, BoneInfo> bones = new LinkedHashMap<>();
    private final Map<String, Locator> locators = new LinkedHashMap<>();

    private Rig() {
    }

    /** Parses a {@code minecraft:geometry} (1.12.0+) document; the first geometry is used. */
    public static Rig parse(String geoJson) {
        JsonObject root = Jsons.parseObject(geoJson);
        JsonArray geos = Jsons.arr(root, "minecraft:geometry");
        Rig r = new Rig();
        if (geos == null || geos.size() == 0) return r;
        JsonObject g = geos.get(0).getAsJsonObject();
        JsonArray bs = Jsons.arr(g, "bones");
        if (bs == null) return r;
        for (JsonElement be : bs) {
            JsonObject b = be.getAsJsonObject();
            BoneInfo bi = new BoneInfo();
            bi.name = Jsons.str(b, "name", null);
            if (bi.name == null) continue;
            bi.parent = Jsons.str(b, "parent", null);
            bi.pivot = Jsons.vec(b.get("pivot"), 3, 0);
            bi.rot = Jsons.vec(b.get("rotation"), 3, 0);
            r.bones.put(bi.name, bi);
            JsonObject ls = Jsons.obj(b, "locators");
            if (ls != null) {
                for (Map.Entry<String, JsonElement> le : ls.entrySet()) {
                    Locator l = new Locator();
                    l.bone = bi.name;
                    JsonElement v = le.getValue();
                    if (v.isJsonObject()) l.offset = Jsons.vec(v.getAsJsonObject().get("offset"), 3, 0);
                    else l.offset = Jsons.vec(v, 3, 0);
                    r.locators.put(le.getKey(), l);
                }
            }
        }
        return r;
    }

    public Set<String> boneNames() {
        return bones.keySet();
    }

    public Set<String> locatorNames() {
        return locators.keySet();
    }

    /** Initial (geometry) rotation of a bone in degrees, or null. */
    public double[] boneRotation(String bone) {
        BoneInfo b = bones.get(bone);
        return b == null ? null : b.rot.clone();
    }

    public double[] bonePivot(String bone) {
        BoneInfo b = bones.get(bone);
        return b == null ? null : b.pivot.clone();
    }

    public String boneParent(String bone) {
        BoneInfo b = bones.get(bone);
        return b == null ? null : b.parent;
    }

    /** Locator position in Bedrock model space (pixels) after bone transforms; null if the locator does not exist. */
    public double[] locator(String name, Pose pose) {
        Locator l = locators.get(name);
        if (l == null) return null;
        double[] p = l.offset.clone();
        BoneInfo b = bones.get(l.bone);
        int guard = 0;
        while (b != null && guard++ < 64) {
            double rx = b.rot[0], ry = b.rot[1], rz = b.rot[2];
            double px = 0, py = 0, pz = 0, sx = 1, sy = 1, sz = 1;
            if (pose != null) {
                Pose.Bone pb = pose.peek(b.name);
                if (pb != null && pb.touched) {
                    rx += pb.rot[0];
                    ry += pb.rot[1];
                    rz += pb.rot[2];
                    px = pb.pos[0];
                    py = pb.pos[1];
                    pz = pb.pos[2];
                    sx = pb.scale[0];
                    sy = pb.scale[1];
                    sz = pb.scale[2];
                }
            }
            double x = (p[0] - b.pivot[0]) * sx;
            double y = (p[1] - b.pivot[1]) * sy;
            double z = (p[2] - b.pivot[2]) * sz;
            // Rz * Ry * Rx
            double cx = Math.cos(Math.toRadians(rx)), sxn = Math.sin(Math.toRadians(rx));
            double y1 = y * cx - z * sxn, z1 = y * sxn + z * cx, x1 = x;
            double cy = Math.cos(Math.toRadians(ry)), syn = Math.sin(Math.toRadians(ry));
            double x2 = x1 * cy + z1 * syn, z2 = -x1 * syn + z1 * cy, y2 = y1;
            double cz = Math.cos(Math.toRadians(rz)), szn = Math.sin(Math.toRadians(rz));
            double x3 = x2 * cz - y2 * szn, y3 = x2 * szn + y2 * cz, z3 = z2;
            p[0] = b.pivot[0] + px + x3;
            p[1] = b.pivot[1] + py + y3;
            p[2] = b.pivot[2] + pz + z3;
            b = b.parent == null ? null : bones.get(b.parent);
        }
        return p;
    }
}
