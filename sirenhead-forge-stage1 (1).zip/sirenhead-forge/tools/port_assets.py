#!/usr/bin/env python3
"""
Converts the extracted Bedrock add-on (RP + BP) into the Forge resource layout described in docs/ARCHITECTURE.md.

Bedrock JSON that carries behaviour (animations, controllers, particles, entity definitions) is copied byte-for-byte.
Only things Java Edition physically cannot read are transformed:
  * file names are lower-cased / sanitised (resource locations must match [a-z0-9/._-])
  * geometry files are split to one geometry per file and 1.10.0-style geometry is upgraded to the 1.12.0 schema (GeckoLib)
  * .lang -> lang/en_us.json, sound_definitions -> Java sounds.json
Usage: python3 -I tools/port_assets.py <extracted_dir> <out_resources_dir>
"""
import json, os, re, shutil, sys

SRC = sys.argv[1]
OUT = sys.argv[2]
RP = os.path.join(SRC, 'SirenHead V4.7(RP)')
BP = os.path.join(SRC, 'SirenHead V4.7(BP)')
MOD = 'sirenhead'
A = os.path.join(OUT, 'assets', MOD)
D = os.path.join(OUT, 'data', MOD)
RP_OUT = os.path.join(A, 'bedrock', 'rp')
BP_OUT = os.path.join(D, 'bedrock', 'bp')
report = {'renamed': [], 'warnings': [], 'geometries': 0}


def load(path):
    s = open(path, encoding='utf-8-sig').read()
    try:
        return json.loads(s)
    except Exception:
        s2 = re.sub(r'(?m)^\s*//.*$', '', s)
        s2 = re.sub(r',(\s*[}\]])', r'\1', s2)
        return json.loads(s2)


def clean_name(rel):
    new = re.sub(r'[^a-z0-9/._-]', '_', rel.replace('\\', '/').lower().replace(' ', '_'))
    if new != rel.replace('\\', '/'):
        report['renamed'].append((rel, new))
    return new


def copy_tree(src_root, sub, dst_root, exts=None, skip=()):
    base = os.path.join(src_root, sub)
    if not os.path.isdir(base):
        return
    for root, _, files in os.walk(base):
        for f in sorted(files):
            if exts and not f.lower().endswith(exts):
                continue
            full = os.path.join(root, f)
            rel = os.path.relpath(full, src_root)
            if any(s in rel for s in skip):
                continue
            dst = os.path.join(dst_root, clean_name(rel))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copyfile(full, dst)


def index_of(root, prefix):
    out = []
    for r, _, files in os.walk(root):
        for f in files:
            if f == 'index.json':
                continue
            out.append(prefix + '/' + os.path.relpath(os.path.join(r, f), root).replace(os.sep, '/'))
    return sorted(out)


# ----------------------------------------------------------------------------- RP (data copied verbatim)
for sub in ('animations', 'animation_controllers', 'entity', 'render_controllers', 'particles', 'attachables'):
    copy_tree(RP, sub, RP_OUT, exts=('.json',))
os.makedirs(os.path.join(RP_OUT, 'sounds'), exist_ok=True)
shutil.copyfile(os.path.join(RP, 'sounds', 'sound_definitions.json'), os.path.join(RP_OUT, 'sounds', 'sound_definitions.json'))
if os.path.exists(os.path.join(RP, 'sounds.json')):
    shutil.copyfile(os.path.join(RP, 'sounds.json'), os.path.join(RP_OUT, 'sounds.json'))

# textures: same relative paths under assets/<mod>/textures (png/tga only)
tex_src = os.path.join(RP, 'textures')
for root, _, files in os.walk(tex_src):
    for f in sorted(files):
        if not f.lower().endswith(('.png', '.tga')):
            continue
        rel = os.path.relpath(os.path.join(root, f), RP)
        dst = os.path.join(A, clean_name(rel))
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copyfile(os.path.join(root, f), dst)

# ----------------------------------------------------------------------------- geometry -> GeckoLib
geo_index = {}


def upgrade_110(ident, g):
    """geometry.x (1.8/1.10 schema) -> 1.12.0 description + bones."""
    parent = None
    if ':' in ident:
        ident, parent = ident.split(':', 1)
        report['warnings'].append(f'geometry {ident} inherits {parent} (inheritance dropped)')
    desc = {
        'identifier': ident,
        'texture_width': g.get('texturewidth', 64),
        'texture_height': g.get('textureheight', 64),
    }
    for k_old, k_new in (('visible_bounds_width', 'visible_bounds_width'), ('visible_bounds_height', 'visible_bounds_height'),
                         ('visible_bounds_offset', 'visible_bounds_offset')):
        if k_old in g:
            desc[k_new] = g[k_old]
    bones = []
    for b in g.get('bones', []):
        nb = dict(b)
        if 'bind_pose_rotation' in nb:
            if 'rotation' not in nb:
                nb['rotation'] = nb['bind_pose_rotation']
            del nb['bind_pose_rotation']
        for junk in ('META_BoneType', 'reset', 'neverRender'):
            nb.pop(junk, None)
        bones.append(nb)
    return {'description': desc, 'bones': bones}


def write_geo(ident, geom_obj, fmt):
    name = ident[len('geometry.'):] if ident.startswith('geometry.') else ident
    name = re.sub(r'[^a-z0-9._-]', '_', name.lower())
    rel = f'geo/{name}.geo.json'
    path = os.path.join(A, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as fh:
        json.dump({'format_version': fmt, 'minecraft:geometry': [geom_obj]}, fh, separators=(',', ':'))
    geo_index[ident] = f'{MOD}:{rel}'
    report['geometries'] += 1


for root, _, files in os.walk(os.path.join(RP, 'models')):
    for f in sorted(files):
        if not f.endswith('.json'):
            continue
        full = os.path.join(root, f)
        d = load(full)
        if 'minecraft:geometry' in d:
            fmt = d.get('format_version', '1.12.0')
            for g in d['minecraft:geometry']:
                write_geo(g['description']['identifier'], g, fmt if fmt >= '1.12.0' else '1.12.0')
        else:
            for k, v in d.items():
                if k.startswith('geometry.'):
                    g = upgrade_110(k, v)
                    write_geo(g['description']['identifier'], g, '1.12.0')

# ----------------------------------------------------------------------------- BP (verbatim)
for sub in ('entities', 'animations', 'animation_controllers', 'spawn_rules', 'items', 'blocks', 'recipes', 'loot_tables', 'trading'):
    copy_tree(BP, sub, BP_OUT)
for root, _, files in os.walk(os.path.join(BP, 'functions')):
    for f in sorted(files):
        full = os.path.join(root, f)
        rel = os.path.relpath(full, BP)
        dst = os.path.join(BP_OUT, clean_name(rel))
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copyfile(full, dst)

# ----------------------------------------------------------------------------- lang
lang = {}
lang_src = os.path.join(RP, 'texts', 'en_US.lang')
if os.path.exists(lang_src):
    for line in open(lang_src, encoding='utf-8-sig'):
        line = line.rstrip('\n')
        if not line.strip() or line.lstrip().startswith('#') or '=' not in line:
            continue
        k, v = line.split('=', 1)
        v = v.split('\t#')[0].strip()
        k = k.strip()
        m = re.match(r'entity\.([a-z_]+):([a-z0-9_]+)\.name$', k)
        if m:
            lang[f'entity.{MOD}.{m.group(2)}'] = v
            continue
        m = re.match(r'item\.spawn_egg\.entity\.([a-z_]+):([a-z0-9_]+)\.name$', k)
        if m:
            lang[f'item.{MOD}.{m.group(2)}_spawn_egg'] = v
            continue
        m = re.match(r'(item|tile)\.([a-z_]+):([a-z0-9_]+)(?:\.name)?$', k)
        if m:
            lang[('item.' if m.group(1) == 'item' else 'block.') + f'{MOD}.{m.group(3)}'] = v
            continue
        lang['bedrock.' + k] = v
os.makedirs(os.path.join(A, 'lang'), exist_ok=True)
with open(os.path.join(A, 'lang', 'en_us.json'), 'w', encoding='utf-8') as fh:
    json.dump(lang, fh, indent=1, ensure_ascii=False, sort_keys=True)

# ----------------------------------------------------------------------------- sounds.json (Java)
sd = load(os.path.join(RP, 'sounds', 'sound_definitions.json'))
defs = sd.get('sound_definitions', sd)
java_sounds = {}
missing_ogg = []
for ev, v in defs.items():
    entries = []
    for s in v.get('sounds', []):
        if isinstance(s, str):
            s = {'name': s}
        name = s['name']
        path = re.sub(r'^sounds/', '', name).lower()
        e = {'name': f'{MOD}:{path}'}
        if 'volume' in s:
            e['volume'] = s['volume']
        if 'pitch' in s:
            e['pitch'] = s['pitch']
        if 'weight' in s:
            e['weight'] = s['weight']
        if s.get('stream'):
            e['stream'] = True
        entries.append(e)
        missing_ogg.append(f'assets/{MOD}/sounds/{path}.ogg')
    java_sounds[ev] = {'sounds': entries}
with open(os.path.join(A, 'sounds.json'), 'w', encoding='utf-8') as fh:
    json.dump(java_sounds, fh, indent=1, sort_keys=True)
with open(os.path.join(A, 'sounds', 'REQUIRED_SOUND_FILES.txt') if os.path.isdir(os.path.join(A, 'sounds')) else os.path.join(OUT, 'REQUIRED_SOUND_FILES.txt'), 'w') as fh:
    fh.write('The original .mcaddon did not contain audio files. Put .ogg files at these paths:\n')
    fh.write('\n'.join(sorted(set(missing_ogg))) + '\n')

# ----------------------------------------------------------------------------- indexes
with open(os.path.join(RP_OUT, 'geometry_index.json'), 'w') as fh:
    json.dump(geo_index, fh, indent=1, sort_keys=True)
with open(os.path.join(RP_OUT, 'index.json'), 'w') as fh:
    json.dump(index_of(RP_OUT, f'assets/{MOD}/bedrock/rp'), fh, indent=0)
with open(os.path.join(BP_OUT, 'index.json'), 'w') as fh:
    json.dump(index_of(BP_OUT, f'data/{MOD}/bedrock/bp'), fh, indent=0)

print('geometries:', report['geometries'], 'renamed files:', len(report['renamed']))
for r in report['renamed']:
    print('  renamed', r[0], '->', r[1])
for w in report['warnings']:
    print('  WARN', w)
