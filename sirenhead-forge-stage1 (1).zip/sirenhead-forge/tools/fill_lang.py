#!/usr/bin/env python3
"""Adds default English names for every registered entity/spawn egg/block/tab that the Bedrock lang file did not name."""
import json, glob, os, re

ROOT = os.path.join(os.path.dirname(__file__), '..')
LANG = os.path.join(ROOT, 'src/main/resources/assets/sirenhead/lang/en_us.json')
BP = os.path.join(ROOT, 'src/main/resources/data/sirenhead/bedrock/bp')

def java_path(ident):
    return ident.split(':', 1)[-1].lower()

def pretty(p):
    return ' '.join(w.capitalize() for w in re.split(r'[_\s]+', p) if w)

lang = json.load(open(LANG, encoding='utf-8'))
added = 0
def put(k, v):
    global added
    if k not in lang:
        lang[k] = v
        added += 1

for f in sorted(glob.glob(os.path.join(BP, 'entities', '**', '*.json'), recursive=True)):
    try:
        d = json.load(open(f, encoding='utf-8'))['minecraft:entity']
    except Exception:
        continue
    desc = d['description']
    p = java_path(desc['identifier'])
    nm = pretty(p)
    put('entity.sirenhead.' + p, nm)
    if desc.get('is_spawnable', True):
        put('item.sirenhead.%s_spawn_egg' % p, 'Spawn ' + nm)
put('block.sirenhead.siren_head_head', 'Head of Siren Head')
put('block.sirenhead.bd_lighter', 'Lighter')
put('itemGroup.sirenhead.main', 'Siren Head (ported add-on)')
json.dump(dict(sorted(lang.items())), open(LANG, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('added', added, 'total', len(lang))
