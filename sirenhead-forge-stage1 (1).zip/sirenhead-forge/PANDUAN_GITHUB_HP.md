# Build lewat GitHub dari HP (satu file workflow)

1. Buat repo baru di GitHub (app atau browser). Boleh privat.
2. **Add file → Upload files** → pilih `sirenhead-forge-stage1.zip` dari HP → **Commit changes**.
3. **Add file → Create new file**. Nama file: `.github/workflows/build.yml`
   (ketik dengan garis miring, folder dibuat otomatis). Tempel isi `build.yml` → **Commit**.
4. Tab **Actions → Build mod**. Berjalan otomatis setelah commit (atau **Run workflow**).
   Workflow ini sekaligus:
   * mengekstrak zip, menyimpan semua file proyek ke repo, dan menghapus zip-nya;
   * membangun jar (Java 17), sekitar 5–15 menit pertama.
5. Buka run-nya:
   * BERHASIL → **Artifacts** → `sirenhead-jar`.
   * GAGAL → **Summary** berisi daftar error. Salin dan kirim ke Claude. Log lengkap: artifact `build-log`.

Untuk memperbarui proyek: unggah zip baru ke root repo lalu jalankan "Build mod" lagi (zip lama ditimpa).
